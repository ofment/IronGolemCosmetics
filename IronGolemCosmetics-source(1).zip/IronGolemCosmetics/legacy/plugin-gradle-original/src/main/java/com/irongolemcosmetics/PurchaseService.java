package com.irongolemcosmetics;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * All ownership / selection rules. Everything runs on the main thread, so a purchase is atomic:
 *   owned? -> funds? -> withdraw -> mark owned -> save.
 * A second click can never reach "withdraw" for a skin that is already marked owned, and the in-flight
 * guard stops re-entrant calls, so money can only be taken once per skin.
 */
public final class PurchaseService {

    public enum Result { SUCCESS, DISABLED, PURCHASES_DISABLED, ALREADY_OWNED, NOT_OWNED, NOT_ENOUGH_MONEY, ECONOMY_ERROR, BUSY }

    private final IronGolemCosmeticsPlugin plugin;
    private final Set<UUID> inFlight = new HashSet<>();

    public PurchaseService(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean owns(UUID id, Skin s) {
        return s.price() <= 0D || plugin.data().get(id).owned.contains(s.id());
    }

    public Skin defaultSkin() {
        return plugin.skins().get(plugin.getConfig().getString("settings.default-skin", "vanilla"));
    }

    /** The skin that will really be used: explicit selection if valid, else the default skin (may be null). */
    public Skin effectiveSkin(UUID id) {
        String sel = plugin.data().get(id).selected;
        Skin s = plugin.skins().get(sel);
        if (s != null && s.enabled() && owns(id, s)) return s;
        Skin def = defaultSkin();
        return def != null && def.enabled() ? def : null;
    }

    public boolean isSelected(UUID id, Skin s) {
        Skin eff = effectiveSkin(id);
        return eff != null && eff.id().equals(s.id());
    }

    public boolean canBuy(Player p, Skin s) {
        return plugin.getConfig().getBoolean("settings.allow-purchase", true) && plugin.economy().has(p, s.price());
    }

    public Result purchase(Player p, Skin s) {
        if (!Bukkit.isPrimaryThread()) return Result.BUSY;
        if (!s.enabled()) return Result.DISABLED;
        if (!plugin.getConfig().getBoolean("settings.allow-purchase", true)) return Result.PURCHASES_DISABLED;
        UUID id = p.getUniqueId();
        if (!inFlight.add(id)) return Result.BUSY;
        try {
            PlayerDataStore.PlayerData d = plugin.data().get(id);
            if (owns(id, s)) return Result.ALREADY_OWNED;
            double price = s.price();
            if (!plugin.economy().available()) return Result.ECONOMY_ERROR;
            if (!plugin.economy().has(p, price)) return Result.NOT_ENOUGH_MONEY;
            if (!plugin.economy().withdraw(p, price)) return Result.ECONOMY_ERROR;
            d.owned.add(s.id());          // ownership is recorded immediately after the withdrawal
            plugin.data().save(id);
            return Result.SUCCESS;
        } finally {
            inFlight.remove(id);
        }
    }

    public Result select(Player p, Skin s) {
        if (!s.enabled()) return Result.DISABLED;
        UUID id = p.getUniqueId();
        if (!owns(id, s)) return Result.NOT_OWNED;
        plugin.data().get(id).selected = s.id();
        plugin.data().save(id);
        return Result.SUCCESS;
    }

    public void deselect(Player p) {
        plugin.data().get(p.getUniqueId()).selected = null;
        plugin.data().save(p.getUniqueId());
    }

    // ---- admin helpers (no money involved) ----
    public void grant(UUID id, Skin s) {
        plugin.data().get(id).owned.add(s.id());
        plugin.data().save(id);
    }

    public void revoke(UUID id, Skin s) {
        PlayerDataStore.PlayerData d = plugin.data().get(id);
        d.owned.remove(s.id());
        if (s.id().equals(d.selected == null ? null : d.selected.toLowerCase(Locale.ROOT))) d.selected = null;
        plugin.data().save(id);
    }
}
