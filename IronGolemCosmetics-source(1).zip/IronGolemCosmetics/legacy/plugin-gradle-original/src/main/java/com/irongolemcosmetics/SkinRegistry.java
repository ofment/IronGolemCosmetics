package com.irongolemcosmetics;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

/** Reads the "skins" section of config.yml. Adding a skin never requires code changes. */
public final class SkinRegistry {

    private final IronGolemCosmeticsPlugin plugin;
    private final Map<String, Skin> skins = new LinkedHashMap<>();

    public SkinRegistry(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        skins.clear();
        ConfigurationSection root = plugin.getConfig().getConfigurationSection("skins");
        if (root == null) {
            plugin.getLogger().warning("config.yml has no 'skins' section.");
            return;
        }
        List<Skin> loaded = new ArrayList<>();
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Material icon = Material.matchMaterial(s.getString("icon.material", "IRON_BLOCK"));
            if (icon == null || icon.isAir()) {
                plugin.getLogger().warning("Skin '" + id + "': invalid icon material, using IRON_BLOCK.");
                icon = Material.IRON_BLOCK;
            }
            Map<String, Skin.AnimationSpec> anims = new HashMap<>();
            ConfigurationSection a = s.getConfigurationSection("animations");
            if (a != null) {
                for (String key : a.getKeys(false)) {
                    ConfigurationSection e = a.getConfigurationSection(key);
                    if (e != null) {
                        anims.put(key.toLowerCase(Locale.ROOT), new Skin.AnimationSpec(e.getString("name", key), e.getInt("ticks", 0)));
                    }
                }
            }
            loaded.add(new Skin(
                    id.toLowerCase(Locale.ROOT),
                    s.getBoolean("enabled", true),
                    s.getInt("sort-order", 100),
                    s.getString("display-name", id),
                    s.getStringList("description"),
                    Math.max(0D, s.getDouble("price", 0D)),
                    icon,
                    s.getString("model", ""),
                    anims));
        }
        loaded.sort(Comparator.comparingInt(Skin::sortOrder));
        for (Skin skin : loaded) skins.put(skin.id(), skin);
    }

    public Skin get(String id) {
        return id == null ? null : skins.get(id.toLowerCase(Locale.ROOT));
    }

    public Collection<Skin> all() {
        return Collections.unmodifiableCollection(skins.values());
    }

    /** Enabled skins in menu order. */
    public List<Skin> enabled() {
        List<Skin> out = new ArrayList<>();
        for (Skin s : skins.values()) if (s.enabled()) out.add(s);
        return out;
    }

    public int size() {
        return skins.size();
    }
}
