package com.irongolemcosmetics;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Level;

/**
 * Persistent per-player data: plugins/IronGolemCosmetics/playerdata/<uuid>.yml
 * Reads happen in AsyncPlayerPreLoginEvent (off the main thread); writes go through a single IO thread
 * with atomic file replacement, so a crash can never leave a half-written file.
 */
public final class PlayerDataStore {

    public static final class PlayerData {
        public final Set<String> owned = new LinkedHashSet<>();
        public volatile String selected;
    }

    private final IronGolemCosmeticsPlugin plugin;
    private final File dir;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> new Thread(r, "IronGolemCosmetics-IO"));

    public PlayerDataStore(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "playerdata");
    }

    private boolean persist() {
        return plugin.getConfig().getBoolean("settings.save-player-data", true);
    }

    public PlayerData get(UUID id) {
        return cache.computeIfAbsent(id, this::load);
    }

    private PlayerData load(UUID id) {
        PlayerData d = new PlayerData();
        if (!persist()) return d;
        File f = new File(dir, id + ".yml");
        if (f.isFile()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            d.owned.addAll(y.getStringList("owned"));
            d.selected = y.getString("selected");
        }
        return d;
    }

    /** Snapshot now (main thread) and write asynchronously. */
    public void save(UUID id) {
        PlayerData d = cache.get(id);
        if (d == null || !persist()) return;
        YamlConfiguration y = new YamlConfiguration();
        y.set("owned", new ArrayList<>(d.owned));
        y.set("selected", d.selected);
        String yaml = y.saveToString();
        try {
            io.execute(() -> write(id, yaml));
        } catch (RejectedExecutionException ex) {
            write(id, yaml);
        }
    }

    private void write(UUID id, String yaml) {
        try {
            Files.createDirectories(dir.toPath());
            Path target = new File(dir, id + ".yml").toPath();
            Path tmp = new File(dir, id + ".yml.tmp").toPath();
            Files.writeString(tmp, yaml, StandardCharsets.UTF_8);
            try {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not save player data for " + id, ex);
        }
    }

    /** Save and drop from memory (player left). */
    public void unload(UUID id) {
        save(id);
        cache.remove(id);
    }

    public void shutdown() {
        for (UUID id : new ArrayList<>(cache.keySet())) save(id);
        io.shutdown();
        try {
            if (!io.awaitTermination(10, TimeUnit.SECONDS)) plugin.getLogger().warning("Player data writer did not finish in time.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
