package com.irongolemcosmetics;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Locale;

/**
 * Talks to Screaming BedWars through reflection so this plugin still loads (and logs a clear message)
 * if the API differs. The only thing needed from BedWars: "is this player inside a game right now?".
 *
 * NOT VERIFIED on a live server by the author - see docs/COMPATIBILITY_AND_TESTING.md.
 */
public final class BedwarsBridge {

    private final IronGolemCosmeticsPlugin plugin;
    private Object api;
    private Method isPlaying;
    private Method gameOfPlayer;
    private boolean available;

    public BedwarsBridge(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
        hook();
    }

    private void hook() {
        Plugin bw = null;
        for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
            if (p != plugin && p.getName().toLowerCase(Locale.ROOT).contains("bedwars")) {
                bw = p;
                break;
            }
        }
        if (bw == null) {
            plugin.getLogger().warning("No BedWars plugin found - golem skins are only applied if settings.apply-without-bedwars-api is true.");
            return;
        }
        try {
            ClassLoader cl = bw.getClass().getClassLoader();
            Class<?> apiClass = Class.forName("org.screamingsandals.bedwars.api.BedwarsAPI", true, cl);
            api = apiClass.getMethod("getInstance").invoke(null);
            try {
                isPlaying = apiClass.getMethod("isPlayerPlayingAnyGame", Player.class);
            } catch (NoSuchMethodException ignored) {
                // try the other lookup below
            }
            try {
                gameOfPlayer = apiClass.getMethod("getGameOfPlayer", Player.class);
            } catch (NoSuchMethodException ignored) {
                // optional
            }
            available = api != null && (isPlaying != null || gameOfPlayer != null);
            plugin.getLogger().info("Hooked into " + bw.getName() + " " + bw.getPluginMeta().getVersion()
                    + " (API lookup " + (available ? "OK" : "FAILED") + ").");
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not hook the BedWars API (" + t + "). Check BedwarsBridge.java.");
        }
    }

    public boolean available() {
        return available;
    }

    public boolean isPlaying(Player p) {
        if (!available) return plugin.getConfig().getBoolean("settings.apply-without-bedwars-api", false);
        try {
            if (isPlaying != null) return (boolean) isPlaying.invoke(api, p);
            return gameOfPlayer.invoke(api, p) != null;
        } catch (Throwable t) {
            return false;
        }
    }
}
