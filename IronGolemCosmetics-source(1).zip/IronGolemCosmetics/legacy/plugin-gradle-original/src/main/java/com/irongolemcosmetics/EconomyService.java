package com.irongolemcosmetics;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Locale;

/**
 * Thin wrapper over Vault. The provider is looked up lazily, so it does not matter whether the
 * economy plugin (EssentialsX, CMI, ...) enabled before or after this plugin.
 */
public final class EconomyService {

    private final IronGolemCosmeticsPlugin plugin;

    public EconomyService(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
    }

    private Economy eco() {
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : rsp.getProvider();
    }

    public boolean available() {
        return eco() != null;
    }

    public double balance(OfflinePlayer p) {
        Economy e = eco();
        return e == null ? 0D : e.getBalance(p);
    }

    public boolean has(OfflinePlayer p, double amount) {
        Economy e = eco();
        return e != null && e.has(p, amount);
    }

    /** @return true only if the money was really taken. */
    public boolean withdraw(OfflinePlayer p, double amount) {
        Economy e = eco();
        if (e == null) return false;
        EconomyResponse r = e.withdrawPlayer(p, amount);
        return r != null && r.transactionSuccess();
    }

    public String format(double amount) {
        Economy e = eco();
        if (e != null) {
            try {
                return e.format(amount);
            } catch (Throwable ignored) {
                // fall through
            }
        }
        return String.format(Locale.US, "%,.2f", amount);
    }
}
