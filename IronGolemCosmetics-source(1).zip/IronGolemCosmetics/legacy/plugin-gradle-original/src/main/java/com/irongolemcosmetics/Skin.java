package com.irongolemcosmetics;

import org.bukkit.Material;

import java.util.List;
import java.util.Map;

/** One cosmetic skin, fully described by config.yml. */
public record Skin(String id, boolean enabled, int sortOrder, String displayName, List<String> description,
                   double price, Material icon, String model, Map<String, AnimationSpec> animations) {

    public record AnimationSpec(String name, int ticks) {}

    private static final Map<String, Integer> DEFAULT_TICKS = Map.of("draw", 17, "attack", 18, "sheathe", 20, "hurt", 9);

    public boolean hasModel() {
        return model != null && !model.isBlank();
    }

    /** Animation for a logical key (idle, run, combat-idle, combat-run, draw, attack, sheathe, hurt). */
    public AnimationSpec animation(String key) {
        AnimationSpec spec = animations.get(key);
        if (spec != null) return spec;
        return new AnimationSpec(key.replace('-', '_'), DEFAULT_TICKS.getOrDefault(key, 0));
    }
}
