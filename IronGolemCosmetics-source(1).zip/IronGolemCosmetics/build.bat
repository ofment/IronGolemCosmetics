@echo off
REM Builds target\IronGolemCosmetics.jar. Needs JDK 21+ and Maven on PATH and an internet connection.
java -version
mvn -version
mvn -DskipTests clean package
echo.
echo If the build succeeded your plugin is: target\IronGolemCosmetics.jar
pause
