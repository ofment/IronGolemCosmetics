#!/usr/bin/env python3
"""
Blue Phantom Rider - procedural model generator.
Outputs: blue_phantom_rider.bbmodel (Blockbench, textures embedded), texture PNG, preview renders.

ROT_SIGN: if rotations look mirrored when you open the model in Blockbench / BetterModel,
set ROT_SIGN = -1 and re-run this script. It flips every X rotation (static + animated).
"""
import json, math, base64, io, random, uuid, sys, os
from PIL import Image, ImageDraw

ROT_SIGN = 1
OUT = os.path.dirname(os.path.abspath(__file__))
TEX = 256
rnd = random.Random(7)

# ---------------------------------------------------------------- palette
PAL = {
    "armor":   ((26, 28, 38), (70, 110, 210)),   # base, edge-glow
    "armor2":  ((38, 42, 58), (90, 150, 255)),
    "helm":    ((20, 22, 32), (80, 140, 255)),
    "dark":    ((6, 8, 14), (6, 8, 14)),
    "glow":    ((120, 210, 255), (200, 245, 255)),
    "fx":      ((150, 225, 255), (230, 250, 255)),
    "cloth":   ((14, 20, 44), (40, 90, 200)),
    "leather": ((52, 38, 42), (90, 70, 90)),
    "saddle":  ((44, 30, 36), (60, 120, 220)),
    "horse":   ((22, 24, 34), (34, 40, 60)),
    "hbarding": ((34, 38, 56), (80, 140, 245)),
    "mane":    ((12, 16, 40), (60, 120, 255)),
    "hoof":    ((10, 10, 16), (24, 28, 44)),
    "steel":   ((70, 78, 100), (150, 190, 255)),
    "blade":   ((28, 36, 70), (110, 200, 255)),
    "scab":    ((22, 24, 32), (60, 110, 230)),
    "rein":    ((60, 52, 84), (110, 140, 230)),
}

# ---------------------------------------------------------------- scene graph
_n = [0]
def uid(tag):
    _n[0] += 1
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"bpr/{tag}/{_n[0]}"))

class G:
    def __init__(s, name, origin, rot=(0, 0, 0), parent=None):
        s.name, s.origin, s.rot, s.parent = name, list(origin), list(rot), parent
        s.children, s.uuid = [], uid(name)
        if parent: parent.children.append(s)
class C:
    def __init__(s, name, a, b, mat, inf, parent):
        s.name, s.a, s.b, s.mat, s.inf, s.parent = name, a, b, mat, inf, parent
        s.uuid = uid(name); parent.children.append(s)

ALL_G = {}
def grp(name, origin, rot=(0, 0, 0), parent=None):
    g = G(name, origin, rot, parent); ALL_G[name] = g; return g
def box(parent, name, x0, y0, z0, x1, y1, z1, mat, inf=0.0):
    return C(name, (x0, y0, z0), (x1, y1, z1), mat, inf, parent)
def mirror_x(parent, name, x0, y0, z0, x1, y1, z1, mat, inf=0.0):
    box(parent, name + "_r", x0, y0, z0, x1, y1, z1, mat, inf)
    box(parent, name + "_l", -x1, y0, z0, -x0, y1, z1, mat, inf)

# ---------------------------------------------------------------- math helpers
def rotm(rx, ry, rz):
    rx, ry, rz = [math.radians(v) for v in (rx, ry, rz)]
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = [[1, 0, 0], [0, cx, -sx], [0, sx, cx]]
    Ry = [[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]]
    Rz = [[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]]
    def mm(A, B): return [[sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return mm(Rz, mm(Ry, Rx))
def mv(M, v): return [sum(M[i][k] * v[k] for k in range(3)) for i in range(3)]
def tr(M): return [[M[j][i] for j in range(3)] for i in range(3)]
def add(a, b): return [a[i] + b[i] for i in range(3)]
def sub(a, b): return [a[i] - b[i] for i in range(3)]

def chain(node):
    out = []
    while node is not None and isinstance(node, G):
        out.append(node); node = node.parent
    return out[::-1]

def to_world(node, p, pose=None):
    """p in node's unrotated frame -> world, applying rest rotation (+ pose offsets)."""
    p = list(p)
    for g in reversed(chain(node)):
        rot = [g.rot[i] * 1 for i in range(3)]
        pos, scl = [0, 0, 0], 1.0
        if pose and g.name in pose:
            pr = pose[g.name]
            rot = [rot[i] + pr.get("rotation", (0, 0, 0))[i] for i in range(3)]
            pos = pr.get("position", (0, 0, 0)); scl = pr.get("scale", 1.0)
        R = rotm(ROT_SIGN * rot[0], rot[1], rot[2])
        d = sub(p, g.origin)
        d = [v * scl for v in d]
        p = add(add(g.origin, mv(R, d)), pos)
    return p

def to_local(node, pw):
    """world rest-pose point -> node's unrotated frame (inverse of to_world, rest only)."""
    p = list(pw)
    for g in chain(node):
        R = rotm(ROT_SIGN * g.rot[0], g.rot[1], g.rot[2])
        p = add(g.origin, mv(tr(R), sub(p, g.origin)))
    return p

def segment(parent, name, p0, p1, w, h, mat):
    """Box from p0 to p1 (points in parent's unrotated frame), implemented as rotated child group."""
    d = sub(p1, p0); L = math.sqrt(sum(v * v for v in d)); d = [v / L for v in d]
    rx = math.degrees(math.asin(d[1])); ry = math.degrees(math.atan2(-d[0], -d[2]))
    g = grp(name, p0, (ROT_SIGN * rx, ry, 0), parent)
    box(g, name + "_c", p0[0] - w / 2, p0[1] - h / 2, p0[2] - L, p0[0] + w / 2, p0[1] + h / 2, p0[2], mat)
    return g

# ---------------------------------------------------------------- arm IK (sagittal plane)
SY, L1, L2 = 38.0, 5.0, 5.0
def ik(z, y, ths):
    """hand target (z,y) relative to shoulder pivot (z=0,y=SY); sword/blade angle ths (0=down, 90=forward, 180=up).
    returns (upper_rot, fore_rot, hand_rot) in degrees (X axis)."""
    dz, dy = z, y - SY
    d = min(math.hypot(dz, dy), L1 + L2 - 1e-3)
    c2 = (d * d - L1 * L1 - L2 * L2) / (2 * L1 * L2)
    t2 = math.acos(max(-1, min(1, c2)))                  # elbow bends forward
    phi = math.atan2(-dz, -dy)
    delta = math.atan2(L2 * math.sin(t2), L1 + L2 * math.cos(t2))
    t1 = phi - delta
    r1, r2 = math.degrees(t1), math.degrees(t2)
    return r1, r2, ths - (r1 + r2)

# ================================================================= MODEL
root = grp("root", (0, 0, 0))
rig = grp("rig", (0, 20, 0), parent=root)                    # body-bob group

# ---- horse body
hb = grp("horse_body", (0, 22, 0), parent=rig)
box(hb, "barrel", -4.5, 16, -9, 4.5, 27, 10, "horse")
box(hb, "chest_armor", -5.0, 17, -10.4, 5.0, 26.5, -6, "hbarding")
box(hb, "chest_trim", -5.2, 21.5, -10.6, 5.2, 22.3, -6.0, "glow")
mirror_x(hb, "flank_plate", 4.5, 17.5, -4, 5.5, 25.5, 6, "hbarding")
mirror_x(hb, "flank_glow", 5.4, 21, -3, 5.7, 21.8, 5, "glow")
box(hb, "crupper", -5, 19, 6.2, 5, 27.5, 11, "hbarding")
box(hb, "spine_glow", -0.6, 27.5, -9, 0.6, 27.9, -3.5, "glow")
box(hb, "girth", -4.8, 16.6, 1, 4.8, 27.2, 2.2, "leather")
box(hb, "saddle_seat", -4.9, 27, -3, 4.9, 28.4, 6, "saddle")
box(hb, "saddle_pommel", -1.8, 28.4, -3.4, 1.8, 30.2, -1.8, "saddle")
box(hb, "saddle_cantle", -4, 28.4, 5, 4, 30.2, 6.8, "saddle")
box(hb, "saddle_blanket", -5.4, 25.6, -3.6, 5.4, 27, 6.6, "cloth")
mirror_x(hb, "stirrup_strap", 5.3, 21, 0.1, 5.8, 27.2, 0.9, "leather")
mirror_x(hb, "stirrup", 5.3, 20.2, -0.9, 7.0, 21.2, 2.0, "steel")

# ---- neck + head
neck = grp("neck", (0, 25.5, -8), (-35, 0, 0), parent=rig)
box(neck, "neck_core", -2.5, 25.5, -10.5, 2.5, 36.5, -5.5, "horse")
for i, (a, b) in enumerate([(26.4, 29.2), (29.7, 32.5), (33.0, 35.8)]):
    box(neck, f"crinet_{i}", -2.9, a, -11.2, 2.9, b, -10.4, "hbarding")
    box(neck, f"crinet_glow_{i}", -3.0, b - 0.3, -11.3, 3.0, b + 0.1, -10.3, "glow")
for i, (a, b) in enumerate([(26, 31), (30, 35), (34, 38.2)]):
    box(neck, f"mane_{i}", -0.6, a, -5.7, 0.6, b, -4.2 + i * 0.1, "mane")
head = grp("head", (0, 36.5, -8), (105, 0, 0), parent=neck)
box(head, "skull", -2.2, 28.4, -10.4, 2.2, 36.6, -5.6, "horse")
box(head, "muzzle", -1.9, 25.8, -10.2, 1.9, 28.8, -5.8, "horse")
box(head, "nostril_l", 0.6, 25.7, -10.35, 1.5, 26.5, -9.9, "dark")
box(head, "nostril_r", -1.5, 25.7, -10.35, -0.6, 26.5, -9.9, "dark")
box(head, "chamfron", -2.5, 30, -10.9, 2.5, 36.2, -10.35, "hbarding")
box(head, "chamfron_glow", -0.4, 29.8, -11.1, 0.4, 36.4, -10.85, "glow")
box(head, "chamfron_cheek_r", 2.2, 29, -10.0, 2.7, 35.5, -6.0, "hbarding")
box(head, "chamfron_cheek_l", -2.7, 29, -10.0, -2.2, 35.5, -6.0, "hbarding")
box(head, "eye_r", 2.65, 32.4, -9.2, 2.95, 33.6, -8.0, "glow")
box(head, "eye_l", -2.95, 32.4, -9.2, -2.65, 33.6, -8.0, "glow")
box(head, "ear_r", 1.1, 36.6, -8.4, 2.2, 39.4, -7.2, "hbarding")
box(head, "ear_l", -2.2, 36.6, -8.4, -1.1, 39.4, -7.2, "hbarding")
box(head, "noseband", -2.0, 27.6, -10.5, 2.0, 28.4, -5.5, "leather")
box(head, "bridle_brow", -2.4, 35.4, -9.4, 2.4, 36.0, -5.4, "leather")
box(head, "bridle_ring_r", 2.7, 31.4, -8.2, 3.3, 32.6, -7.0, "glow")
box(head, "bridle_ring_l", -3.3, 31.4, -8.2, -2.7, 32.6, -7.0, "glow")

# ---- tail
tail = grp("tail", (0, 26.5, 10.5), (28, 0, 0), parent=rig)
box(tail, "tail_0", -1.0, 18, 10, 1.0, 26.5, 11.6, "mane")
box(tail, "tail_1", -1.6, 12, 10.2, 1.6, 20, 11.4, "mane")
box(tail, "tail_glow", -0.3, 13, 11.4, 0.3, 21, 11.8, "glow")

# ---- legs (hip y = 16)
def leg(tag, x, z):
    up = grp(f"{tag}_u", (x, 17, z), parent=root)
    box(up, f"{tag}_thigh", x - 1.6, 8, z - 1.6, x + 1.6, 18, z + 1.6, "horse")
    box(up, f"{tag}_armor", x - 1.9, 10.2, z - 1.9, x + 1.9, 15.5, z + 1.9, "hbarding")
    lo = grp(f"{tag}_l", (x, 8.5, z), parent=up)
    box(lo, f"{tag}_cannon", x - 1.2, 2.2, z - 1.2, x + 1.2, 8.6, z + 1.2, "horse")
    box(lo, f"{tag}_greave", x - 1.5, 3.4, z - 1.5, x + 1.5, 7.2, z + 1.5, "hbarding")
    box(lo, f"{tag}_glow", x - 1.6, 6.6, z - 1.6, x + 1.6, 7.0, z + 1.6, "glow")
    box(lo, f"{tag}_hoof", x - 1.6, 0, z - 1.7, x + 1.6, 2.6, z + 1.7, "hoof")
leg("fl", 3.0, -7.0); leg("fr", -3.0, -7.0); leg("bl", 3.0, 8.0); leg("br", -3.0, 8.0)

# ---- rider
rider = grp("rider", (0, 28, 0), parent=rig)
box(rider, "pelvis", -4, 26.5, -2.5, 4, 30, 3, "armor")
box(rider, "belt", -4.3, 29.2, -2.8, 4.3, 30.4, 3.3, "leather")
box(rider, "belt_buckle", -1, 29.3, -3.2, 1, 30.3, -2.8, "glow")
box(rider, "chest", -4, 30, -2.5, 4, 38.5, 2.5, "armor")
box(rider, "chest_plate", -4.4, 31.2, -2.95, 4.4, 38, -2.4, "armor2")
box(rider, "chest_glow", -0.4, 31.4, -3.05, 0.4, 37.6, -2.9, "glow")
box(rider, "chest_ribs", -3.6, 33.2, -3.05, 3.6, 33.6, -2.95, "glow")
box(rider, "gorget", -3, 38.5, -2.3, 3, 40.2, 2.3, "armor2")
box(rider, "back_plate", -3.6, 31, 2.5, 3.6, 38, 3.0, "armor2")
for s, x in (("r", 1), ("l", -1)):
    xs = (5.6, 8.0) if x == 1 else (-8.0, -5.6)
    box(rider, f"thigh_{s}", xs[0], 25.5, -3.2, xs[1], 29.2, 3.2, "armor")
    box(rider, f"knee_{s}", xs[0] - 0.2, 24.8, -3.9, xs[1] + 0.2, 28.4, -2.6, "armor2")
    box(rider, f"shin_{s}", xs[0] + 0.1, 18.5, -3.4, xs[1] - 0.1, 25.2, -0.6, "armor")
    box(rider, f"boot_{s}", xs[0] - 0.2, 17.2, -3.9, xs[1] + 0.2, 21.2, 0.5, "armor2")
    box(rider, f"boot_glow_{s}", xs[0] - 0.3, 20.8, -4.0, xs[1] + 0.3, 21.4, 0.6, "glow")

rhead = grp("rider_head", (0, 39.5, 0), parent=rider)
box(rhead, "helm", -3.5, 39.5, -3.5, 3.5, 46.5, 3.5, "helm")
box(rhead, "helm_visor", -3.0, 41.4, -3.95, 3.0, 44.6, -3.45, "dark")
box(rhead, "eye_r", -2.5, 43.0, -4.05, -0.8, 43.9, -3.9, "glow")
box(rhead, "eye_l", 0.8, 43.0, -4.05, 2.5, 43.9, -3.9, "glow")
box(rhead, "brow", -3.8, 44.6, -3.9, 3.8, 45.6, -3.4, "armor2")
box(rhead, "chin", -2.6, 39.4, -3.8, 2.6, 41.0, -3.3, "armor2")
box(rhead, "crest", -0.5, 46.5, -3.2, 0.5, 49.5, 2.6, "armor2")
box(rhead, "crest_glow", -0.6, 47.0, -3.0, 0.6, 47.5, 2.4, "glow")
mirror_x(rhead, "helm_wing", 3.5, 41.2, -1.2, 4.2, 45.8, 2.0, "armor2")
mirror_x(rhead, "helm_wing_glow", 3.9, 43.2, -0.6, 4.4, 44.0, 1.6, "glow")

c1 = grp("cape1", (0, 38.2, 2.6), parent=rider)
box(c1, "cape1_c", -4.6, 30, 2.7, 4.6, 38.2, 3.5, "cloth")
box(c1, "cape1_trim", -4.8, 30, 2.6, -4.2, 38.2, 3.6, "glow")
box(c1, "cape1_trim_r", 4.2, 30, 2.6, 4.8, 38.2, 3.6, "glow")
c2 = grp("cape2", (0, 30, 3.1), (-72, 0, 0), parent=c1)
box(c2, "cape2_c", -4.9, 22, 2.7, 4.9, 30, 3.5, "cloth")
box(c2, "cape2_trim", -5.0, 22, 2.6, -4.4, 30, 3.6, "glow")
box(c2, "cape2_trim_r", 4.4, 22, 2.6, 5.0, 30, 3.6, "glow")
c3 = grp("cape3", (0, 22, 3.1), (-16, 0, 0), parent=c2)
box(c3, "cape3_c", -4.6, 14.5, 2.7, 4.6, 22, 3.5, "cloth")
box(c3, "cape3_hem", -4.7, 14.2, 2.6, 4.7, 15, 3.6, "glow")

# arms. right arm: free (animated). left arm: static IK pose holding the saddle prop
def arm(side, x):
    pauld = None
    u = grp(f"arm_{side}_u", (x, SY, 0), parent=rider)
    f = grp(f"arm_{side}_f", (x, SY - L1, 0), parent=u)
    h = grp(f"hand_{side}", (x, SY - L1 - L2, 0), parent=f)
    sg = 1 if x > 0 else -1
    box(u, f"pauldron_{side}", min(x - 2.6, x + 2.6) - (0.3 if sg < 0 else 0), 37.2, -2.6, max(x + 2.6, x - 2.6) + (0.3 if sg > 0 else 0), 40.0, 2.6, "armor2")
    box(u, f"pauldron_glow_{side}", x - 2.7, 36.9, -2.7, x + 2.7, 37.4, 2.7, "glow")
    box(u, f"arm_up_{side}", x - 1.6, SY - L1, -1.6, x + 1.6, 37.6, 1.6, "armor")
    box(f, f"arm_fore_{side}", x - 1.5, SY - L1 - L2 + 0.3, -1.5, x + 1.5, SY - L1 + 0.4, 1.5, "armor")
    box(f, f"vambrace_{side}", x - 1.8, SY - L1 - 3.2, -1.8, x + 1.8, SY - L1 - 1.0, 1.8, "armor2")
    box(f, f"elbow_{side}", x - 1.8, SY - L1 - 0.6, -1.8, x + 1.8, SY - L1 + 0.8, 1.8, "armor2")
    box(h, f"gauntlet_{side}", x - 1.4, SY - L1 - L2 - 2.0, -1.4, x + 1.4, SY - L1 - L2 + 0.4, 1.4, "armor2")
    box(h, f"gauntlet_glow_{side}", x - 1.5, SY - L1 - L2 + 0.0, -1.5, x + 1.5, SY - L1 - L2 + 0.35, 1.5, "glow")
    return u, f, h
au_r, af_r, h_r = arm("r", 7.0)
au_l, af_l, h_l = arm("l", -7.0)
# left arm static pose: hand at (z,y)
lr1, lr2, lrh = ik(-4.0, 31.0, 0)
au_l.rot = [ROT_SIGN * lr1, 0, 0]; af_l.rot = [ROT_SIGN * lr2, 0, 0]; h_l.rot = [ROT_SIGN * lrh, 0, 0]
# the saddle held by the knight (always in hand, hangs from the left gauntlet)
sp = grp("saddle_prop", (-7.0, 27.5, 0), parent=h_l)
box(sp, "prop_strap", -7.25, 25.4, -0.25, -6.75, 27.8, 0.25, "leather")
box(sp, "prop_seat", -9.6, 23.2, -2.6, -4.4, 25.4, 2.6, "saddle")
box(sp, "prop_pommel", -7.6, 25.4, -2.6, -6.4, 27.0, -1.4, "saddle")
box(sp, "prop_cantle", -8.6, 25.4, 1.4, -5.4, 26.8, 2.6, "saddle")
box(sp, "prop_glow", -9.7, 23.0, -2.7, -4.3, 23.4, 2.7, "glow")
box(sp, "prop_stirrup", -9.9, 20.8, -0.4, -9.3, 23.2, 0.4, "steel")

# sword parts, defined around a hilt-centre point H, blade pointing -y
def sword(parent, H, tag, with_blade=True):
    x, y, z = H
    box(parent, f"{tag}_pommel", x - 1.0, y + 2.0, z - 1.0, x + 1.0, y + 3.4, z + 1.0, "steel")
    box(parent, f"{tag}_grip", x - 0.7, y - 2.0, z - 0.7, x + 0.7, y + 2.1, z + 0.7, "leather")
    box(parent, f"{tag}_guard", x - 3.0, y - 3.2, z - 1.0, x + 3.0, y - 2.0, z + 1.0, "armor2")
    box(parent, f"{tag}_guard_glow", x - 3.1, y - 2.5, z - 1.1, x + 3.1, y - 2.2, z + 1.1, "glow")
    if with_blade:
        box(parent, f"{tag}_blade", x - 1.1, y - 17.2, z - 0.5, x + 1.1, y - 3.2, z + 0.5, "blade")
        box(parent, f"{tag}_blade_edge", x - 0.2, y - 17.2, z - 0.6, x + 0.2, y - 3.2, z + 0.6, "glow")
        box(parent, f"{tag}_blade_tip", x - 0.6, y - 18.4, z - 0.4, x + 0.6, y - 17.2, z + 0.4, "glow")
SWORD_X = 7.5
hand_origin = (7.0, SY - L1 - L2, 0.0)
sword_hand = grp("sword_hand", hand_origin, parent=h_r)
sword(sword_hand, (SWORD_X, SY - L1 - L2, 0.0), "sh")

# scabbard at right hip. hilt point P_SHEATH, tilted so the tip points slightly back
P_SH = (1.0, 29.5)           # (z, y) hand target for grasping the hilt
TH_SH = -15.0                # blade angle in the scabbard
scab = grp("scabbard", (SWORD_X, P_SH[1], P_SH[0]), (ROT_SIGN * TH_SH, 0, 0), parent=rider)
box(scab, "scab_body", SWORD_X - 1.7, P_SH[1] - 17.6, P_SH[0] - 1.0, SWORD_X + 1.7, P_SH[1] - 3.3, P_SH[0] + 1.0, "scab")
box(scab, "scab_mouth", SWORD_X - 1.9, P_SH[1] - 4.6, P_SH[0] - 1.2, SWORD_X + 1.9, P_SH[1] - 3.2, P_SH[0] + 1.2, "armor2")
box(scab, "scab_glow", SWORD_X - 1.9, P_SH[1] - 4.9, P_SH[0] - 1.25, SWORD_X + 1.9, P_SH[1] - 4.6, P_SH[0] + 1.25, "glow")
box(scab, "scab_chape", SWORD_X - 1.9, P_SH[1] - 19.4, P_SH[0] - 1.2, SWORD_X + 1.9, P_SH[1] - 17.4, P_SH[0] + 1.2, "armor2")
box(scab, "scab_strip", SWORD_X - 0.2, P_SH[1] - 17.4, P_SH[0] - 1.1, SWORD_X + 0.2, P_SH[1] - 5.0, P_SH[0] + 1.1, "glow")
sword_sheathed = grp("sword_sheathed", (SWORD_X, P_SH[1], P_SH[0]), parent=scab)
sword(sword_sheathed, (SWORD_X, P_SH[1], P_SH[0]), "ss")
box(rider, "belt_strap", 4.2, 28.6, -1.2, 8.4, 30.2, 1.2, "leather")    # hanger from belt to scabbard

# slash FX (crescent trail) - hidden except during the slash animation
fx = grp("slash_fx", (7.2, SY, 0), parent=rider)
arc = []
for ang in (55, 85, 115, 145, 172):
    arc.append([7.2, SY - 1.5 - 12.5 * math.cos(math.radians(ang)), -12.5 * math.sin(math.radians(ang))])
for i in range(len(arc) - 1):
    segment(fx, f"fx_{i}", arc[i], arc[i + 1], 1.0, 0.9 + 0.5 * (i % 3 == 1), "fx")

# reins: rider-left-hand -> M (child of rider) ; M -> bridle ring (child of head)
hand_l_w = to_world(h_l, (-7.0, SY - L1 - L2 + 0.5, 0.0))
ring_w = to_world(head, (-3.0, 32.0, -7.6))
M = [(hand_l_w[i] + ring_w[i]) / 2 for i in range(3)]; M[1] -= 1.3
segment(rider, "rein_a", hand_l_w, M, 0.7, 0.7, "rein")
box(rider, "rein_knot", hand_l_w[0] - 1.0, hand_l_w[1] - 1.0, hand_l_w[2] - 1.0, hand_l_w[0] + 1.0, hand_l_w[1] + 1.0, hand_l_w[2] + 1.0, "glow")
segment(head, "rein_b", to_local(head, M), (-3.0, 32.0, -7.6), 0.7, 0.7, "rein")

# ================================================================= ANIMATIONS
ARMED_POSE = (-7.5, 36.0, 140.0)       # (z, y, blade angle) ready stance
REST_POSE = (-3.0, 29.0, -10.0)
SWAP_DT = 0.05

class Anim:
    def __init__(s, name, length, loop):
        s.name, s.length, s.loop = name, length, loop
        s.tracks = {}      # (bone, channel) -> [(t, (x,y,z))]
    def key(s, bone, ch, t, v):
        s.tracks.setdefault((bone, ch), []).append((round(t, 4), tuple(v)))
    def finish(s):
        for k in s.tracks: s.tracks[k].sort(key=lambda a: a[0])

def tau(): return 2 * math.pi
def sample(anim, bone, ch, fn, n, dur=None):
    dur = dur or anim.length
    for i in range(n + 1):
        t = dur * i / n
        anim.key(bone, ch, t, fn(t))

def sword_state(a, state, swap_t=None):
    """state: 'sheathed' | 'armed' | 'draw' | 'sheathe'. visibility via scale keyframes."""
    HID, VIS = 0.001, 1.0
    def vis(bone, v0, v1=None):
        if swap_t is None:
            a.key(bone, "scale", 0, (v0, v0, v0))
        else:
            a.key(bone, "scale", 0, (v0, v0, v0)); a.key(bone, "scale", swap_t, (v0, v0, v0))
            a.key(bone, "scale", swap_t + SWAP_DT, (v1, v1, v1))
    if state == "sheathed":  vis("sword_hand", HID); vis("sword_sheathed", VIS)
    elif state == "armed":   vis("sword_hand", VIS); vis("sword_sheathed", HID)
    elif state == "draw":    vis("sword_hand", HID, VIS); vis("sword_sheathed", VIS, HID)
    elif state == "sheathe": vis("sword_hand", VIS, HID); vis("sword_sheathed", HID, VIS)

def fx_visible(a, spans):
    if not spans: a.key("slash_fx", "scale", 0, (0.001,) * 3); return
    a.key("slash_fx", "scale", 0, (0.001,) * 3)
    for (t0, t1) in spans:
        a.key("slash_fx", "scale", t0, (0.001,) * 3); a.key("slash_fx", "scale", t0 + 0.04, (1, 1, 1))
        a.key("slash_fx", "scale", t1, (1, 1, 1)); a.key("slash_fx", "scale", t1 + 0.08, (0.001,) * 3)

def arm_key(a, t, pose):
    r1, r2, rh = ik(*pose)
    a.key("arm_r_u", "rotation", t, (ROT_SIGN * r1, 0, 0))
    a.key("arm_r_f", "rotation", t, (ROT_SIGN * r2, 0, 0))
    a.key("hand_r", "rotation", t, (ROT_SIGN * rh, 0, 0))

def X(v): return (ROT_SIGN * v, 0, 0)

def base_idle(a):
    T = a.length
    s = lambda t, ph=0: math.sin(tau() * t / T + ph)
    sample(a, "horse_body", "position", lambda t: (0, 0.35 * s(t), 0), 8)
    sample(a, "rider", "position", lambda t: (0, 0.35 * s(t), 0), 8)
    sample(a, "rider", "rotation", lambda t: X(0.8 * s(t, 0.6)), 8)
    sample(a, "neck", "rotation", lambda t: X(2.5 * s(t, 0.3)), 8)
    sample(a, "head", "rotation", lambda t: X(2.0 * s(t, 1.1)), 8)
    sample(a, "tail", "rotation", lambda t: (ROT_SIGN * 3 * s(t, 0.5), 8 * s(t, 0.0), 0), 8)
    for i, b in enumerate(("cape1", "cape2", "cape3")):
        sample(a, b, "rotation", lambda t, i=i: X((2 + 2.5 * i) * s(t, 0.5 + 0.7 * i)), 8)
    sample(a, "rein_a", "rotation", lambda t: (0, 0, 1.5 * s(t, 0.2)), 8)
    sample(a, "fl_u", "rotation", lambda t: X(0.0), 2)
    # occasional paw of the front leg
    a.key("fr_u", "rotation", 0, X(0)); a.key("fr_u", "rotation", 2.6, X(0)); a.key("fr_u", "rotation", 2.9, X(-14))
    a.key("fr_u", "rotation", 3.2, X(0)); a.key("fr_u", "rotation", T, X(0))
    a.key("fr_l", "rotation", 0, X(0)); a.key("fr_l", "rotation", 2.6, X(0)); a.key("fr_l", "rotation", 2.9, X(-28))
    a.key("fr_l", "rotation", 3.2, X(0)); a.key("fr_l", "rotation", T, X(0))

def base_run(a):
    T = a.length
    ph = {"fl": 0.0, "fr": 0.12, "bl": 0.50, "br": 0.62}
    for leg, p in ph.items():
        sample(a, f"{leg}_u", "rotation", lambda t, p=p: X(42 * math.sin(tau() * (t / T + p))), 12)
        sample(a, f"{leg}_l", "rotation", lambda t, p=p: X(-58 * max(0.0, math.sin(tau() * (t / T + p) - 0.5))), 12)
    bob = lambda t: abs(math.sin(tau() * (t / T)))
    sample(a, "horse_body", "position", lambda t: (0, 1.6 * bob(t) - 0.6, 0), 12)
    sample(a, "rider", "position", lambda t: (0, 1.6 * bob(t) - 0.6, 0), 12)
    sample(a, "rig", "rotation", lambda t: X(3.5 * math.sin(tau() * (t / T) + 0.8)), 12)
    sample(a, "rider", "rotation", lambda t: X(-9 + 2 * math.sin(tau() * (t / T) + 2.0)), 12)
    sample(a, "neck", "rotation", lambda t: X(-6 + 6 * math.sin(tau() * (t / T) + 0.4)), 12)
    sample(a, "head", "rotation", lambda t: X(-3 + 4 * math.sin(tau() * (t / T) + 1.0)), 12)
    sample(a, "tail", "rotation", lambda t: X(-26 + 8 * math.sin(tau() * (t / T) * 2)), 12)
    sample(a, "cape1", "rotation", lambda t: X(-6 + 3 * math.sin(tau() * (t / T) * 2)), 12)
    sample(a, "cape2", "rotation", lambda t: X(-30 + 9 * math.sin(tau() * (t / T) * 2 + 0.7)), 12)
    sample(a, "cape3", "rotation", lambda t: X(-18 + 13 * math.sin(tau() * (t / T) * 2 + 1.5)), 12)
    sample(a, "rein_a", "rotation", lambda t: (0, 0, 3 * math.sin(tau() * (t / T) * 2)), 12)

ANIMS = []
def mk(name, length, loop, builder):
    a = Anim(name, length, loop); builder(a); a.finish(); ANIMS.append(a); return a

def A_idle(a):  base_idle(a); arm_key(a, 0, REST_POSE); arm_key(a, a.length, REST_POSE); sword_state(a, "sheathed"); fx_visible(a, [])
def A_run(a):   base_run(a);  arm_key(a, 0, REST_POSE); arm_key(a, a.length, REST_POSE); sword_state(a, "sheathed"); fx_visible(a, [])
def A_idle_armed(a): base_idle(a); arm_key(a, 0, ARMED_POSE); arm_key(a, a.length, ARMED_POSE); sword_state(a, "armed"); fx_visible(a, [])
def A_run_armed(a):  base_run(a);  arm_key(a, 0, ARMED_POSE); arm_key(a, a.length, ARMED_POSE); sword_state(a, "armed"); fx_visible(a, [])

# ---- draw: hand to hilt, grasp, pull out along blade axis, sweep to ready
def draw_path():
    pts = []                      # (t, (z,y,ths))
    pts.append((0.00, (REST_POSE[0], REST_POSE[1], TH_SH)))
    pts.append((0.12, (-1.0, 29.0, TH_SH)))
    pts.append((0.25, (P_SH[0], P_SH[1], TH_SH)))          # grasp -> swap
    ax = (-math.sin(math.radians(TH_SH)) * -1, 0)         # blade direction (z,y)=(-sin,-cos)
    bz, by = -math.sin(math.radians(TH_SH)), -math.cos(math.radians(TH_SH))
    for i, d in enumerate((2.5, 5.5, 8.5, 11.0), 1):       # pull = move opposite to blade direction
        pts.append((0.25 + 0.07 * i, (P_SH[0] - bz * d, P_SH[1] - by * d, TH_SH)))
    top = pts[-1][1]
    for i in (1, 2, 3, 4):
        f = i / 4.0; e = f * f * (3 - 2 * f)
        pts.append((0.53 + 0.09 * i, (top[0] + (ARMED_POSE[0] - top[0]) * e, top[1] + (ARMED_POSE[1] - top[1]) * e,
                                      TH_SH + (ARMED_POSE[2] - TH_SH) * e)))
    return pts
def A_draw(a):
    base_idle_light(a)
    for t, p in draw_path(): arm_key(a, t, p)
    sword_state(a, "draw", swap_t=0.25); fx_visible(a, [])
def A_sheathe(a):
    base_idle_light(a)
    p = draw_path(); T = a.length
    # reverse the draw path; slower insertion
    rev = [(T * (1 - (t / p[-1][0])) , pose) for t, pose in p]
    # custom timing: sweep 0.45s, insert 0.7s, release 0.3s
    seq = p[::-1]
    times = []
    n = len(seq)
    sweep_n = 5; ins_n = 5
    tt = 0.0
    out = []
    for i, (_, pose) in enumerate(seq):
        if i == 0: tt = 0.0
        elif i <= sweep_n - 0: tt += 0.11
        elif i <= sweep_n + ins_n - 1: tt += 0.15
        else: tt += 0.10
        out.append((tt, pose))
    for t, pose in out: arm_key(a, t, pose)
    end = out[-1][0]
    swap_t = out[[i for i, (_, ps) in enumerate(out) if abs(ps[0] - P_SH[0]) < 1e-6 and abs(ps[1] - P_SH[1]) < 1e-6][0]][0]
    arm_key(a, end + 0.35, REST_POSE)
    a.length = round(end + 0.4, 2)
    sword_state(a, "sheathe", swap_t=swap_t); fx_visible(a, [])
def base_idle_light(a):
    T = max(a.length, 0.01)
    # keep the body in a gentle idle pose through the one-shot animations
    sample(a, "horse_body", "position", lambda t: (0, 0.2, 0), 1)
    sample(a, "rider", "position", lambda t: (0, 0.2, 0), 1)
    sample(a, "cape2", "rotation", lambda t: X(4 * math.sin(t * 5)), 8, 1.0)
    sample(a, "tail", "rotation", lambda t: (0, 8 * math.sin(t * 4), 0), 8, 1.0)

def A_slash(a):
    T = a.length
    pts = [(0.00, ARMED_POSE), (0.18, (-3.0, 29.5, 62)), (0.27, (-2.6, 29.0, 55)),
           (0.34, (-7.0, 31.0, 92)), (0.40, (-9.8, 35.0, 128)), (0.46, (-8.6, 41.0, 168)),
           (0.55, (-6.4, 41.6, 176)), (0.68, (-6.8, 38.5, 158)), (T, ARMED_POSE)]
    for t, p in pts: arm_key(a, t, p)
    # body follows the strike
    a.key("rider", "rotation", 0, X(0)); a.key("rider", "rotation", 0.22, X(7)); a.key("rider", "rotation", 0.42, X(-12))
    a.key("rider", "rotation", 0.6, X(-6)); a.key("rider", "rotation", T, X(0))
    a.key("neck", "rotation", 0, X(0)); a.key("neck", "rotation", 0.22, X(-6)); a.key("neck", "rotation", 0.44, X(9)); a.key("neck", "rotation", T, X(0))
    a.key("fl_u", "rotation", 0, X(0)); a.key("fl_u", "rotation", 0.3, X(-18)); a.key("fl_u", "rotation", 0.45, X(32)); a.key("fl_u", "rotation", T, X(0))
    a.key("fr_u", "rotation", 0, X(0)); a.key("fr_u", "rotation", 0.3, X(-14)); a.key("fr_u", "rotation", 0.45, X(28)); a.key("fr_u", "rotation", T, X(0))
    a.key("cape2", "rotation", 0, X(0)); a.key("cape2", "rotation", 0.45, X(-24)); a.key("cape2", "rotation", T, X(0))
    sword_state(a, "armed"); fx_visible(a, [(0.34, 0.5)])

def A_hurt(a, armed):
    T = a.length
    a.key("rider", "rotation", 0, X(0)); a.key("rider", "rotation", 0.07, X(15)); a.key("rider", "rotation", 0.2, X(-4)); a.key("rider", "rotation", T, X(0))
    a.key("rider", "position", 0, (0, 0, 0)); a.key("rider", "position", 0.07, (0, 0, 1.4)); a.key("rider", "position", T, (0, 0, 0))
    a.key("horse_body", "position", 0, (0, 0, 0)); a.key("horse_body", "position", 0.07, (0, 0.4, 1.0)); a.key("horse_body", "position", T, (0, 0, 0))
    a.key("neck", "rotation", 0, X(0)); a.key("neck", "rotation", 0.07, X(-14)); a.key("neck", "rotation", T, X(0))
    a.key("head", "rotation", 0, X(0)); a.key("head", "rotation", 0.07, X(-10)); a.key("head", "rotation", T, X(0))
    a.key("tail", "rotation", 0, X(0)); a.key("tail", "rotation", 0.1, X(-30)); a.key("tail", "rotation", T, X(0))
    a.key("fl_u", "rotation", 0, X(0)); a.key("fl_u", "rotation", 0.1, X(-30)); a.key("fl_u", "rotation", T, X(0))
    a.key("fl_l", "rotation", 0, X(0)); a.key("fl_l", "rotation", 0.1, X(-45)); a.key("fl_l", "rotation", T, X(0))
    a.key("cape2", "rotation", 0, X(0)); a.key("cape2", "rotation", 0.1, X(-22)); a.key("cape2", "rotation", T, X(0))
    pose = ARMED_POSE if armed else REST_POSE
    arm_key(a, 0, pose); arm_key(a, T, pose)
    sword_state(a, "armed" if armed else "sheathed"); fx_visible(a, [])

mk("idle", 4.0, "loop", A_idle)
mk("run", 0.6, "loop", A_run)
mk("idle_armed", 4.0, "loop", A_idle_armed)
mk("run_armed", 0.6, "loop", A_run_armed)
mk("draw_sword", 0.98, "once", A_draw)
mk("slash_up", 0.8, "once", A_slash)
mk("sheathe", 1.5, "once", A_sheathe)
mk("hurt", 0.4, "once", lambda a: A_hurt(a, False))
mk("hurt_armed", 0.4, "once", lambda a: A_hurt(a, True))

# ================================================================= TEXTURE
def pack_cubes():
    cubes = []
    def walk(n):
        for c in n.children:
            if isinstance(c, C): cubes.append(c)
            else: walk(c)
    walk(root)
    items = []
    for c in cubes:
        w, h, d = [max(1, math.ceil(abs(c.b[i] - c.a[i]) + 2 * c.inf - 1e-6)) for i in range(3)]
        items.append((c, w, h, d, 2 * (w + d), h + d))
    items.sort(key=lambda it: -it[5])
    x = y = rowh = 0; placed = {}
    for it in items:
        c, w, h, d, W, H = it
        if x + W > TEX: x = 0; y += rowh; rowh = 0
        placed[c.uuid] = (x, y, w, h, d); x += W; rowh = max(rowh, H)
        if y + H > TEX: raise SystemExit("texture overflow: raise TEX")
    return cubes, placed

def faces_of(x, y, w, h, d):
    return {"north": (x + d, y + d, x + d + w, y + d + h), "east": (x, y + d, x + d, y + d + h),
            "south": (x + 2 * d + w, y + d, x + 2 * d + 2 * w, y + d + h), "west": (x + d + w, y + d, x + 2 * d + w, y + d + h),
            "up": (x + d, y, x + d + w, y + d), "down": (x + d + w, y, x + d + 2 * w, y + d)}

def paint(cubes, placed):
    img = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 0)); px = img.load()
    avg = {}
    for c in cubes:
        x, y, w, h, d = placed[c.uuid]
        base, edge = PAL[c.mat]
        for fname, (x0, y0, x1, y1) in faces_of(x, y, w, h, d).items():
            for yy in range(y0, y1):
                for xx in range(x0, x1):
                    v = rnd.randint(-5, 5) if c.mat not in ("glow", "fx", "dark") else rnd.randint(-8, 8)
                    col = [max(0, min(255, base[i] + v)) for i in range(3)]
                    border = (xx in (x0, x1 - 1) or yy in (y0, y1 - 1)) and (x1 - x0 > 2 and y1 - y0 > 2)
                    if border and c.mat not in ("dark",):
                        col = [int(col[i] * 0.55 + edge[i] * 0.45) for i in range(3)]
                    if c.mat in ("horse", "hbarding", "cloth", "armor", "armor2", "helm") and fname in ("up", "north") and yy == y0 + 1:
                        col = [min(255, col[i] + 10) for i in range(3)]
                    px[xx, yy] = tuple(col) + (255,)
        # bright accents
        if c.name.startswith("eye_") or c.name == "helm_visor":
            pass
    # blue rune dots on armor plates
    for c in cubes:
        if c.mat in ("armor2", "hbarding") and c.name.endswith(("plate", "armor", "pauldron_r", "pauldron_l", "crupper")):
            x, y, w, h, d = placed[c.uuid]
            fx0, fy0, fx1, fy1 = faces_of(x, y, w, h, d)["north"]
            for k in range(0, max(1, (fx1 - fx0) // 3)):
                if fx0 + 1 + 3 * k < fx1 - 1 and fy0 + 2 < fy1 - 1: px[fx0 + 1 + 3 * k, fy0 + 2] = (110, 190, 255, 255)
    return img

# ================================================================= EXPORT .bbmodel
def ang(v): return [v[0], v[1], v[2]]
def cube_json(c, placed):
    x, y, w, h, d = placed[c.uuid]
    f = {k: {"uv": list(v), "texture": 0} for k, v in faces_of(x, y, w, h, d).items()}
    return {"name": c.name, "type": "cube", "uuid": c.uuid, "box_uv": True, "rescale": False, "locked": False,
            "from": [round(v, 3) for v in c.a], "to": [round(v, 3) for v in c.b], "autouv": 0, "color": 0,
            "inflate": c.inf, "origin": [0, 0, 0], "rotation": [0, 0, 0], "uv_offset": [x, y], "faces": f}
def outliner(g):
    return {"name": g.name, "origin": [round(v, 3) for v in g.origin], "rotation": ang(g.rot), "color": 0,
            "uuid": g.uuid, "export": True, "isOpen": True, "locked": False, "visibility": True, "autouv": 0,
            "children": [outliner(c) if isinstance(c, G) else c.uuid for c in g.children]}
def anim_json(a):
    animators = {}
    for (bone, ch), keys in a.tracks.items():
        g = ALL_G[bone]
        an = animators.setdefault(g.uuid, {"name": bone, "type": "bone", "keyframes": []})
        for t, v in keys:
            an["keyframes"].append({"channel": ch, "data_points": [{"x": round(v[0], 4), "y": round(v[1], 4), "z": round(v[2], 4)}],
                                    "uuid": uid("kf"), "time": t, "color": -1,
                                    "interpolation": "linear" if ch == "scale" else "catmullrom"})
    return {"uuid": uid("anim"), "name": a.name, "loop": a.loop, "override": False, "length": a.length,
            "snapping": 20, "selected": False, "anim_time_update": "", "blend_weight": "", "start_delay": "", "loop_delay": "",
            "animators": animators}

def export():
    cubes, placed = pack_cubes()
    img = paint(cubes, placed)
    buf = io.BytesIO(); img.save(buf, "PNG"); png = buf.getvalue()
    os.makedirs(OUT, exist_ok=True)
    img.save(os.path.join(OUT, "blue_phantom_rider.png"))
    model = {"meta": {"format_version": "4.10", "model_format": "free", "box_uv": True},
             "name": "blue_phantom_rider", "model_identifier": "blue_phantom_rider", "visible_box": [1, 1, 0],
             "variable_placeholders": "", "variable_placeholder_buttons": [],
             "timeline_setups": [], "unhandled_root_fields": {},
             "resolution": {"width": TEX, "height": TEX},
             "elements": [cube_json(c, placed) for c in cubes],
             "outliner": [outliner(root)],
             "textures": [{"path": "", "name": "blue_phantom_rider.png", "folder": "", "namespace": "", "id": "0",
                           "particle": False, "render_mode": "default", "render_sides": "auto", "frame_time": 1,
                           "frame_order_type": "loop", "frame_order": "", "frame_interpolate": False, "visible": True,
                           "internal": True, "saved": False, "uuid": uid("tex"), "width": TEX, "height": TEX,
                           "uv_width": TEX, "uv_height": TEX,
                           "source": "data:image/png;base64," + base64.b64encode(png).decode()}],
             "animations": [anim_json(a) for a in ANIMS]}
    with open(os.path.join(OUT, "blue_phantom_rider.bbmodel"), "w") as fh: json.dump(model, fh, separators=(",", ":"))
    info = {"model": "blue_phantom_rider", "cubes": len(cubes), "groups": len(ALL_G),
            "animations": {a.name: {"length": a.length, "loop": a.loop} for a in ANIMS}}
    with open(os.path.join(OUT, "model-info.json"), "w") as fh: json.dump(info, fh, indent=2)
    return cubes, placed, img, info

# ================================================================= PREVIEW RENDERER
def eval_pose(a, t):
    pose = {}
    for (bone, ch), keys in a.tracks.items():
        if t <= keys[0][0]: v = keys[0][1]
        elif t >= keys[-1][0]: v = keys[-1][1]
        else:
            for i in range(len(keys) - 1):
                if keys[i][0] <= t <= keys[i + 1][0]:
                    t0, v0 = keys[i]; t1, v1 = keys[i + 1]
                    f = 0 if t1 == t0 else (t - t0) / (t1 - t0)
                    v = tuple(v0[k] + (v1[k] - v0[k]) * f for k in range(3)); break
        pose.setdefault(bone, {})[ch] = v if ch != "scale" else v[0]
    return pose

def render(cubes, placed, img, pose, yaw, size=(360, 420), scale=7.0):
    W, H = size; im = Image.new("RGB", size, (24, 26, 34)); dr = ImageDraw.Draw(im)
    ty = math.radians(yaw); cy, sy_ = math.cos(ty), math.sin(ty)
    polys = []
    px = img.load()
    for c in cubes:
        scl = pose.get(c.parent.name, {}).get("scale", 1.0) if isinstance(c.parent, G) else 1.0
        # hide whole subtree if any ancestor scale ~0
        hidden = False; n = c.parent
        while n is not None:
            if pose.get(n.name, {}).get("scale", 1.0) < 0.01: hidden = True
            n = n.parent
        if hidden: continue
        x, y, w, h, d = placed[c.uuid]
        fr = faces_of(x, y, w, h, d)
        a, b = c.a, c.b
        corners = {(i, j, k): (b[0] if i else a[0], b[1] if j else a[1], b[2] if k else a[2]) for i in (0, 1) for j in (0, 1) for k in (0, 1)}
        wc = {k: to_world(c.parent, v, pose) for k, v in corners.items()}
        def P(k):
            X_, Y_, Z_ = wc[k]
            xr = X_ * cy + Z_ * sy_; zr = -X_ * sy_ + Z_ * cy
            return (W / 2 + xr * scale, H - 25 - Y_ * scale), zr
        defs = {"north": [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)], "south": [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)],
                "west": [(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)], "east": [(1, 0, 0), (1, 0, 1), (1, 1, 1), (1, 1, 0)],
                "up": [(0, 1, 0), (1, 1, 0), (1, 1, 1), (0, 1, 1)], "down": [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)]}
        for fname, idx in defs.items():
            pts = [P(i) for i in idx]
            u0, v0, u1, v1 = fr[fname]
            col = px[(u0 + u1) // 2, (v0 + v1) // 2][:3] if u1 > u0 and v1 > v0 else (80, 80, 80)
            light = {"up": 1.15, "north": 1.0, "south": 0.8, "east": 0.9, "west": 0.9, "down": 0.6}[fname]
            col = tuple(min(255, int(v * light + 6)) for v in col)
            depth = sum(p[1] for p in pts) / 4
            # backface test
            (x0_, y0_), (x1_, y1_), (x2_, y2_) = pts[0][0], pts[1][0], pts[2][0]
            cross = (x1_ - x0_) * (y2_ - y0_) - (y1_ - y0_) * (x2_ - x0_)
            polys.append((depth, [p[0] for p in pts], col, cross))
    polys.sort(key=lambda p: p[0])
    for depth, pts, col, cross in polys:
        dr.polygon(pts, fill=col)
    return im

if __name__ == "__main__":
    cubes, placed, img, info = export()
    print(json.dumps(info, indent=1))
    if "--preview" in sys.argv:
        rows = [("idle", 0.0), ("idle_armed", 0.0), ("draw_sword", 0.25), ("draw_sword", 0.46), ("draw_sword", 0.98),
                ("slash_up", 0.18), ("slash_up", 0.40), ("slash_up", 0.46), ("sheathe", 0.6), ("run_armed", 0.15)]
        A = {a.name: a for a in ANIMS}
        sheet = Image.new("RGB", (360 * 5, 420 * 2))
        for i, (n, t) in enumerate(rows):
            im = render(cubes, placed, img, eval_pose(A[n], t), 70 if i % 2 == 0 else 125)
            ImageDraw.Draw(im).text((8, 8), f"{n} t={t}", fill=(255, 255, 255))
            sheet.paste(im, ((i % 5) * 360, (i // 5) * 420))
        sheet.save(os.path.join(OUT, "preview_sheet.png"))
