# Resource pack slot

* `pack.mcmeta` (pack_format 75 = Minecraft 1.21.11 - verify with your client; change if it complains) + `assets/` with the
  Blue Phantom Rider textures (`blue_phantom_rider.png`, emissive mask `_e.png`).
* **BetterModel builds its own pack from `plugins/BetterModel/models/*.bbmodel`** (textures are embedded in the .bbmodel).
  If you use BetterModel's pack hosting you do NOT need this zip - keep `resource-pack.enabled: false`.
* If you want this plugin to deliver a pack (yours, merged, or this one):
  1. Put the zip in `plugins/IronGolemCosmetics/resourcepack/` (the same folder is created on first start).
  2. config.yml -> `resource-pack.enabled: true`, `mode: self-host`, `file: <your zip name>`,
     `host.public-address: <your server IP/domain>`, open `host.port` (default 8765/TCP).
  3. `/golemskins reload`, then `/golemskins pack` shows the download URL.
