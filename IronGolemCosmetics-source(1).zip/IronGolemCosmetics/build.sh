#!/usr/bin/env bash
# Builds target/IronGolemCosmetics.jar. Needs JDK 21+ and Maven and an internet connection.
set -e
java -version; mvn -version
mvn -DskipTests clean package
echo "Plugin: target/IronGolemCosmetics.jar"
