# IronGolemCosmetics — راهنمای نصب و استفاده

پلاگین Paper (Minecraft **1.21.11**) برای فروش و انتخاب اسکین گولم آهنی در **Screaming BedWars**، با پول دائمی سرور از طریق **Vault** و مدل‌های سه‌بعدی **BetterModel**.

> ⚠️ **وضعیت صادقانه:** این پروژه در محیط من **کامپایل نهایی و تست روی سرور واقعی نشده** (دسترسی به اینترنت/Maven/Paper API نداشتم). سورس از نظر نحوی با کامپایلر JDK بررسی شد، اما JAR نساخته‌ام. جزئیات در `docs/COMPATIBILITY_AND_TESTING.md`.

## ۱. چه چیزهایی لازم است
| مورد | توضیح |
|---|---|
| Paper 1.21.11 | Java 21 |
| Vault + یک پلاگین اقتصاد (مثلاً EssentialsX) | الزامی |
| Screaming BedWars | برای تشخیص بازیکنِ داخل مسابقه |
| BetterModel | برای نمایش مدل متحرک (بدون آن اسکین‌ها قابل خرید ولی بدون ظاهر سفارشی هستند) |

## ۲. ساخت JAR (روی کامپیوتر خودت)
> مهم برای 1.21.11: پروژه روی `paper-api 1.21.11` و **Java 21** تنظیم شده و `api-version: '1.21'` دارد (روی همه‌ی 1.21.x از جمله 1.21.11 لود می‌شود). JAR های قدیمی که با API/Java دیگر ساخته شده‌اند را استفاده نکن؛ از همین پروژه بساز.
> با `build.bat` (ویندوز) یا `build.sh` (لینوکس/مک) هم می‌توانی بسازی.
نیاز: JDK 21 و Maven و اینترنت.
```
mvn -DskipTests clean package
```
خروجی: `target/IronGolemCosmetics.jar`. اگر خطای کامپایل دیدی، متن کامل خطا را برایم بفرست تا اصلاح کنم.

## ۳. نصب
1. `IronGolemCosmetics.jar` را در `plugins/` بگذار (همراه Vault، اقتصاد، BedWars، BetterModel).
2. سرور را یک بار روشن کن. پلاگین فایل مدل `blue_phantom_rider.bbmodel` را خودش در `plugins/BetterModel/models/` کپی می‌کند (اگر نبود).
3. دستور `/bettermodel reload` را بزن و از نصب‌بودن مدل مطمئن شو.
4. `/golemskins info` را اجرا کن؛ باید Vault، BetterModel و BedWars را "ready/true" ببینی.
5. `/golemskins testgolem` یک گولم تستی کنارت می‌سازد تا مدل و انیمیشن‌ها را بدون مسابقه ببینی.

## ۴. Resource Pack
* BetterModel خودش pack را از روی `.bbmodel` می‌سازد (تکسچر داخل فایل است). بیشتر وقت‌ها به pack من نیاز نداری.
* **جایگاه Resource Pack:** پوشه‌ی `plugins/IronGolemCosmetics/resourcepack/`. zip را آنجا بگذار، در `config.yml` بخش `resource-pack` را فعال کن (`mode: self-host`، `host.public-address`، پورت 8765/TCP را باز کن) و `/golemskins reload` بزن. `/golemskins pack` آدرس دانلود را نشان می‌دهد.
* `resource-pack.zip` همراه پروژه: `pack.mcmeta` (pack_format 75 — اگر کلاینت اعتراض کرد عدد را مطابق نسخه‌ات تغییر بده) + تکسچرها.

## ۵. تغییر قیمت و اسکین‌ها
همه‌چیز در `plugins/IronGolemCosmetics/config.yml`، بخش `skins:`. هر اسکین: `enabled`، `price` (۰ = رایگان)، `display-name`، `description`، `icon`، `model`، `animations`. بعد از تغییر: `/golemskins reload`.
**اسکین جدید:** یک بلوک را کپی کن، id را عوض کن، فایل `.bbmodel` را در `plugins/BetterModel/models/` بگذار و نام آن را در `model:` بنویس. به کد دست نمی‌زنی. پیام‌ها در `messages.yml` هستند.

## ۶. دستورها
| دستور | کار |
|---|---|
| `/golemskins` (`/igc`, `/cosmetics`) | باز کردن منوی Iron Golem Cosmetics (`irongolemcosmetics.use`، پیش‌فرض همه) |
| `/golemskins reload` | بارگذاری مجدد config/messages/pack |
| `/golemskins list` | فهرست اسکین‌ها، قیمت و وضعیت |
| `/golemskins give\|take\|select <player> <skin>` | مدیریت مالکیت/انتخاب بدون پول |
| `/golemskins testgolem` | ساخت گولم تستی با اسکین خودت |
| `/golemskins anim <name>` | اجرای دستی یک انیمیشن روی نزدیک‌ترین گولمِ اسکین‌دار |
| `/golemskins info` / `pack` | وضعیت وابستگی‌ها / آدرس Resource Pack |
(همه‌ی زیردستورها: `irongolemcosmetics.admin`، پیش‌فرض OP)

## ۷. رفع خطای رایج
* **مدل دیده نمی‌شود:** `/golemskins info`؛ لاگ را برای پیام‌های `BetterModel` ببین؛ `/bettermodel reload`؛ pack برای بازیکن لود شده باشد.
* **اسکین روی گولم اعمال نمی‌شود:** `settings.debug: true`؛ در تست بدون BedWars از `testgolem` یا موقتاً `settings.apply-without-bedwars-api: true` استفاده کن. تشخیص «گولم مال کیست» heuristic است (docs را ببین).
* **خرید کار نمی‌کند:** Vault و یک پلاگین اقتصاد باید نصب باشند؛ `/golemskins info` → `Vault: true`.
* **حرکت‌ها برعکس است:** در `generator/build_blue_phantom_rider.py` مقدار `ROT_X_SIGN` را `-1` کن، اسکریپت را اجرا کن و `.bbmodel` جدید را جایگزین کن.

## ۸. ساختار پروژه
```
pom.xml                         Maven (Java 21, paper-api 1.21.11, VaultAPI، هر دو provided)
src/main/java/...               کد پلاگین      src/main/resources/ config.yml, messages.yml, plugin.yml, defaults/models/*.bbmodel
betterModel/ + generator/       مدل اصلی (Blockbench) و اسکریپت تولید آن (از کارهای قبلی)
alt-model/                      مدل جایگزین با اسکلت IK (نسخه‌ی آزمایشی، نصب نمی‌شود)
resource-pack/                  پوشه‌ی pack      legacy/  کپی دست‌نخورده‌ی Gradle قبلی      docs/  گزارش‌ها
```
