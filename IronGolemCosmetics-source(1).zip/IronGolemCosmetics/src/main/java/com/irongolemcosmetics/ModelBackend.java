package com.irongolemcosmetics;

import org.bukkit.entity.LivingEntity;

/** Abstraction over the model engine so the rest of the plugin never touches engine classes directly. */
public interface ModelBackend {
    String name();

    boolean available();

    /** Attach the named model to the entity; null if it could not be attached. */
    ModelHandle attach(LivingEntity entity, String modelId);
}
