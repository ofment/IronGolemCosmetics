package com.irongolemcosmetics;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** Message helper: messages.yml, '&' colour codes, {placeholders}, prefix. */
public final class Messages {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final IronGolemCosmeticsPlugin plugin;
    private YamlConfiguration cfg = new YamlConfiguration();

    public Messages(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File f = new File(plugin.getDataFolder(), "messages.yml");
        if (!f.isFile()) plugin.saveResource("messages.yml", false);
        cfg = YamlConfiguration.loadConfiguration(f);
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) cfg.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
        } catch (Exception ignored) {
            // defaults are optional
        }
    }

    public Component parse(String text) {
        return LEGACY.deserialize(text == null ? "" : text).decoration(TextDecoration.ITALIC, false);
    }

    public String raw(String key) {
        return cfg.getString(key, "&cMissing message: " + key);
    }

    public String format(String key, String... kv) {
        String s = raw(key);
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        return s;
    }

    public Component component(String key, String... kv) {
        return parse(format(key, kv));
    }

    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(parse(raw("prefix") + format(key, kv)));
    }

    public void sound(Player p, String soundKey) {
        String key = plugin.getConfig().getString("menu.sounds." + soundKey, "");
        if (key != null && !key.isBlank()) p.playSound(p.getLocation(), key, 0.8f, 1f);
    }
}
