package com.irongolemcosmetics;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /golemskins [reload|list|give|take|select|testgolem|anim|info|pack] */
public final class CosmeticsCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUB = List.of("reload", "list", "give", "take", "select", "testgolem", "anim", "info", "pack");
    private final IronGolemCosmeticsPlugin plugin;

    public CosmeticsCommand(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Messages msg = plugin.messages();
        if (args.length == 0) {
            if (!(sender instanceof Player p)) { msg.send(sender, "players-only"); return true; }
            if (!p.hasPermission("irongolemcosmetics.use")) { msg.send(sender, "no-permission"); return true; }
            new CosmeticsMenu(plugin, p).open();
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (!sender.hasPermission("irongolemcosmetics.admin")) { msg.send(sender, "no-permission"); return true; }
        switch (sub) {
            case "reload" -> { plugin.reloadAll(); msg.send(sender, "reloaded", "count", String.valueOf(plugin.skins().size())); }
            case "list" -> {
                for (Skin s : plugin.skins().all()) {
                    sender.sendMessage(msg.parse("&7- &f" + s.id() + " &8| " + (s.enabled() ? "&aon" : "&coff") + " &8| &6" + s.price() + " &8| &7" + (s.hasModel() ? s.model() : "(vanilla)")));
                }
            }
            case "give", "take", "select" -> {
                if (args.length < 3) { sender.sendMessage(msg.parse("&7/" + label + " " + sub + " <player> <skin>")); return true; }
                OfflinePlayer target = Bukkit.getPlayerExact(args[1]);
                if (target == null) target = Bukkit.getOfflinePlayerIfCached(args[1]);
                if (target == null) { msg.send(sender, "unknown-player", "player", args[1]); return true; }
                Skin skin = plugin.skins().get(args[2]);
                if (skin == null) { msg.send(sender, "unknown-skin", "skin", args[2]); return true; }
                switch (sub) {
                    case "give" -> plugin.purchases().grant(target.getUniqueId(), skin);
                    case "take" -> plugin.purchases().revoke(target.getUniqueId(), skin);
                    default -> {
                        plugin.purchases().grant(target.getUniqueId(), skin);
                        plugin.data().get(target.getUniqueId()).selected = skin.id();
                        plugin.data().save(target.getUniqueId());
                    }
                }
                sender.sendMessage(msg.parse("&aOK: " + sub + " " + skin.id() + " -> " + args[1]));
            }
            case "testgolem" -> {
                if (!(sender instanceof Player p)) { msg.send(sender, "players-only"); return true; }
                Skin eff = plugin.purchases().effectiveSkin(p.getUniqueId());
                if (eff == null || !eff.hasModel()) { msg.send(sender, "no-model-skin"); return true; }
                if (plugin.golems().spawnTest(p)) msg.send(sender, "test-spawned", "skin", eff.displayName());
                else sender.sendMessage(msg.parse("&cModel could not be attached - see the console."));
            }
            case "anim" -> {
                if (!(sender instanceof Player p) || args.length < 2) { sender.sendMessage(msg.parse("&7/" + label + " anim <animation> (stand within 12 blocks of a skinned golem)")); return true; }
                if (!plugin.golems().playOnNearest(p, args[1])) msg.send(sender, "no-golem-nearby");
            }
            case "info" -> {
                sender.sendMessage(msg.parse("&7Skins: &f" + plugin.skins().size() + " &7| model backend: &f" + plugin.models().name()
                        + " (" + (plugin.models().available() ? "ready" : "unavailable") + ") &7| BedWars hook: &f" + plugin.bedwars().available()
                        + " &7| Vault: &f" + plugin.economy().available() + " &7| skinned golems: &f" + plugin.golems().activeCount()));
            }
            case "pack" -> msg.send(sender, "pack-info", "info", plugin.pack().info());
            default -> sender.sendMessage(msg.parse("&7/" + label + " [reload|list|give|take|select|testgolem|anim|info|pack]"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("irongolemcosmetics.admin")) return out;
        if (args.length == 1) {
            for (String s : SUB) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && List.of("give", "take", "select").contains(args[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
        } else if (args.length == 3) {
            for (Skin s : plugin.skins().all()) if (s.id().startsWith(args[2].toLowerCase(Locale.ROOT))) out.add(s.id());
        }
        return out;
    }
}
