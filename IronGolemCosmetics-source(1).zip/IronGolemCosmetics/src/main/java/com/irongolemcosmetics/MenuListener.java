package com.irongolemcosmetics;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

/** Every interaction with the cosmetics GUI is cancelled; only explicit button handling runs. */
public final class MenuListener implements Listener {

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof CosmeticsMenu menu)) return;
        e.setCancelled(true);                       // covers shift-click, number keys, double-click collect, drops...
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        menu.handleClick(e.getRawSlot());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof CosmeticsMenu) e.setCancelled(true);
    }
}
