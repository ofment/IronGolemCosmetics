package com.irongolemcosmetics;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public final class IronGolemCosmeticsPlugin extends JavaPlugin implements Listener {

    private static final String[] BUNDLED_MODELS = {"blue_phantom_rider.bbmodel", "crimson_samurai_rider.bbmodel"};

    private Messages messages;
    private SkinRegistry skins;
    private PlayerDataStore data;
    private EconomyService economy;
    private PurchaseService purchases;
    private BedwarsBridge bedwars;
    private ModelBackend models = new NoModelBackend();
    private GolemSkinManager golems;
    private ResourcePackService pack;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);
        skins = new SkinRegistry(this);
        skins.load();
        data = new PlayerDataStore(this);
        economy = new EconomyService(this);
        purchases = new PurchaseService(this);
        bedwars = new BedwarsBridge(this);
        setupModels();

        golems = new GolemSkinManager(this);
        pack = new ResourcePackService(this);

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(new MenuListener(), this);
        Bukkit.getPluginManager().registerEvents(golems, this);
        Bukkit.getPluginManager().registerEvents(pack, this);
        golems.start();
        pack.start();

        PluginCommand cmd = getCommand("golemskins");
        if (cmd != null) {
            CosmeticsCommand handler = new CosmeticsCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
        if (!economy.available()) getLogger().warning("No Vault economy provider yet. Paid skins cannot be bought until one is registered.");
        getLogger().info("Enabled: " + skins.size() + " skins, model backend: " + models.name() + ".");
    }

    @Override
    public void onDisable() {
        if (golems != null) golems.shutdown();
        if (pack != null) pack.stop();
        if (data != null) data.shutdown();
    }

    /** /golemskins reload */
    public void reloadAll() {
        reloadConfig();
        messages.reload();
        skins.load();
        setupModels();
        pack.stop();
        pack.start();
    }

    private void setupModels() {
        String backend = getConfig().getString("models.backend", "bettermodel").toLowerCase();
        if (backend.equals("bettermodel")) {
            if (getConfig().getBoolean("models.auto-install-models", true)) installBundledModels();
            models = new BetterModelBackend(this);
        } else {
            models = new NoModelBackend();
        }
    }

    /** Copies bundled .bbmodel files into plugins/BetterModel/models if missing (never overwrites yours). */
    private void installBundledModels() {
        File bmModels = new File(getDataFolder().getParentFile(), "BetterModel/models");
        if (!bmModels.isDirectory() && !bmModels.mkdirs()) return;
        for (String name : BUNDLED_MODELS) {
            File target = new File(bmModels, name);
            if (target.exists()) continue;
            try (InputStream in = getResource("defaults/models/" + name)) {
                if (in == null) continue;
                Files.copy(in, target.toPath(), StandardCopyOption.REPLACE_EXISTING);
                getLogger().info("Installed " + name + " into plugins/BetterModel/models. Run /bettermodel reload once.");
            } catch (Exception e) {
                getLogger().warning("Could not install " + name + ": " + e.getMessage());
            }
        }
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (e.getLoginResult() == AsyncPlayerPreLoginEvent.Result.ALLOWED) data.get(e.getUniqueId());   // load off the main thread
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        data.unload(e.getPlayer().getUniqueId());
        CosmeticsMenu.forget(e.getPlayer().getUniqueId());
    }

    public Messages messages() { return messages; }
    public SkinRegistry skins() { return skins; }
    public PlayerDataStore data() { return data; }
    public EconomyService economy() { return economy; }
    public PurchaseService purchases() { return purchases; }
    public BedwarsBridge bedwars() { return bedwars; }
    public ModelBackend models() { return models; }
    public GolemSkinManager golems() { return golems; }
    public ResourcePackService pack() { return pack; }
}
