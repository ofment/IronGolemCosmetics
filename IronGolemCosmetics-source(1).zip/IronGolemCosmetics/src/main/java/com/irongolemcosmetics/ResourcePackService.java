package com.irongolemcosmetics;

import com.sun.net.httpserver.HttpServer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.io.File;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.UUID;

/**
 * Optional resource-pack delivery. The "slot" is plugins/IronGolemCosmetics/resourcepack/ - drop your zip there.
 * mode self-host : a tiny built-in HTTP server serves that zip (open the configured TCP port).
 * mode external  : players are sent the url/sha1 from config.yml.
 * If you use BetterModel's own pack generation/hosting, leave resource-pack.enabled=false.
 */
public final class ResourcePackService implements Listener {

    private final IronGolemCosmeticsPlugin plugin;
    private HttpServer server;
    private String url = "";
    private byte[] sha1 = new byte[0];
    private final UUID packId = UUID.nameUUIDFromBytes("IronGolemCosmetics-pack".getBytes());

    public ResourcePackService(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
    }

    public File folder() {
        File f = new File(plugin.getDataFolder(), "resourcepack");
        f.mkdirs();
        return f;
    }

    public void start() {
        folder();
        if (!plugin.getConfig().getBoolean("resource-pack.enabled", false)) return;
        String mode = plugin.getConfig().getString("resource-pack.mode", "self-host");
        try {
            if (mode.equalsIgnoreCase("external")) {
                url = plugin.getConfig().getString("resource-pack.url", "");
                String hex = plugin.getConfig().getString("resource-pack.sha1", "");
                sha1 = hex.isBlank() ? new byte[0] : hexToBytes(hex);
            } else {
                File zip = new File(folder(), plugin.getConfig().getString("resource-pack.file", "pack.zip"));
                if (!zip.isFile()) {
                    plugin.getLogger().warning("resource-pack.enabled but " + zip.getPath() + " does not exist.");
                    return;
                }
                byte[] bytes = Files.readAllBytes(zip.toPath());
                sha1 = MessageDigest.getInstance("SHA-1").digest(bytes);
                int port = plugin.getConfig().getInt("resource-pack.host.port", 8765);
                String bind = plugin.getConfig().getString("resource-pack.host.bind-address", "0.0.0.0");
                String pub = plugin.getConfig().getString("resource-pack.host.public-address", "");
                if (pub.isBlank()) plugin.getLogger().warning("resource-pack.host.public-address is empty - players cannot download the pack.");
                server = HttpServer.create(new InetSocketAddress(bind, port), 0);
                server.createContext("/pack.zip", ex -> {
                    ex.getResponseHeaders().add("Content-Type", "application/zip");
                    ex.sendResponseHeaders(200, bytes.length);
                    try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
                });
                server.start();
                url = "http://" + pub + ":" + port + "/pack.zip";
                plugin.getLogger().info("Serving resource pack at " + url);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Resource pack setup failed: " + e);
            url = "";
        }
    }

    public void stop() {
        if (server != null) { server.stop(0); server = null; }
        url = "";
    }

    public String info() {
        if (!plugin.getConfig().getBoolean("resource-pack.enabled", false)) return "disabled (folder: " + folder().getPath() + ")";
        return url.isBlank() ? "enabled but not ready (see console)" : url;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (url.isBlank()) return;
        Player p = e.getPlayer();
        p.setResourcePack(packId, url, sha1.length == 0 ? null : sha1,
                plugin.messages().parse(plugin.getConfig().getString("resource-pack.prompt", "")),
                plugin.getConfig().getBoolean("resource-pack.force", false));
    }

    private static byte[] hexToBytes(String s) {
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return out;
    }
}
