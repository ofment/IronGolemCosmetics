package com.irongolemcosmetics;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/** Paginated "Iron Golem Cosmetics" chest GUI. All state lives here; the listener only forwards clicks. */
public final class CosmeticsMenu implements InventoryHolder {

    private static final Map<UUID, Long> LAST_CLICK = new HashMap<>();

    private final IronGolemCosmeticsPlugin plugin;
    private final Player player;
    private final Inventory inv;
    private final int rows;
    private final List<Integer> skinSlots;
    private final int slotPrev, slotInfo, slotNext, slotDeselect, slotClose;
    private final Map<Integer, String> slotToSkin = new HashMap<>();
    private int page;

    public CosmeticsMenu(IronGolemCosmeticsPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.rows = Math.max(3, Math.min(6, plugin.getConfig().getInt("menu.rows", 6)));
        int size = rows * 9;
        this.skinSlots = loadSkinSlots(size);
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("menu.slots");
        this.slotPrev = clamp(s == null ? size - 6 : s.getInt("previous", size - 6), size);
        this.slotInfo = clamp(s == null ? size - 5 : s.getInt("info", size - 5), size);
        this.slotNext = clamp(s == null ? size - 4 : s.getInt("next", size - 4), size);
        this.slotDeselect = clamp(s == null ? size - 9 : s.getInt("deselect", size - 9), size);
        this.slotClose = clamp(s == null ? size - 1 : s.getInt("close", size - 1), size);
        Component title = plugin.messages().parse(plugin.getConfig().getString("menu.title", "Iron Golem Cosmetics"));
        this.inv = Bukkit.createInventory(this, size, title);
    }

    private static int clamp(int slot, int size) {
        return Math.max(0, Math.min(size - 1, slot));
    }

    private List<Integer> loadSkinSlots(int size) {
        List<Integer> configured = plugin.getConfig().getIntegerList("menu.skin-slots");
        List<Integer> out = new ArrayList<>();
        for (int slot : configured) if (slot >= 0 && slot < size && !out.contains(slot)) out.add(slot);
        if (!out.isEmpty()) return out;
        for (int r = 1; r < rows - 1; r++) for (int c = 1; c < 8; c++) out.add(r * 9 + c);   // inner area
        return out;
    }

    @Override
    public Inventory getInventory() { return inv; }

    public void open() {
        render();
        player.openInventory(inv);
    }

    private int pageCount(int skinCount) {
        return Math.max(1, (int) Math.ceil(skinCount / (double) skinSlots.size()));
    }

    public void render() {
        inv.clear();
        slotToSkin.clear();
        Material fillMat = Material.matchMaterial(plugin.getConfig().getString("menu.filler.material", "AIR"));
        if (fillMat != null && !fillMat.isAir()) {
            ItemStack filler = named(fillMat, Component.empty());
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        }
        List<Skin> skins = plugin.skins().enabled();
        int pages = pageCount(skins.size());
        page = Math.max(0, Math.min(page, pages - 1));
        int from = page * skinSlots.size();
        for (int i = 0; i < skinSlots.size() && from + i < skins.size(); i++) {
            Skin skin = skins.get(from + i);
            int slot = skinSlots.get(i);
            inv.setItem(slot, skinItem(skin));
            slotToSkin.put(slot, skin.id());
        }
        if (page > 0) inv.setItem(slotPrev, named(Material.ARROW, plugin.messages().component("menu-prev")));
        if (page < pages - 1) inv.setItem(slotNext, named(Material.ARROW, plugin.messages().component("menu-next")));
        ItemStack info = named(Material.EMERALD, plugin.messages().component("menu-info", "page", String.valueOf(page + 1), "pages", String.valueOf(pages)));
        ItemMeta im = info.getItemMeta();
        im.lore(List.of(plugin.messages().component("menu-info-balance", "balance", plugin.economy().format(plugin.economy().balance(player)))));
        info.setItemMeta(im);
        inv.setItem(slotInfo, info);
        ItemStack deselect = named(Material.RED_DYE, plugin.messages().component("menu-deselect"));
        ItemMeta dm = deselect.getItemMeta();
        dm.lore(List.of(plugin.messages().component("menu-deselect-lore")));
        deselect.setItemMeta(dm);
        inv.setItem(slotDeselect, deselect);
        inv.setItem(slotClose, named(Material.BARRIER, plugin.messages().component("menu-close")));
    }

    private ItemStack named(Material m, Component name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack skinItem(Skin skin) {
        Messages msg = plugin.messages();
        PurchaseService ps = plugin.purchases();
        UUID id = player.getUniqueId();
        boolean owned = ps.owns(id, skin);
        boolean selected = ps.isSelected(id, skin);
        boolean purchasesOn = plugin.getConfig().getBoolean("settings.allow-purchase", true);
        ItemStack it = named(skin.icon(), msg.parse(skin.displayName()));
        ItemMeta meta = it.getItemMeta();
        List<Component> lore = new ArrayList<>();
        for (String line : skin.description()) lore.add(msg.parse(line));
        lore.add(Component.empty());
        String price = plugin.economy().format(skin.price());
        lore.add(msg.parse(skin.price() <= 0 ? msg.raw("price-free") : msg.format("price-line", "price", price)));
        lore.add(Component.empty());
        if (selected) {
            lore.add(msg.parse(msg.raw("status-selected")));
            meta.setEnchantmentGlintOverride(true);
        } else if (owned) {
            lore.add(msg.parse(msg.raw("status-owned")));
        } else if (!purchasesOn) {
            lore.add(msg.parse(msg.raw("status-locked")));
            lore.add(msg.parse(msg.raw("status-locked-disabled")));
        } else if (plugin.economy().available() && !plugin.economy().has(player, skin.price())) {
            lore.add(msg.parse(msg.raw("status-locked")));
            lore.add(msg.parse(msg.raw("status-locked-money")));
        } else {
            lore.add(msg.parse(msg.raw("status-purchase")));
        }
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    /** Called by MenuListener with the raw slot of a click in the top inventory. */
    public void handleClick(int slot) {
        long nowMs = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("menu.click-cooldown-ms", 200L);
        Long last = LAST_CLICK.get(player.getUniqueId());
        if (last != null && nowMs - last < cd) return;               // spam / double-click guard
        LAST_CLICK.put(player.getUniqueId(), nowMs);

        int pages = pageCount(plugin.skins().enabled().size());
        Messages msg = plugin.messages();
        if (slot == slotClose) {
            player.closeInventory();
            return;
        }
        if (slot == slotPrev && page > 0) { page--; msg.sound(player, "click"); render(); return; }
        if (slot == slotNext && page < pages - 1) { page++; msg.sound(player, "click"); render(); return; }
        if (slot == slotDeselect) {
            plugin.purchases().deselect(player);
            msg.send(player, "deselected");
            msg.sound(player, "click");
            render();
            return;
        }
        String skinId = slotToSkin.get(slot);
        if (skinId == null) return;
        Skin skin = plugin.skins().get(skinId);
        if (skin == null || !skin.enabled()) { msg.send(player, "skin-disabled"); msg.sound(player, "error"); render(); return; }
        PurchaseService ps = plugin.purchases();
        UUID id = player.getUniqueId();

        if (ps.isSelected(id, skin) && ps.owns(id, skin) && plugin.data().get(id).selected != null) {
            ps.deselect(player);                                       // click the selected skin again = unselect
            msg.send(player, "deselected");
            msg.sound(player, "click");
        } else if (ps.owns(id, skin)) {
            if (ps.select(player, skin) == PurchaseService.Result.SUCCESS) {
                msg.send(player, "selected", "skin", skin.displayName());
                msg.sound(player, "success");
            } else {
                msg.send(player, "not-owned");
                msg.sound(player, "error");
            }
        } else {
            PurchaseService.Result r = ps.purchase(player, skin);
            String price = plugin.economy().format(skin.price());
            switch (r) {
                case SUCCESS -> {
                    msg.send(player, "purchased", "skin", skin.displayName(), "price", price);
                    msg.sound(player, "success");
                    if (plugin.getConfig().getBoolean("settings.auto-select-after-purchase", true)) {
                        ps.select(player, skin);
                        msg.send(player, "selected", "skin", skin.displayName());
                    }
                }
                case NOT_ENOUGH_MONEY -> {
                    msg.send(player, "not-enough-money", "price", price, "balance", plugin.economy().format(plugin.economy().balance(player)));
                    msg.sound(player, "error");
                }
                case ALREADY_OWNED -> { msg.send(player, "already-owned"); msg.sound(player, "error"); }
                case DISABLED -> { msg.send(player, "skin-disabled"); msg.sound(player, "error"); }
                case PURCHASES_DISABLED -> { msg.send(player, "purchases-disabled"); msg.sound(player, "error"); }
                case BUSY -> msg.send(player, "busy");
                default -> { msg.send(player, "economy-error"); msg.sound(player, "error"); }
            }
        }
        render();
    }

    public static void forget(UUID id) { LAST_CLICK.remove(id); }
}
