package com.irongolemcosmetics;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Optional;
import java.util.logging.Level;

/**
 * BetterModel backend, reached through reflection so this plugin compiles and loads without the BetterModel jar
 * and keeps working if method names move between BetterModel versions. If a lookup fails, the log tells you
 * exactly which step failed - adjust the candidate names below (single place to fix).
 *
 * NOT VERIFIED against a live BetterModel install by the author. See docs/COMPATIBILITY_AND_TESTING.md.
 */
public final class BetterModelBackend implements ModelBackend {

    private static final String API_CLASS = "kr.toxicity.model.api.BetterModel";
    private static final String[] ADAPTER_CLASSES = {
            "kr.toxicity.model.api.bukkit.platform.BukkitAdapter",
            "kr.toxicity.model.api.platform.BukkitAdapter"
    };
    private static final String[] MODEL_LOOKUPS = {"modelOrNull", "model", "renderer", "getModel"};
    private static final String[] ANIMATION_MODIFIER_CLASSES = {
            "kr.toxicity.model.api.animation.AnimationModifier"
    };

    private final IronGolemCosmeticsPlugin plugin;
    private ClassLoader loader;
    private Class<?> api;
    private boolean available;
    private boolean warnedLookup;

    public BetterModelBackend(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
        Plugin bm = Bukkit.getPluginManager().getPlugin("BetterModel");
        if (bm == null) {
            plugin.getLogger().warning("BetterModel is not installed - skins will have no custom model.");
            return;
        }
        try {
            loader = bm.getClass().getClassLoader();
            api = Class.forName(API_CLASS, true, loader);
            available = true;
            plugin.getLogger().info("BetterModel " + bm.getPluginMeta().getVersion() + " found.");
        } catch (Throwable t) {
            plugin.getLogger().warning("BetterModel found, but " + API_CLASS + " could not be loaded (" + t + ").");
        }
    }

    @Override public String name() { return "BetterModel"; }

    @Override public boolean available() { return available; }

    @Override
    public ModelHandle attach(LivingEntity entity, String modelId) {
        if (!available) return null;
        try {
            Object renderer = findRenderer(modelId);
            if (renderer == null) {
                if (!warnedLookup) plugin.getLogger().warning("BetterModel has no model named '" + modelId
                        + "'. Put " + modelId + ".bbmodel in plugins/BetterModel/models/ and run /bettermodel reload.");
                warnedLookup = true;
                return null;
            }
            Object tracker = createTracker(renderer, entity);
            if (tracker == null) {
                plugin.getLogger().warning("Could not create a BetterModel tracker for '" + modelId
                        + "' (no compatible 'create' method). Adjust BetterModelBackend.createTracker.");
                return null;
            }
            return new Handle(tracker);
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Failed to attach model '" + modelId + "'", t);
            return null;
        }
    }

    private Object findRenderer(String id) throws Exception {
        for (String name : MODEL_LOOKUPS) {
            for (Method m : api.getMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != 1 || m.getParameterTypes()[0] != String.class) continue;
                Object target = Modifier.isStatic(m.getModifiers()) ? null : instanceOf(api);
                if (!Modifier.isStatic(m.getModifiers()) && target == null) continue;
                Object r = unwrap(m.invoke(target, id));
                if (r != null) return r;
            }
        }
        return null;
    }

    private Object instanceOf(Class<?> c) {
        try {
            return c.getField("INSTANCE").get(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private Object createTracker(Object renderer, Entity entity) throws Exception {
        Object adapted = adapt(entity);
        for (Method m : renderer.getClass().getMethods()) {
            if (!m.getName().equals("create") || m.getParameterCount() != 1) continue;
            Class<?> p = m.getParameterTypes()[0];
            try {
                if (p.isInstance(entity)) return unwrap(m.invoke(renderer, entity));
                if (adapted != null && p.isInstance(adapted)) return unwrap(m.invoke(renderer, adapted));
            } catch (ReflectiveOperationException ignored) {
                // try the next overload
            }
        }
        return null;
    }

    private Object adapt(Entity entity) {
        for (String cn : ADAPTER_CLASSES) {
            try {
                Class<?> c = Class.forName(cn, true, loader);
                Object inst = instanceOf(c);
                for (Method m : c.getMethods()) {
                    if (m.getName().equals("adapt") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(entity)) {
                        return m.invoke(Modifier.isStatic(m.getModifiers()) ? null : inst, entity);
                    }
                }
            } catch (Throwable ignored) {
                // try next
            }
        }
        return null;
    }

    private static Object unwrap(Object o) {
        return o instanceof Optional<?> opt ? opt.orElse(null) : o;
    }

    private final class Handle implements ModelHandle {
        private final Object tracker;
        private Object defaultModifier;
        private boolean modifierLooked;

        Handle(Object tracker) { this.tracker = tracker; }

        @Override
        public void play(String animation) {
            try {
                for (Method m : tracker.getClass().getMethods()) {
                    if (!m.getName().equals("animate")) continue;
                    Class<?>[] pt = m.getParameterTypes();
                    if (pt.length == 1 && pt[0] == String.class) { m.invoke(tracker, animation); return; }
                }
                Object mod = modifier();
                for (Method m : tracker.getClass().getMethods()) {
                    if (!m.getName().equals("animate")) continue;
                    Class<?>[] pt = m.getParameterTypes();
                    if (pt.length == 2 && pt[0] == String.class && mod != null && pt[1].isInstance(mod)) { m.invoke(tracker, animation, mod); return; }
                }
                if (plugin.getConfig().getBoolean("settings.debug")) plugin.getLogger().warning("No compatible 'animate' method on the BetterModel tracker.");
            } catch (Throwable t) {
                if (plugin.getConfig().getBoolean("settings.debug")) plugin.getLogger().log(Level.WARNING, "animate(" + animation + ") failed", t);
            }
        }

        private Object modifier() {
            if (modifierLooked) return defaultModifier;
            modifierLooked = true;
            for (String cn : ANIMATION_MODIFIER_CLASSES) {
                try {
                    Class<?> c = Class.forName(cn, true, loader);
                    defaultModifier = c.getField("DEFAULT").get(null);
                    break;
                } catch (Throwable ignored) {
                    // not available in this version
                }
            }
            return defaultModifier;
        }

        @Override
        public void close() {
            try {
                tracker.getClass().getMethod("close").invoke(tracker);
            } catch (Throwable ignored) {
                // already closed / entity removed
            }
        }
    }
}
