package com.irongolemcosmetics;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Attaches the owner's selected skin to a freshly spawned Iron Golem and drives its animations.
 *
 * The golem itself is never modified apart from (optionally) being made invisible: health, damage, targeting,
 * pathfinding and team logic stay 100% BedWars/vanilla. The model is purely a visual layer.
 *
 * States: SHEATHED -> DRAWING -> ARMED <-> ATTACKING ; ARMED -> SHEATHING -> SHEATHED.
 * The sword stays drawn (ARMED) for as long as the golem has a target within chase-range, plus sheathe-delay-ticks.
 */
public final class GolemSkinManager implements Listener {

    private enum State { SHEATHED, DRAWING, ARMED, ATTACKING, SHEATHING }

    private static final class Active {
        final LivingEntity golem;
        final UUID owner;
        final Skin skin;
        final ModelHandle handle;
        final boolean test;
        State state = State.SHEATHED;
        long stateUntil, lastEngaged = Long.MIN_VALUE / 2, lastAttack = Long.MIN_VALUE / 2, hurtUntil;
        boolean attackQueued;
        String current = "";
        Location last;

        Active(LivingEntity golem, UUID owner, Skin skin, ModelHandle handle, boolean test) {
            this.golem = golem; this.owner = owner; this.skin = skin; this.handle = handle; this.test = test;
            this.last = golem.getLocation();
        }
    }

    private final IronGolemCosmeticsPlugin plugin;
    private final Map<UUID, Active> active = new HashMap<>();
    private final Map<UUID, Long> lastInteract = new HashMap<>();
    private BukkitTask task;
    private static final int INTERVAL = 2;

    public GolemSkinManager(IronGolemCosmeticsPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ lifecycle
    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, INTERVAL);
        registerCleanupEvents();
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (Active a : new ArrayList<>(active.values())) release(a, true);
        active.clear();
    }

    @SuppressWarnings("unchecked")
    private void registerCleanupEvents() {
        for (String name : plugin.getConfig().getStringList("behavior.cleanup-events")) {
            for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
                if (p == plugin || !p.getName().toLowerCase(Locale.ROOT).contains("bedwars")) continue;
                try {
                    Class<?> c = Class.forName(name, true, p.getClass().getClassLoader());
                    if (!Event.class.isAssignableFrom(c)) continue;
                    Bukkit.getPluginManager().registerEvent((Class<? extends Event>) c, this, EventPriority.MONITOR,
                            (l, e) -> Bukkit.getScheduler().runTaskLater(plugin, this::sweep, 20L), plugin, true);
                    plugin.getLogger().info("Listening for game end event " + name);
                    break;
                } catch (ClassNotFoundException ignored) {
                    // this API version does not have that event
                } catch (Throwable t) {
                    plugin.getLogger().warning("Could not register " + name + ": " + t);
                }
            }
        }
    }

    // ------------------------------------------------------------------ attaching
    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent e) {
        lastInteract.put(e.getPlayer().getUniqueId(), (long) Bukkit.getCurrentTick());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getEntityType() != EntityType.IRON_GOLEM) return;
        LivingEntity golem = e.getEntity();
        Bukkit.getScheduler().runTask(plugin, () -> {          // next tick: entity fully added, BedWars finished setting it up
            if (!golem.isValid() || active.containsKey(golem.getUniqueId())) return;
            Player owner = findOwner(golem.getLocation());
            if (owner != null) attach(golem, owner, false);
        });
    }

    private Player findOwner(Location loc) {
        if (loc.getWorld() == null) return null;
        double r = plugin.getConfig().getDouble("settings.detect-radius", 8.0);
        long now = Bukkit.getCurrentTick();
        Player best = null;
        double bestScore = Double.MAX_VALUE;
        for (Player p : loc.getWorld().getPlayers()) {
            double d = p.getLocation().distance(loc);
            if (d > r || !plugin.bedwars().isPlaying(p)) continue;
            Long used = lastInteract.get(p.getUniqueId());
            boolean recent = used != null && now - used <= 40;
            double score = d + (recent ? 0 : 1000);               // a player who just right-clicked wins
            if (score < bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    /** @return true if a model was attached. */
    public boolean attach(LivingEntity golem, Player owner, boolean test) {
        if (active.containsKey(golem.getUniqueId())) return false;
        Skin skin = plugin.purchases().effectiveSkin(owner.getUniqueId());
        if (skin == null || !skin.hasModel()) return false;
        ModelHandle handle = plugin.models().attach(golem, skin.model());
        if (handle == null) return false;
        if (plugin.getConfig().getBoolean("behavior.hide-vanilla-golem", true)) golem.setInvisible(true);
        Active a = new Active(golem, owner.getUniqueId(), skin, handle, test);
        active.put(golem.getUniqueId(), a);
        play(a, "idle", true);
        return true;
    }

    /** /golemskins testgolem: spawns a golem next to the player and skins it with the player's effective skin. */
    public boolean spawnTest(Player p) {
        Location l = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(3));
        IronGolem g = p.getWorld().spawn(l, IronGolem.class, golem -> golem.setPlayerCreated(true));
        if (attach(g, p, true)) return true;
        g.remove();
        return false;
    }

    public boolean playOnNearest(Player p, String animation) {
        Active best = null;
        double bd = 12 * 12;
        for (Active a : active.values()) {
            if (!a.golem.getWorld().equals(p.getWorld())) continue;
            double d = a.golem.getLocation().distanceSquared(p.getLocation());
            if (d < bd) { bd = d; best = a; }
        }
        if (best == null) return false;
        best.handle.play(animation);
        best.current = "";
        return true;
    }

    public int activeCount() { return active.size(); }

    // ------------------------------------------------------------------ per-tick brain
    private void tick() {
        long now = Bukkit.getCurrentTick();
        for (Iterator<Active> it = active.values().iterator(); it.hasNext(); ) {
            Active a = it.next();
            if (!a.golem.isValid() || a.golem.isDead()) {
                it.remove();
                release(a, false);
                continue;
            }
            try {
                update(a, now);
            } catch (Throwable t) {
                plugin.getLogger().warning("Animation update failed: " + t);
            }
        }
        if (now % 600 < INTERVAL) lastInteract.values().removeIf(v -> now - v > 200);
    }

    private void update(Active a, long now) {
        double chase = plugin.getConfig().getDouble("behavior.chase-range", 24.0);
        double draw = plugin.getConfig().getDouble("behavior.draw-distance", 6.0);
        long sheatheDelay = plugin.getConfig().getLong("behavior.sheathe-delay-ticks", 40);

        LivingEntity target = a.golem instanceof Mob m ? m.getTarget() : null;
        double dist = Double.MAX_VALUE;
        boolean engaged = false;
        if (target != null && target.isValid() && target.getWorld().equals(a.golem.getWorld())) {
            dist = target.getLocation().distance(a.golem.getLocation());
            engaged = dist <= chase;
        }
        if (engaged) a.lastEngaged = now;

        Location cur = a.golem.getLocation();
        boolean moving = cur.getWorld().equals(a.last.getWorld())
                && Math.hypot(cur.getX() - a.last.getX(), cur.getZ() - a.last.getZ()) > 0.04;
        a.last = cur;

        if (now < a.hurtUntil) return;                              // hurt animation is playing

        switch (a.state) {
            case SHEATHED -> {
                if (engaged && dist <= draw) startDraw(a, now);
                else locomotion(a, moving, false);
            }
            case DRAWING -> {
                if (now >= a.stateUntil) {
                    a.state = State.ARMED;
                    a.current = "";
                    if (a.attackQueued) { a.attackQueued = false; startAttack(a, now); }
                }
            }
            case ATTACKING -> {
                if (now >= a.stateUntil) { a.state = State.ARMED; a.current = ""; }
            }
            case ARMED -> {
                if (!engaged && now - a.lastEngaged >= sheatheDelay) startSheathe(a, now);
                else locomotion(a, moving, true);
            }
            case SHEATHING -> {
                if (engaged && dist <= draw) startDraw(a, now);      // enemy came back mid-sheathe
                else if (now >= a.stateUntil) { a.state = State.SHEATHED; a.current = ""; }
            }
        }
    }

    private void locomotion(Active a, boolean moving, boolean armed) {
        String key = armed ? (moving ? "combat-run" : "combat-idle") : (moving ? "run" : "idle");
        play(a, key, false);
    }

    private void startDraw(Active a, long now) {
        a.state = State.DRAWING;
        a.stateUntil = now + Math.max(1, a.skin.animation("draw").ticks());
        play(a, "draw", true);
    }

    private void startAttack(Active a, long now) {
        a.state = State.ATTACKING;
        a.stateUntil = now + Math.max(1, a.skin.animation("attack").ticks());
        play(a, "attack", true);
    }

    private void startSheathe(Active a, long now) {
        a.state = State.SHEATHING;
        a.stateUntil = now + Math.max(1, a.skin.animation("sheathe").ticks());
        play(a, "sheathe", true);
    }

    private void play(Active a, String key, boolean force) {
        String name = a.skin.animation(key).name();
        if (!force && name.equals(a.current)) return;
        a.current = name;
        a.handle.play(name);
    }

    // ------------------------------------------------------------------ combat hooks
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        long now = Bukkit.getCurrentTick();
        Active attacker = active.get(e.getDamager().getUniqueId());
        if (attacker != null) onGolemAttack(attacker, e.getEntity(), now);
        Active victim = active.get(e.getEntity().getUniqueId());
        if (victim != null && plugin.getConfig().getBoolean("behavior.hurt-animation", true) && victim.state != State.SHEATHING) {
            Skin.AnimationSpec hurt = victim.skin.animation("hurt");
            victim.hurtUntil = now + Math.max(1, hurt.ticks());
            play(victim, "hurt", true);
            victim.current = "";
        }
    }

    private void onGolemAttack(Active a, Entity victim, long now) {
        a.lastEngaged = now;
        long cd = plugin.getConfig().getLong("behavior.attack-cooldown-ticks", 12);
        if (now - a.lastAttack < cd) return;
        a.lastAttack = now;
        switch (a.state) {
            case SHEATHED, SHEATHING -> { a.attackQueued = true; startDraw(a, now); }
            case DRAWING -> a.attackQueued = true;
            case ARMED, ATTACKING -> startAttack(a, now);
        }
        if (plugin.getConfig().getBoolean("behavior.hit-fx", true)) {
            long delay = Math.max(0, plugin.getConfig().getLong("behavior.hit-fx-delay-ticks", 4));
            Location at = victim.getLocation().add(0, victim.getHeight() * 0.6, 0);
            Bukkit.getScheduler().runTaskLater(plugin, () -> hitEffect(at), delay);
        }
    }

    private void hitEffect(Location at) {
        if (at.getWorld() == null) return;
        at.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, at, 14, 0.25, 0.3, 0.25, 0.03);
        at.getWorld().spawnParticle(Particle.END_ROD, at, 4, 0.2, 0.25, 0.2, 0.02);
        at.getWorld().playSound(at, "entity.player.attack.sweep", 0.7f, 1.5f);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        Active a = active.remove(e.getEntity().getUniqueId());
        if (a != null) release(a, false);
    }

    // ------------------------------------------------------------------ cleanup
    private void release(Active a, boolean restoreGolem) {
        try {
            a.handle.close();
        } catch (Throwable ignored) {
            // tracker already gone
        }
        if (restoreGolem && a.golem.isValid()) {
            if (a.test) a.golem.remove();
            else if (plugin.getConfig().getBoolean("behavior.hide-vanilla-golem", true)) a.golem.setInvisible(false);
        }
    }

    /** Drops models whose golem is gone or whose world is empty (game ended). BedWars removes the golems itself. */
    public void sweep() {
        for (Iterator<Active> it = active.values().iterator(); it.hasNext(); ) {
            Active a = it.next();
            if (!a.golem.isValid() || (!a.test && a.golem.getWorld().getPlayers().isEmpty())) {
                it.remove();
                release(a, false);
            }
        }
    }
}
