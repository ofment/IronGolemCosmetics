package com.irongolemcosmetics;

import org.bukkit.entity.LivingEntity;

/** Used when no model engine is installed: skins stay selectable but nothing is rendered. */
public final class NoModelBackend implements ModelBackend {
    @Override public String name() { return "none"; }
    @Override public boolean available() { return false; }
    @Override public ModelHandle attach(LivingEntity entity, String modelId) { return null; }
}
