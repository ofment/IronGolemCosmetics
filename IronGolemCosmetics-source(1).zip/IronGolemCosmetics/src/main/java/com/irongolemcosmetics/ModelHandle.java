package com.irongolemcosmetics;

/** A model attached to one entity. */
public interface ModelHandle {
    void play(String animation);

    void close();
}
