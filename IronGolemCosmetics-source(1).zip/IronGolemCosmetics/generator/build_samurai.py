#!/usr/bin/env python3
"""
Samurai armor model (original geometry/texture, inspired by a black-lacquer + red-lacing + cream-trim samurai look).
Writes samurai_armor.bbmodel (Blockbench "free"/generic model, per-face UV, embedded texture) + samurai_armor.png.

ModelEngine-friendly choices:
  * lowercase bone names, rest rotations all zero (poses come from animations), no rotated cubes
  * all geometry inside the -16..32 px range, 256x256 texture
  * bones: root > hitbox, body, h_head, arm_*, leg_*, ...   animations: idle, walk, run, attack, death
"""
import base64, io, json, math, os, random, uuid
from PIL import Image

NAME = "samurai_armor"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "samurai")
os.makedirs(OUT, exist_ok=True)
TEX = 256
random.seed(11)
_n = [0]


def U():
    _n[0] += 1
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"samurai/{_n[0]}"))


# ----------------------------------------------------------------------------- palette: (base, edge, highlight)
PAL = {
    "black":  ((24, 22, 27), (74, 64, 62), (50, 46, 52)),
    "red":    ((156, 24, 28), (92, 10, 14), (205, 62, 56)),     # red lacing (painted with dotted rows)
    "cream":  ((226, 208, 164), (150, 124, 78), (248, 236, 196)),
    "gold":   ((218, 174, 74), (140, 98, 30), (252, 220, 126)),
    "steel":  ((176, 182, 196), (110, 116, 132), (240, 244, 252)),
    "cloth":  ((70, 16, 20), (36, 8, 10), (96, 26, 30)),
    "wrap":   ((22, 20, 24), (10, 10, 12), (44, 40, 44)),
    "dark":   ((12, 10, 13), (4, 4, 5), (28, 24, 28)),
    "eye":    ((255, 110, 70), (255, 190, 120), (255, 230, 170)),
}

groups, group_order, cubes = {}, [], []


def G(name, origin, parent=None):
    g = dict(name=name, origin=list(origin), uuid=U(), children=[])
    groups[name] = g
    group_order.append(name)
    if parent:
        groups[parent]["children"].append(("g", name))
    return g


def C(group, name, frm, to, mat):
    frm, to = [min(a, b) for a, b in zip(frm, to)], [max(a, b) for a, b in zip(frm, to)]
    c = dict(name=name, frm=frm, to=to, mat=mat, uuid=U())
    cubes.append(c)
    groups[group]["children"].append(("c", c["uuid"]))
    return c


def mirror(group_r, group_l, fn):
    """fn(group, sign, suffix) builds one side; sign=+1 right (+x), -1 left."""
    fn(group_r, 1, "r")
    fn(group_l, -1, "l")


def X(sign, a, b):
    """x range mirrored for the left side"""
    return (a, b) if sign > 0 else (-b, -a)


# ----------------------------------------------------------------------------- geometry
G("root", (0, 0, 0))
G("hitbox", (0, 0, 0), "root")
C("hitbox", "hitbox_box", (-4, 0, -4), (4, 31.5, 4), "dark")       # hitbox bone: not rendered by ModelEngine

# ---- body (do): black lacquer cuirass, red lacing bands, cream trims
G("body", (0, 11, 0), "root")
C("body", "do_core", (-4, 11, -2.2), (4, 21, 2.2), "black")
for k in range(5):
    y0 = 11.5 + k * 1.75
    C("body", f"do_lace_{k}", (-3.9, y0, -2.75), (3.9, y0 + 1.35, -2.2), "red")
    C("body", f"do_trim_{k}", (-3.95, y0 + 1.35, -2.8), (3.95, y0 + 1.75, -2.2), "cream")
C("body", "do_pectoral", (-3.9, 19.9, -2.9), (3.9, 21.1, -2.2), "black")
C("body", "do_pectoral_trim", (-3.95, 19.6, -2.95), (3.95, 19.95, -2.2), "cream")
C("body", "do_collar", (-3.2, 21.0, -2.5), (3.2, 22.0, 2.5), "black")
C("body", "do_collar_trim", (-3.25, 21.8, -2.55), (3.25, 22.1, 2.55), "cream")
for k in range(5):                                                   # back plate: alternating bands
    y0 = 11.5 + k * 1.75
    C("body", f"back_band_{k}", (-3.9, y0, 2.2), (3.9, y0 + 1.35, 2.75), "black" if k % 2 == 0 else "red")
    C("body", f"back_trim_{k}", (-3.95, y0 + 1.35, 2.2), (3.95, y0 + 1.75, 2.8), "cream")
C("body", "side_plate_r", (4.0, 12, -2.0), (4.5, 20.5, 2.0), "black")
C("body", "side_plate_l", (-4.5, 12, -2.0), (-4.0, 20.5, 2.0), "black")
C("body", "side_trim_r", (4.0, 15.9, -2.05), (4.55, 16.3, 2.05), "cream")
C("body", "side_trim_l", (-4.55, 15.9, -2.05), (-4.0, 16.3, 2.05), "cream")
C("body", "obi", (-4.3, 10.7, -2.55), (4.3, 12.0, 2.55), "cloth")
C("body", "obi_buckle", (-0.9, 10.8, -2.8), (0.9, 11.9, -2.5), "gold")
C("body", "obi_knot_a", (2.2, 9.4, -2.9), (3.2, 10.9, -2.5), "red")
C("body", "obi_knot_b", (2.6, 8.0, -2.9), (3.1, 9.5, -2.55), "red")
C("body", "back_mon", (-1.2, 15.5, 2.8), (1.2, 18.0, 3.05), "gold")      # small crest plate on the back

# ---- kusazuri (hip plates) - separate bones so they can swing with the legs
G("skirt_f", (0, 11.3, -2.5), "body")
for i, (a, b) in enumerate(((-4.1, -1.6), (-1.5, 1.5), (1.6, 4.1))):
    C("skirt_f", f"skirt_f_{i}", (a, 8.2, -3.2), (b, 11.3, -2.5), "black")
    C("skirt_f", f"skirt_f_lace_{i}", (a + 0.1, 8.5, -3.3), (b - 0.1, 9.5, -2.9), "red")
    C("skirt_f", f"skirt_f_trim_{i}", (a, 8.1, -3.3), (b, 8.5, -2.5), "cream")
G("skirt_b", (0, 11.3, 2.5), "body")
for i, (a, b) in enumerate(((-4.1, -1.6), (-1.5, 1.5), (1.6, 4.1))):
    C("skirt_b", f"skirt_b_{i}", (a, 8.2, 2.5), (b, 11.3, 3.2), "black")
    C("skirt_b", f"skirt_b_lace_{i}", (a + 0.1, 8.5, 2.9), (b - 0.1, 9.5, 3.3), "red")
    C("skirt_b", f"skirt_b_trim_{i}", (a, 8.1, 2.5), (b, 8.5, 3.3), "cream")
for s, sg in (("r", 1), ("l", -1)):
    G(f"skirt_{s}", (4.3 * sg, 11.3, 0), "body")
    xa, xb = X(sg, 4.2, 5.0)
    C(f"skirt_{s}", f"skirt_{s}_plate", (xa, 8.3, -2.3), (xb, 11.3, 2.3), "black")
    xa, xb = X(sg, 4.3, 5.1)
    C(f"skirt_{s}", f"skirt_{s}_lace", (xa, 8.6, -2.0), (xb, 9.6, 2.0), "red")
    C(f"skirt_{s}", f"skirt_{s}_trim", (xa, 8.2, -2.4), (xb, 8.6, 2.4), "cream")

# ---- saya (scabbard) on the left hip; pose comes from animations
G("saya", (-7.0, 10.8, 0.2), "body")
C("saya", "saya_body", (-7.6, -4.5, -0.7), (-6.4, 10.8, 0.7), "black")
C("saya", "saya_stripe", (-7.65, 0.0, -0.2), (-7.55, 10.0, 0.2), "red")
C("saya", "saya_koiguchi", (-7.7, 10.2, -0.8), (-6.3, 11.1, 0.8), "gold")
C("saya", "saya_kojiri", (-7.7, -4.9, -0.8), (-6.3, -4.0, 0.8), "gold")
C("saya", "saya_kurigata", (-8.0, 6.0, -0.4), (-7.55, 7.2, 0.4), "red")
C("saya", "sageo", (-7.4, 8.2, -1.0), (-6.9, 11.0, -0.7), "red")

# ---- head: face mask + kabuto helmet with crescent crest
G("h_head", (0, 22, 0), "body")
C("h_head", "neck_cloth", (-2.4, 21.6, -2.4), (2.4, 22.8, 2.4), "cloth")
C("h_head", "head_core", (-3.0, 22.4, -3.0), (3.0, 26.2, 3.0), "dark")
C("h_head", "mask", (-2.8, 22.5, -3.6), (2.8, 25.0, -3.0), "dark")
C("h_head", "mask_mouth", (-1.9, 23.2, -3.7), (1.9, 23.8, -3.55), "red")
C("h_head", "mask_cheek_r", (2.7, 22.6, -3.55), (3.2, 24.9, -2.6), "black")
C("h_head", "mask_cheek_l", (-3.2, 22.6, -3.55), (-2.7, 24.9, -2.6), "black")
C("h_head", "mask_chin_trim", (-2.9, 22.35, -3.65), (2.9, 22.75, -3.0), "cream")
C("h_head", "eye_band", (-2.7, 25.0, -3.55), (2.7, 26.0, -3.0), "dark")
C("h_head", "eye_r", (0.7, 25.2, -3.62), (2.2, 25.8, -3.5), "eye")
C("h_head", "eye_l", (-2.2, 25.2, -3.62), (-0.7, 25.8, -3.5), "eye")
C("h_head", "kabuto_bowl", (-3.7, 26.0, -3.7), (3.7, 29.0, 3.7), "black")
C("h_head", "kabuto_top", (-2.7, 29.0, -2.7), (2.7, 29.6, 2.7), "black")
C("h_head", "kabuto_band", (-3.8, 26.2, -3.8), (3.8, 27.1, 3.8), "red")
C("h_head", "kabuto_ring", (-3.85, 27.1, -3.85), (3.85, 27.45, 3.85), "cream")
C("h_head", "kabuto_brim", (-3.8, 26.0, -4.6), (3.8, 26.7, -3.7), "black")
C("h_head", "kabuto_brim_trim", (-3.85, 25.8, -4.7), (3.85, 26.1, -3.7), "cream")
C("h_head", "kabuto_rivets", (-3.0, 28.2, -3.8), (3.0, 28.6, -3.7), "cream")
for i, (y0, hw, z1) in enumerate(((24.3, 3.9, 4.5), (23.0, 4.5, 4.9), (21.7, 5.1, 5.3))):   # shikoro neck guard
    C("h_head", f"shikoro_{i}", (-hw, y0, 3.5), (hw, y0 + 1.7, z1), "black")
    C("h_head", f"shikoro_lace_{i}", (-hw + 0.1, y0 + 0.2, z1 - 0.1), (hw - 0.1, y0 + 0.95, z1 + 0.2), "red")
    C("h_head", f"shikoro_trim_{i}", (-hw, y0 - 0.1, 3.5), (hw, y0 + 0.3, z1 + 0.25), "cream")
for s, sg in (("r", 1), ("l", -1)):                                  # side flaps (fukigaeshi)
    xa, xb = X(sg, 3.8, 5.7)
    C("h_head", f"fuki_{s}", (xa, 24.0, -3.0), (xb, 27.6, -0.4), "black")
    xa, xb = X(sg, 4.0, 5.8)
    C("h_head", f"fuki_lace_{s}", (xa, 24.3, -2.8), (xb, 25.3, -0.6), "red")
    C("h_head", f"fuki_trim_{s}", (xa, 23.9, -3.1), (xb, 24.3, -0.3), "cream")
# crescent crest (maedate): stepped gold horns
C("h_head", "crest_base", (-0.7, 28.6, -4.3), (0.7, 29.9, -3.6), "gold")
for i, (xc, y0) in enumerate(((1.45, 29.2), (2.25, 29.75), (2.95, 30.3), (3.5, 30.9))):
    C("h_head", f"crest_r{i}", (xc - 0.5, y0, -4.2), (xc + 0.5, y0 + 1.0, -3.6), "gold")
    C("h_head", f"crest_l{i}", (-xc - 0.5, y0, -4.2), (-xc + 0.5, y0 + 1.0, -3.6), "gold")
C("h_head", "crest_gem", (-0.35, 29.9, -4.4), (0.35, 30.7, -4.25), "red")

# ---- arms
def arm(sign, s):
    up, low = f"arm_{s}", f"arm_{s}_low"
    sx = 5.5 * sign
    G(up, (sx, 20.3, 0), "body")
    G(low, (sx, 15.8, 0), up)
    xa, xb = X(sign, 4.2, 6.8)
    C(up, f"upper_{s}", (xa, 15.8, -1.5), (xb, 19.6, 1.5), "black")
    xa, xb = X(sign, 4.1, 6.9)
    C(up, f"upper_lace_{s}", (xa, 17.0, -1.6), (xb, 17.9, 1.6), "red")
    # sode: three stacked, slightly widening shoulder plates
    for k, (y0, a, b) in enumerate(((19.9, 4.0, 8.6), (18.65, 4.3, 9.0), (17.4, 4.6, 9.4))):
        xa, xb = X(sign, a, b)
        C(up, f"sode_{s}{k}", (xa, y0, -3.1), (xb, y0 + 1.25, 3.1), "black")
        xa, xb = X(sign, a + 0.1, b + 0.05)
        C(up, f"sode_lace_{s}{k}", (xa, y0 + 0.15, -3.2), (xb, y0 + 0.6, 3.2), "red")
        xa, xb = X(sign, a, b + 0.1)
        C(up, f"sode_trim_{s}{k}", (xa, y0 - 0.05, -3.15), (xb, y0 + 0.2, 3.15), "cream")
    xa, xb = X(sign, 8.4, 8.8)
    C(up, f"sode_edge_{s}", (xa, 17.4, -3.2), (xb, 21.1, 3.2), "cream")
    xa, xb = X(sign, 4.1, 6.9)
    C(low, f"kote_{s}", (xa, 10.9, -1.5), (xb, 15.8, 1.5), "black")
    xa, xb = X(sign, 4.0, 7.0)
    C(low, f"kote_trim_hi_{s}", (xa, 15.3, -1.6), (xb, 15.75, 1.6), "cream")
    C(low, f"kote_trim_lo_{s}", (xa, 11.2, -1.6), (xb, 11.6, 1.6), "cream")
    C(low, f"kote_lace_{s}", (xa, 12.6, -1.65), (xb, 14.4, -1.45), "red")
    xa, xb = X(sign, 4.3, 6.7)
    C(low, f"tekko_{s}", (xa, 9.6, -1.4), (xb, 11.0, 1.4), "dark")
    C(low, f"tekko_plate_{s}", (xa, 10.3, -1.5), (xb, 11.0, -0.6), "black")
    C(low, f"fingers_{s}", (xa + 0.1 * sign, 9.1, -1.3), (xb - 0.1 * sign, 9.7, 1.3), "dark")


arm(1, "r")
arm(-1, "l")

# ---- katana in the right hand (grip at the hand; blade points down along the forearm at rest)
G("sword", (5.5, 10.2, -0.2), "arm_r_low")
C("sword", "tsuka", (5.0, 8.4, -0.6), (6.0, 12.4, 0.4), "wrap")
C("sword", "tsuka_diamond", (4.95, 9.0, -0.65), (6.05, 9.5, 0.45), "cream")
C("sword", "tsuka_diamond2", (4.95, 10.2, -0.65), (6.05, 10.7, 0.45), "cream")
C("sword", "tsuka_diamond3", (4.95, 11.4, -0.65), (6.05, 11.9, 0.45), "cream")
C("sword", "kashira", (4.85, 12.4, -0.7), (6.15, 12.95, 0.5), "gold")
C("sword", "tsuba", (4.2, 8.0, -1.4), (6.8, 8.4, 1.0), "black")
C("sword", "tsuba_rim", (4.1, 8.05, -1.5), (6.9, 8.35, 1.1), "gold")
C("sword", "habaki", (5.1, 7.4, -0.55), (5.9, 8.0, 0.35), "gold")
C("sword", "blade", (5.25, -7.6, -0.5), (5.75, 7.4, 0.3), "steel")
C("sword", "blade_spine", (5.2, -7.5, 0.1), (5.8, 7.4, 0.35), "steel")
C("sword", "blade_tip", (5.3, -8.4, -0.3), (5.7, -7.5, 0.2), "steel")

# ---- legs
def leg(sign, s):
    up, low = f"leg_{s}", f"leg_{s}_low"
    cx = 2.4 * sign
    G(up, (cx, 11, 0), "root")
    G(low, (cx, 6.4, 0), up)
    xa, xb = X(sign, 0.4, 4.4)
    C(up, f"thigh_{s}", (xa, 6.4, -2.0), (xb, 11.0, 2.0), "cloth")
    for k, y0 in enumerate((9.2, 7.9)):
        xa, xb = X(sign, 0.3, 4.5)
        C(up, f"haidate_{s}{k}", (xa, y0, -2.25), (xb, y0 + 1.1, -1.95), "black" if k == 0 else "red")
    xa, xb = X(sign, 0.3, 4.5)
    C(up, f"knee_pad_{s}", (xa, 6.4, -2.4), (xb, 7.5, -1.9), "black")
    C(up, f"knee_trim_{s}", (xa, 7.4, -2.45), (xb, 7.7, -1.9), "cream")
    xa, xb = X(sign, 0.6, 4.2)
    C(low, f"shin_{s}", (xa, 1.4, -1.8), (xb, 6.4, 1.8), "black")
    xa, xb = X(sign, 0.5, 4.3)
    C(low, f"shin_trim_hi_{s}", (xa, 5.9, -1.95), (xb, 6.3, 1.85), "cream")
    C(low, f"shin_trim_lo_{s}", (xa, 1.7, -1.95), (xb, 2.1, 1.85), "cream")
    C(low, f"shin_lace_{s}", (xa + 0.2, 2.8, -2.0), (xb - 0.2, 5.2, -1.8), "red")
    xa, xb = X(sign, 0.4, 4.4)
    C(low, f"foot_{s}", (xa, 0, -3.2), (xb, 1.4, 2.0), "cloth")
    C(low, f"foot_trim_{s}", (xa, 1.2, -3.25), (xb, 1.5, 2.05), "cream")


leg(1, "r")
leg(-1, "l")

# ----------------------------------------------------------------------------- UV packing (per face)
FACES = ("north", "east", "south", "west", "up", "down")


def face_size(c, f):
    (x0, y0, z0), (x1, y1, z1) = c["frm"], c["to"]
    w, h, d = x1 - x0, y1 - y0, z1 - z0
    dims = {"north": (w, h), "south": (w, h), "east": (d, h), "west": (d, h), "up": (w, d), "down": (w, d)}[f]
    return max(1, math.ceil(dims[0] - 1e-6)), max(1, math.ceil(dims[1] - 1e-6))


rects = [[c, f, *face_size(c, f), 0, 0] for c in cubes for f in FACES]
rects.sort(key=lambda r: (-r[3], -r[2]))
x = y = shelf = 0
for r in rects:
    w, h = r[2], r[3]
    if x + w + 1 > TEX:
        x, y, shelf = 0, y + shelf + 1, 0
    r[4], r[5] = x, y
    x += w + 1
    shelf = max(shelf, h)
if y + shelf > TEX:
    raise SystemExit("texture overflow")

img = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 0))
px = img.load()


def clamp(v):
    return max(0, min(255, int(v)))


def shade(col, k):
    return tuple(clamp(c * k) for c in col)


for c, f, w, h, ox, oy in rects:
    base, edge, hi = PAL[c["mat"]]
    m = c["mat"]
    front = f in ("north", "south")
    for j in range(h):
        for i in range(w):
            n = random.randint(-4, 4)
            col = [clamp(base[k] + n) for k in range(3)]
            border = (i in (0, w - 1) or j in (0, h - 1)) and min(w, h) >= 3
            if m == "red":
                if front and w >= 3 and h >= 2:           # dotted lacing rows like layered odoshi
                    if j % 3 == 1 and i % 2 == 0:
                        col = [clamp(edge[k] + n) for k in range(3)]
                    elif j % 3 == 0:
                        col = [clamp(hi[k] * 0.9 + n) for k in range(3)]
                if border:
                    col = [clamp(edge[k] * 0.8 + base[k] * 0.2) for k in range(3)]
            elif m in ("black", "dark", "wrap"):
                if j == 0 and h >= 3:
                    col = [clamp(hi[k] + n) for k in range(3)]
                if border and m != "dark":
                    col = [clamp(edge[k] * 0.55 + base[k] * 0.45) for k in range(3)]
                if m == "black" and front and w >= 6 and h >= 4 and i % 4 == 2 and j % 4 == 2:
                    col = [clamp(edge[k] * 0.75) for k in range(3)]       # rivets
                if m == "wrap" and (i + j) % 3 == 0:
                    col = [clamp(hi[k] + n) for k in range(3)]
            elif m in ("cream", "gold"):
                t = j / max(1, h - 1)
                col = [clamp(hi[k] * (1 - 0.3 * t) + n) for k in range(3)]
                if border:
                    col = list(edge)
            elif m == "steel":
                col = [clamp(base[k] + n + (30 if i < max(1, w // 3) else 0)) for k in range(3)]
                if border:
                    col = [clamp(hi[k]) for k in range(3)]
            elif m == "cloth":
                if (i + j) % 4 == 0:
                    col = [clamp(hi[k] + n) for k in range(3)]
                if border:
                    col = [clamp(edge[k] + n) for k in range(3)]
            elif m == "eye":
                col = [clamp(hi[k]) for k in range(3)]
            if f == "down":
                col = [clamp(v * 0.7) for v in col]
            elif f in ("east", "west"):
                col = [clamp(v * 0.9) for v in col]
            px[ox + i, oy + j] = (*col, 255)
img.save(os.path.join(OUT, f"{NAME}.png"))
buf = io.BytesIO()
img.save(buf, "PNG")
TEX_B64 = base64.b64encode(buf.getvalue()).decode()
face_uv = {}
for c, f, w, h, ox, oy in rects:
    face_uv.setdefault(c["uuid"], {})[f] = [ox, oy, ox + w, oy + h]

# ----------------------------------------------------------------------------- animations
class Anim:
    def __init__(self, name, length, loop):
        self.name, self.length, self.loop, self.tracks = name, length, loop, {}

    def key(self, bone, ch, t, x, y, z, interp="catmullrom"):
        self.tracks.setdefault((bone, ch), []).append((round(t, 3), (round(x, 3), round(y, 3), round(z, 3)), interp))

    def rot(self, bone, t, x, y=0, z=0, interp="catmullrom"):
        self.key(bone, "rotation", t, x, y, z, interp)

    def pos(self, bone, t, x, y, z, interp="catmullrom"):
        self.key(bone, "position", t, x, y, z, interp)

    def sample(self, bone, ch, fn, n=8):
        for i in range(n + 1):
            t = self.length * i / n
            self.key(bone, ch, t, *fn(t), "catmullrom")


ANIMS = []
S = math.sin
TAU = 2 * math.pi
# rest-pose "guard" stance: right forearm forward holding the katana low, left hand near the saya
GUARD = {"arm_r": 10, "arm_r_low": 30, "sword": 10, "arm_l": 8, "arm_l_low": 40, "saya": -78}


def guard(a, extra=None):
    for b, v in GUARD.items():
        if extra and b in extra:
            continue
        a.rot(b, 0, v)
        a.rot(b, a.length, v)


a = Anim("idle", 3.0, "loop")
T = a.length
a.sample("body", "position", lambda t: (0, 0.18 * S(TAU * t / T), 0))
a.sample("h_head", "rotation", lambda t: (1.5 * S(TAU * t / T + 0.6), 3 * S(TAU * t / T), 0))
a.sample("arm_r", "rotation", lambda t: (GUARD["arm_r"] + 1.2 * S(TAU * t / T + 0.4), 0, 0))
a.sample("arm_r_low", "rotation", lambda t: (GUARD["arm_r_low"] + 1.5 * S(TAU * t / T + 0.9), 0, 0))
a.rot("sword", 0, GUARD["sword"]); a.rot("sword", T, GUARD["sword"])
a.sample("arm_l", "rotation", lambda t: (GUARD["arm_l"] + 1.0 * S(TAU * t / T + 0.2), 0, 0))
a.rot("arm_l_low", 0, GUARD["arm_l_low"]); a.rot("arm_l_low", T, GUARD["arm_l_low"])
a.rot("saya", 0, GUARD["saya"]); a.rot("saya", T, GUARD["saya"])
a.sample("skirt_f", "rotation", lambda t: (1.2 * S(TAU * t / T), 0, 0))
a.sample("skirt_b", "rotation", lambda t: (-1.2 * S(TAU * t / T), 0, 0))
ANIMS.append(a)


def gait(name, length, leg_amp, knee, arm_amp, bob):
    a = Anim(name, length, "loop")
    T = length
    ph = lambda t, p=0: TAU * t / T + p
    n = 12
    a.sample("leg_r", "rotation", lambda t: (leg_amp * S(ph(t)), 0, 0), n)
    a.sample("leg_l", "rotation", lambda t: (-leg_amp * S(ph(t)), 0, 0), n)
    a.sample("leg_r_low", "rotation", lambda t: (-knee * max(0, S(ph(t, 1.2))), 0, 0), n)
    a.sample("leg_l_low", "rotation", lambda t: (-knee * max(0, -S(ph(t, 1.2))), 0, 0), n)
    a.sample("body", "position", lambda t: (0, bob * abs(S(ph(t))) - bob * 0.4, 0), n)
    a.sample("body", "rotation", lambda t: (-3 - (arm_amp / 12), 2.5 * S(ph(t)), 0), n)
    a.sample("h_head", "rotation", lambda t: (2 + 1.5 * S(2 * ph(t)), -2.5 * S(ph(t)), 0), n)
    a.sample("arm_r", "rotation", lambda t: (GUARD["arm_r"] - arm_amp * 0.6 * S(ph(t)), 0, 0), n)
    a.sample("arm_r_low", "rotation", lambda t: (GUARD["arm_r_low"] + 5 + 4 * S(ph(t)), 0, 0), n)
    a.rot("sword", 0, GUARD["sword"]); a.rot("sword", T, GUARD["sword"])
    a.sample("arm_l", "rotation", lambda t: (GUARD["arm_l"] + arm_amp * S(ph(t)), 0, 0), n)
    a.sample("arm_l_low", "rotation", lambda t: (GUARD["arm_l_low"] + 6, 0, 0), n)
    a.sample("saya", "rotation", lambda t: (GUARD["saya"] + 4 * S(2 * ph(t)), 0, 0), n)
    a.sample("skirt_f", "rotation", lambda t: (-leg_amp * 0.35 * abs(S(ph(t))) - 2, 0, 0), n)
    a.sample("skirt_b", "rotation", lambda t: (leg_amp * 0.3 * abs(S(ph(t))) + 2, 0, 0), n)
    a.sample("skirt_r", "rotation", lambda t: (0, 0, 2 * S(2 * ph(t))), n)
    a.sample("skirt_l", "rotation", lambda t: (0, 0, -2 * S(2 * ph(t))), n)
    return a


ANIMS.append(gait("walk", 1.0, 28, 34, 16, 0.5))
ANIMS.append(gait("run", 0.6, 44, 58, 30, 0.9))

# attack: wind-up overhead, slash down-forward (arm angle keeps decreasing so the blade sweeps through "forward")
a = Anim("attack", 0.9, "once")
T = a.length
a.rot("arm_r", 0, 10); a.rot("arm_r", 0.25, -140); a.rot("arm_r", 0.33, -150); a.rot("arm_r", 0.5, -300); a.rot("arm_r", 0.62, -318); a.rot("arm_r", T, -350)
a.rot("arm_r_low", 0, 30); a.rot("arm_r_low", 0.25, 10); a.rot("arm_r_low", 0.5, 10); a.rot("arm_r_low", T, 30)
a.rot("sword", 0, 10); a.rot("sword", 0.25, -30); a.rot("sword", 0.5, -30); a.rot("sword", T, 10)
a.rot("arm_l", 0, 8); a.rot("arm_l", 0.3, -25); a.rot("arm_l", 0.5, 30); a.rot("arm_l", T, 8)
a.rot("arm_l_low", 0, 40); a.rot("arm_l_low", 0.3, 20); a.rot("arm_l_low", 0.5, 30); a.rot("arm_l_low", T, 40)
a.rot("saya", 0, -78); a.rot("saya", T, -78)
a.rot("body", 0, 0); a.rot("body", 0.25, -8); a.rot("body", 0.33, -10); a.rot("body", 0.55, 14); a.rot("body", T, 0)
a.rot("h_head", 0, 0); a.rot("h_head", 0.3, -6); a.rot("h_head", 0.55, 8); a.rot("h_head", T, 0)
a.rot("leg_r", 0, 0); a.rot("leg_r", 0.3, 18); a.rot("leg_r", 0.55, 26); a.rot("leg_r", T, 0)
a.rot("leg_l", 0, 0); a.rot("leg_l", 0.3, -22); a.rot("leg_l", 0.55, -14); a.rot("leg_l", T, 0)
a.pos("body", 0, 0, 0, 0); a.pos("body", 0.3, 0, -0.5, 0.3); a.pos("body", 0.55, 0, -0.9, -1.0); a.pos("body", T, 0, 0, 0)
a.rot("skirt_f", 0, 0); a.rot("skirt_f", 0.55, -16); a.rot("skirt_f", T, 0)
a.rot("skirt_b", 0, 0); a.rot("skirt_b", 0.55, 14); a.rot("skirt_b", T, 0)
ANIMS.append(a)

# death: stagger, fall backwards, hold
a = Anim("death", 1.4, "hold")
T = a.length
a.rot("root", 0, 0); a.rot("root", 0.35, 8); a.rot("root", 1.0, 90); a.rot("root", T, 90)
a.pos("root", 0, 0, 0, 0); a.pos("root", 1.0, 0, 3, 0); a.pos("root", T, 0, 3, 0)
a.rot("arm_r", 0, 10); a.rot("arm_r", 0.6, -60); a.rot("arm_r", T, -80)
a.rot("arm_r_low", 0, 30); a.rot("arm_r_low", T, 10)
a.rot("sword", 0, 10); a.rot("sword", T, 40)
a.rot("arm_l", 0, 8); a.rot("arm_l", 0.6, -50); a.rot("arm_l", T, -70)
a.rot("arm_l_low", 0, 40); a.rot("arm_l_low", T, 15)
a.rot("saya", 0, -78); a.rot("saya", T, -78)
a.rot("h_head", 0, 0); a.rot("h_head", 0.5, -15); a.rot("h_head", T, -10)
a.rot("leg_r", 0, 0); a.rot("leg_r", 0.6, 15); a.rot("leg_r", T, 6)
a.rot("leg_l", 0, 0); a.rot("leg_l", 0.6, -10); a.rot("leg_l", T, -4)
ANIMS.append(a)

# ----------------------------------------------------------------------------- write .bbmodel
def element(c):
    return {"name": c["name"], "box_uv": False, "rescale": False, "locked": False, "light_emission": 0,
            "render_order": "default", "allow_mirror_modeling": True, "from": c["frm"], "to": c["to"], "autouv": 0,
            "color": 0, "origin": [round((c["frm"][i] + c["to"][i]) / 2, 3) for i in range(3)],
            "faces": {f: {"uv": face_uv[c["uuid"]][f], "texture": 0} for f in FACES}, "type": "cube", "uuid": c["uuid"]}


def outliner(name):
    g = groups[name]
    kids = [ref if k == "c" else outliner(ref) for k, ref in g["children"]]
    return {"name": name, "origin": g["origin"], "rotation": [0, 0, 0], "color": 0, "uuid": g["uuid"], "export": True,
            "mirror_uv": False, "isOpen": name in ("root", "body"), "locked": False, "visibility": True, "autouv": 0,
            "children": kids}


def anim_json(an):
    animators = {}
    for (bone, ch), keys in an.tracks.items():
        node = animators.setdefault(groups[bone]["uuid"], {"name": bone, "type": "bone", "keyframes": []})
        for t, (x, y, z), interp in sorted(keys, key=lambda k: k[0]):
            node["keyframes"].append({"channel": ch, "data_points": [{"x": x, "y": y, "z": z}], "uuid": U(), "time": t,
                                      "color": -1, "interpolation": interp})
    return {"uuid": U(), "name": an.name, "loop": an.loop, "override": False, "length": an.length, "snapping": 20,
            "selected": False, "anim_time_update": "", "blend_weight": "", "start_delay": "", "loop_delay": "",
            "animators": animators}


project = {
    "meta": {"format_version": "4.10", "creation_time": 1760000000, "model_format": "free", "box_uv": False},
    "name": NAME, "model_identifier": "", "visible_box": [1, 1, 0], "variable_placeholders": "",
    "variable_placeholder_buttons": [], "unhandled_root_fields": {},
    "resolution": {"width": TEX, "height": TEX},
    "elements": [element(c) for c in cubes], "outliner": [outliner("root")],
    "textures": [{"path": "", "name": f"{NAME}.png", "folder": "", "namespace": "", "id": "0", "width": TEX, "height": TEX,
                  "uv_width": TEX, "uv_height": TEX, "particle": False, "use_as_default": False, "layers_enabled": False,
                  "sync_to_project": "", "render_mode": "default", "render_sides": "auto", "frame_time": 1,
                  "frame_order_type": "loop", "frame_order": "", "frame_interpolate": False, "visible": True,
                  "internal": True, "saved": False, "uuid": U(), "source": "data:image/png;base64," + TEX_B64}],
    "animations": [anim_json(an) for an in ANIMS],
}
with open(os.path.join(OUT, f"{NAME}.bbmodel"), "w") as fh:
    json.dump(project, fh, separators=(",", ":"))

lo = [min(c["frm"][i] for c in cubes) for i in range(3)]
hi = [max(c["to"][i] for c in cubes) for i in range(3)]
print("cubes", len(cubes), "bones", len(groups), "animations", [x.name for x in ANIMS])
print("bounds min", lo, "max", hi)
