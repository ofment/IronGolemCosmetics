#!/usr/bin/env python3
"""
Blue Phantom Rider - procedural model generator (original design, nothing copied).

Outputs (next to this script's ../betterModel folder):
  blue_phantom_rider.bbmodel   Blockbench project (open it, tweak it, hand it to BetterModel)
  blue_phantom_rider.png       Main texture (also embedded in the .bbmodel)
  blue_phantom_rider_e.png     Optional emissive mask (glowing blue parts only)
  preview_rest_pose.png        Orthographic sanity-check render of the rest pose

Conventions (Blockbench "Generic model", 16 px = 1 block, front of the model = -Z / north):
  * rotation X: negative swings a hanging limb FORWARD, positive swings it BACKWARD
    (same as vanilla ModelPart xRot).
  * position Y = up, position Z = back (+Z is behind the model).
If any motion looks mirrored in your Blockbench / BetterModel version, change the
two constants ROT_X_SIGN / POS_Z_SIGN below and re-run the script.
"""
import base64, io, json, math, os, random, uuid
from PIL import Image, ImageDraw

ROT_X_SIGN = 1      # set to -1 if every X rotation looks inverted
POS_Z_SIGN = 1      # set to -1 if every Z position offset looks inverted
TEX_SIZE = 256
STYLE = os.environ.get("IGC_STYLE", "phantom")      # phantom | samurai
NAME = {"phantom": "blue_phantom_rider", "samurai": "crimson_samurai_rider"}[STYLE]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "betterModel")
os.makedirs(OUT, exist_ok=True)
random.seed(1337)


def U():
    return str(uuid.uuid4())


# --------------------------------------------------------------------------------------
# Materials (painted procedurally)
# --------------------------------------------------------------------------------------
PAL = {
    #            base colour        noise  edge colour       highlight
    "armor":   ((22, 25, 38),        5,   (58, 84, 150),   (36, 44, 66)),
    "armor2":  ((13, 15, 24),        4,   (38, 56, 104),   (24, 29, 44)),
    "trim":    ((40, 120, 255),     14,   (150, 214, 255), (96, 176, 255)),
    "glow":    ((120, 205, 255),    10,   (235, 250, 255), (170, 228, 255)),
    "cloth":   ((15, 24, 58),        7,   (34, 70, 150),   (24, 40, 92)),
    "leather": ((30, 23, 24),        5,   (72, 54, 52),    (44, 34, 34)),
    "blade":   ((24, 30, 50),        5,   (96, 176, 255),  (42, 54, 86)),
    "ghost":   ((56, 136, 255),     20,   (176, 228, 255), (110, 186, 255)),
    "hoof":    ((9, 10, 16),         3,   (30, 44, 84),    (18, 22, 34)),
    "void":    ((3, 4, 8),           1,   (10, 14, 28),    (6, 8, 16)),
    "eye":     ((175, 242, 255),     6,   (255, 255, 255), (210, 250, 255)),
    "metal":   ((52, 59, 80),        6,   (120, 150, 210), (74, 84, 112)),
}
EMISSIVE = {"trim", "glow", "eye", "ghost"}

# --------------------------------------------------------------------------------------
# Scene graph
# --------------------------------------------------------------------------------------
groups = {}      # name -> dict
cubes = []       # list of dict
group_order = []


def G(name, origin, parent=None):
    g = dict(name=name, origin=list(origin), parent=parent, uuid=U(), children=[])
    groups[name] = g
    group_order.append(name)
    if parent:
        groups[parent]["children"].append(("g", name))
    return g


def C(group, name, frm, to, mat, face_mat=None):
    """Axis aligned cube. frm/to in model px. face_mat: optional {face: material}."""
    frm = [min(a, b) for a, b in zip(frm, to)]
    to = [max(a, b) for a, b in zip(frm, to)] if False else [max(a, b) for a, b in zip(frm, to)]
    cube = dict(name=name, frm=frm, to=to, mat=mat, face_mat=face_mat or {}, uuid=U())
    cubes.append(cube)
    groups[group]["children"].append(("c", cube["uuid"]))
    return cube


# --------------------------------------------------------------------------------------
# Geometry  (x: +right of the rider / east, y: up, z: -front)
# --------------------------------------------------------------------------------------
G("root", (0, 0, 0))
G("horse_root", (0, 11, 0), "root")

# ---- horse body + barding ----
C("horse_root", "horse_body", (-5, 11, -11), (5, 21, 12), "armor2")
for s, sx in (("l", -1), ("r", 1)):
    x0, x1 = (5, 6) if sx > 0 else (-6, -5)
    C("horse_root", f"barding_{s}", (x0, 12, -9), (x1, 19, 9), "armor")
    tx0, tx1 = (6, 6.5) if sx > 0 else (-6.5, -6)
    C("horse_root", f"barding_trim_low_{s}", (tx0, 12, -9), (tx1, 13, 9), "trim")
    C("horse_root", f"barding_trim_up_{s}", (tx0, 18, -9), (tx1, 19, 9), "trim")
    C("horse_root", f"barding_trim_front_{s}", (tx0, 13, -9), (tx1, 18, -8), "trim")
    C("horse_root", f"barding_trim_back_{s}", (tx0, 13, 8), (tx1, 18, 9), "trim")
C("horse_root", "chest_plate", (-5.5, 12, -13), (5.5, 20, -11), "armor")
C("horse_root", "chest_gem", (-1, 14.5, -13.6), (1, 18, -13), "glow")
C("horse_root", "chest_trim_l", (-5.5, 12, -13.4), (-4.5, 20, -13), "trim")
C("horse_root", "chest_trim_r", (4.5, 12, -13.4), (5.5, 20, -13), "trim")
C("horse_root", "rump_plate", (-5.5, 13, 12), (5.5, 20, 13), "armor")
C("horse_root", "rump_trim", (-5.5, 19, 12), (5.5, 20, 13.4), "trim")
C("horse_root", "blanket", (-5.5, 20.8, -6), (5.5, 21.6, 9), "cloth")
C("horse_root", "blanket_trim_l", (-5.7, 20.4, -6), (-5.5, 21.6, 9), "trim")
C("horse_root", "blanket_trim_r", (5.5, 20.4, -6), (5.7, 21.6, 9), "trim")
# horse saddle (the horse's own saddle - the knight ALSO carries one in his hand)
C("horse_root", "saddle_seat", (-4, 21.6, -3), (4, 23, 7), "leather")
C("horse_root", "saddle_pommel", (-1.5, 23, -3), (1.5, 24.5, -1), "leather")
C("horse_root", "saddle_cantle", (-4, 23, 5), (4, 24.5, 7), "leather")
C("horse_root", "saddle_stitch", (-4.1, 22.2, -3.1), (4.1, 22.5, 7.1), "trim")

# ---- tail ----
G("tail", (0, 20, 13), "horse_root")
C("tail", "tail_a", (-1, 13, 13), (1, 20, 15), "cloth")
G("tail_b", (0, 13, 14), "tail")
C("tail_b", "tail_b", (-1.5, 5, 13), (1.5, 13, 15), "ghost")
C("tail_b", "tail_tip", (-1, 2, 13.5), (1, 5, 14.5), "glow")

# ---- neck / head ----
G("neck", (0, 19, -10), "horse_root")
C("neck", "neck_main", (-2.5, 19, -13), (2.5, 31, -9), "armor2")
C("neck", "neck_plate", (-3, 21, -14), (3, 29, -13), "armor")
C("neck", "neck_trim", (-3, 29, -14), (3, 30, -13), "trim")
C("neck", "mane_a", (-1, 20, -9), (1, 26, -7.5), "ghost")
C("neck", "mane_b", (-1, 26, -9), (1, 32, -8), "glow")
G("head", (0, 31, -11), "neck")
C("head", "head_main", (-2.5, 27, -19), (2.5, 33, -11), "armor2")
C("head", "muzzle", (-2, 27, -22), (2, 31, -19), "armor2")
C("head", "chamfron", (-3, 30, -20), (3, 34, -19), "armor")
C("head", "chamfron_crest", (-0.5, 33, -19), (0.5, 36.5, -13), "glow")
C("head", "eye_l", (-3.1, 30, -17), (-2.5, 31.2, -15.5), "eye")
C("head", "eye_r", (2.5, 30, -17), (3.1, 31.2, -15.5), "eye")
C("head", "ear_l", (-2.5, 33, -13), (-1, 36, -12), "armor")
C("head", "ear_r", (1, 33, -13), (2.5, 36, -12), "armor")
C("head", "noseband", (-2.4, 28, -21.5), (2.4, 29, -19), "leather")
C("head", "cheek_strap_l", (-2.8, 27, -19), (-2.5, 33, -17.5), "leather")
C("head", "cheek_strap_r", (2.5, 27, -19), (2.8, 33, -17.5), "leather")
C("head", "bit_ring_l", (-3.4, 28, -19.2), (-2.8, 29.5, -18.2), "metal")
C("head", "bit_ring_r", (2.8, 28, -19.2), (3.4, 29.5, -18.2), "metal")
# reins, horse side (the rider side is inside arm_l)
C("head", "rein_b", (-7.3, 28.5, -13.6), (-3.3, 29.1, -13), "leather")
C("head", "rein_c", (-3.4, 28.4, -18.6), (-2.8, 29, -13), "leather")

# ---- legs ----
LEGS = {"fl": (-3, -8.5), "fr": (3, -8.5), "bl": (-3, 8.5), "br": (3, 8.5)}
for lg, (cx, cz) in LEGS.items():
    G(f"leg_{lg}", (cx, 11, cz), "horse_root")
    C(f"leg_{lg}", f"leg_{lg}_upper", (cx - 1.5, 3, cz - 1.5), (cx + 1.5, 11, cz + 1.5), "armor2")
    C(f"leg_{lg}", f"leg_{lg}_greave", (cx - 2, 4, cz - 2), (cx + 2, 9, cz + 2), "armor")
    C(f"leg_{lg}", f"leg_{lg}_greave_trim", (cx - 2, 9, cz - 2), (cx + 2, 10, cz + 2), "trim")
    C(f"leg_{lg}", f"leg_{lg}_hoof", (cx - 1.75, 0, cz - 1.75), (cx + 1.75, 3, cz + 1.75), "hoof")
    C(f"leg_{lg}", f"leg_{lg}_hoof_trim", (cx - 1.8, 3, cz - 1.8), (cx + 1.8, 3.6, cz + 1.8), "trim")

# ---- knight ----
G("knight_root", (0, 23, 2), "horse_root")
C("knight_root", "pelvis", (-4, 23, -1), (4, 26, 5), "armor2")
for s, sx in (("l", -1), ("r", 1)):
    x_in, x_out = (3, 7) if sx > 0 else (-7, -3)
    C("knight_root", f"thigh_{s}", (x_in, 22, -1), (x_out, 27, 5), "armor")
    sx0, sx1 = (6, 9) if sx > 0 else (-9, -6)
    C("knight_root", f"shin_{s}", (sx0, 14, 0), (sx1, 22, 4), "armor2")
    bx0, bx1 = (6, 9.5) if sx > 0 else (-9.5, -6)
    C("knight_root", f"boot_{s}", (bx0, 12, -0.5), (bx1, 16, 4.5), "armor")
    C("knight_root", f"knee_plate_{s}", (sx0 - 0.2, 21, -0.4), (sx1 + 0.2, 22.2, 4.4), "trim")

G("knight_torso", (0, 26, 2), "knight_root")
C("knight_torso", "torso", (-4, 26, 0), (4, 36, 4), "armor2")
C("knight_torso", "chest_plate_k", (-4.5, 28, -1), (4.5, 35.5, 0), "armor")
C("knight_torso", "chest_line", (-0.6, 28.5, -1.3), (0.6, 35, -1), "trim")
C("knight_torso", "abdomen_plate", (-4, 26, -0.6), (4, 28, 0), "armor")
C("knight_torso", "belt", (-4.3, 25.5, -0.4), (4.3, 27, 4.4), "leather")
C("knight_torso", "belt_buckle", (-1, 25.6, -1), (1, 27, -0.3), "glow")
C("knight_torso", "back_plate", (-4.5, 27, 4), (4.5, 35.5, 4.8), "armor")
C("knight_torso", "gorget", (-3, 36, 0.5), (3, 37.5, 3.5), "armor")

# cape: shoulders -> trailing behind the rider over the horse's rump
G("cape_1", (0, 35.5, 4.8), "knight_torso")
C("cape_1", "cape1_main", (-4.5, 26, 4.8), (4.5, 35.5, 5.8), "cloth")
C("cape_1", "cape1_hem", (-4.5, 26, 4.8), (4.5, 27, 5.9), "trim")
G("cape_2", (0, 26, 5.3), "cape_1")
C("cape_2", "cape2_main", (-4.5, 24.5, 5.8), (4.5, 26.5, 11.5), "cloth")
C("cape_2", "cape2_edge_l", (-4.7, 24.5, 5.8), (-4.5, 26.5, 11.5), "trim")
C("cape_2", "cape2_edge_r", (4.5, 24.5, 5.8), (4.7, 26.5, 11.5), "trim")
G("cape_3", (0, 25.5, 11.5), "cape_2")
C("cape_3", "cape3_main", (-4.5, 21.5, 11.5), (4.5, 26, 12.5), "cloth")
C("cape_3", "cape3_hem", (-4.5, 21.5, 11.5), (4.5, 22.4, 12.6), "trim")

# helmet - dark shadow face, glowing blue eyes
G("h_knight_head", (0, 36, 2), "knight_torso")
C("h_knight_head", "helm", (-3.5, 36, -1.5), (3.5, 43, 5.5), "armor")
C("h_knight_head", "helm_band", (-3.7, 41, -1.7), (3.7, 41.8, 5.7), "trim")
C("h_knight_head", "face_void", (-3, 37.2, -1.7), (3, 41, -1.5), "void")
C("h_knight_head", "eye_k_l", (-2.4, 39, -1.9), (-0.8, 40, -1.7), "eye")
C("h_knight_head", "eye_k_r", (0.8, 39, -1.9), (2.4, 40, -1.7), "eye")
C("h_knight_head", "helm_crest", (-0.5, 43, -0.5), (0.5, 46, 5), "trim")
C("h_knight_head", "helm_plume", (-0.4, 42.5, 5), (0.4, 45, 7.5), "ghost")

# left arm - bent, fist forward, holds a saddle; reins run from the fist to the horse's bit
G("arm_l", (-7, 35, 2), "knight_torso")
C("arm_l", "upper_arm_l", (-8.5, 28.5, 0.5), (-5.5, 35, 3.5), "armor2")
C("arm_l", "pauldron_l", (-9, 34, -0.5), (-4, 37, 4.5), "armor")
C("arm_l", "pauldron_trim_l", (-9.2, 33.5, -0.7), (-3.8, 34.2, 4.7), "trim")
C("arm_l", "forearm_l", (-8.5, 28.5, -6), (-5.5, 31.5, 0.5), "armor2")
C("arm_l", "fist_l", (-9, 28, -7), (-5, 32, -4), "armor")
C("arm_l", "fist_trim_l", (-9.2, 31, -7.2), (-4.8, 31.8, -3.8), "trim")
C("arm_l", "held_saddle_seat", (-10, 32, -10), (-4, 33.5, -3), "leather")
C("arm_l", "held_saddle_pommel", (-8, 33.5, -10), (-6, 35.5, -8.5), "leather")
C("arm_l", "held_saddle_cantle", (-9, 33.5, -4.5), (-5, 35, -3), "leather")
C("arm_l", "held_saddle_flap_l", (-10.5, 29, -9), (-10, 33, -4), "leather")
C("arm_l", "held_saddle_flap_r", (-4, 29, -9), (-3.5, 33, -4), "leather")
C("arm_l", "held_saddle_stitch", (-10.1, 33.4, -10.1), (-3.9, 33.8, -2.9), "trim")
C("arm_l", "held_stirrup", (-10.8, 26, -7.5), (-10.2, 29, -5.5), "metal")
C("arm_l", "rein_a", (-7.3, 29, -13), (-6.7, 29.6, -7), "leather")

# right arm - sword arm
G("arm_r", (7, 35, 2), "knight_torso")
C("arm_r", "upper_arm_r", (5.5, 23, 0.5), (8.5, 35, 3.5), "armor2")
C("arm_r", "pauldron_r", (4, 34, -0.5), (9, 37, 4.5), "armor")
C("arm_r", "pauldron_trim_r", (3.8, 33.5, -0.7), (9.2, 34.2, 4.7), "trim")
C("arm_r", "gauntlet_r", (5.2, 22.8, 0.2), (8.8, 26.5, 3.8), "armor")
C("arm_r", "gauntlet_trim_r", (5.1, 26, 0.1), (8.9, 27, 3.9), "trim")

# ---- sword + side scabbard (children of the torso so they follow the lean) ----
ARM_L = 10.5                                   # shoulder -> hand-centre distance
SHOULDER = (35.0, 2.0)                         # (y, z) of arm_r pivot
ALPHA_REACH = math.degrees(math.asin((-2.5 - SHOULDER[1]) / ARM_L))   # hand lands on the grip
G0Y = SHOULDER[0] - ARM_L * math.cos(math.radians(ALPHA_REACH))
G0Z = -2.5
G("sword", (7, G0Y, G0Z), "knight_torso")
C("sword", "sword_grip", (6.5, G0Y - 1.5, -3), (7.5, G0Y + 1.5, -2), "leather")
C("sword", "sword_pommel", (6.3, G0Y + 1.5, -3.2), (7.7, G0Y + 2.7, -1.8), "metal")
C("sword", "sword_pommel_gem", (6.8, G0Y + 2.0, -3.4), (7.2, G0Y + 2.6, -3.2), "glow")
C("sword", "sword_guard", (5.3, G0Y - 2.6, -3.3), (8.7, G0Y - 1.5, -1.7), "metal")
C("sword", "sword_guard_trim", (5.3, G0Y - 2.4, -3.4), (8.7, G0Y - 1.9, -1.6), "trim")
C("sword", "blade", (6.6, G0Y - 14.1, -3.05), (7.4, G0Y - 2.6, -1.95), "blade")
C("sword", "blade_edge_l", (6.45, G0Y - 14.0, -2.95), (6.6, G0Y - 2.7, -2.05), "glow")
C("sword", "blade_edge_r", (7.4, G0Y - 14.0, -2.95), (7.55, G0Y - 2.7, -2.05), "glow")
C("sword", "blade_tip", (6.7, G0Y - 15.2, -2.95), (7.3, G0Y - 14.1, -2.05), "glow")
C("sword", "blade_core", (6.9, G0Y - 13.5, -3.15), (7.1, G0Y - 4, -3.05), "ghost")
# open-fronted holster so the blade is drawn forward without clipping
C("knight_torso", "holster_back", (6.2, 10.0, -1.95), (7.8, 23.0, -1.5), "leather")
C("knight_torso", "holster_side_l", (6.2, 10.0, -3.5), (6.5, 23.0, -1.95), "leather")
C("knight_torso", "holster_side_r", (7.5, 10.0, -3.5), (7.8, 23.0, -1.95), "leather")
C("knight_torso", "holster_tip", (6.4, 9.0, -3.3), (7.6, 10.0, -1.7), "metal")
C("knight_torso", "holster_band_a", (6.0, 20.5, -3.7), (8.0, 21.5, -1.3), "trim")
C("knight_torso", "holster_band_b", (6.0, 15.5, -3.7), (8.0, 16.5, -1.3), "trim")
C("knight_torso", "holster_strap", (5.8, 22.5, -3.7), (8.0, 25.8, -3.2), "leather")

# ======================================================================================
# RESTYLE v2 - "spectral coat" look: wide-brim hat, tattered navy coat, teal-flame face and clawed hands,
# grey trousers, belt with glowing gems. The horse uses the same dark-navy / teal palette.
# (Inspired by the mood of the reference image; original blocky design. Bone names are unchanged,
#  so every animation keeps working.)
# ======================================================================================
def _remove(*names):
    for n in names:
        for c in list(cubes):
            if c["name"] == n:
                cubes.remove(c)
                for g in groups.values():
                    g["children"] = [ch for ch in g["children"] if not (ch[0] == "c" and ch[1] == c["uuid"])]


def _mat(mat, *names):
    for c in cubes:
        if c["name"] in names:
            c["mat"] = mat



if STYLE == "phantom":
    PAL["trim"]   = ((24, 190, 205), 12, (170, 245, 250), (70, 225, 235))
    PAL["glow"]   = ((90, 230, 235), 10, (235, 255, 255), (150, 245, 248))
    PAL["ghost"]  = ((30, 170, 200), 18, (150, 235, 245), (60, 200, 225))
    PAL["eye"]    = ((190, 252, 255), 6, (255, 255, 255), (220, 255, 255))
    PAL["armor"]  = ((22, 26, 56), 5, (52, 72, 140), (34, 42, 84))
    PAL["armor2"] = ((14, 18, 40), 4, (34, 50, 100), (22, 28, 58))
    PAL["metal"]  = ((112, 118, 134), 6, (205, 210, 225), (150, 156, 172))
    PAL["coat"]   = ((22, 28, 62), 6, (56, 80, 156), (34, 44, 92))
    PAL["pants"]  = ((68, 70, 80), 5, (112, 114, 128), (88, 90, 102))
    PAL["hat"]    = ((30, 31, 40), 4, (66, 70, 92), (44, 46, 60))
    PAL["smoke"]  = ((9, 13, 32), 4, (18, 62, 86), (14, 20, 46))
    PAL["flame"]  = ((30, 208, 218), 20, (215, 255, 255), (96, 236, 242))
    PAL["hand"]   = ((10, 50, 68), 6, (44, 205, 215), (16, 84, 104))
    PAL["claw"]   = ((8, 24, 34), 3, (70, 215, 225), (14, 40, 54))
    EMISSIVE.update({"flame"})


    # ---- horse: dark navy body, torn cloth barding, teal-flame mane / tail / eyes ----
    _mat("smoke", "horse_body", "neck_main", "head_main", "muzzle", "ear_l", "ear_r", "tail_a",
         *[f"leg_{lg}_upper" for lg in LEGS])
    _mat("coat", "barding_l", "barding_r", "chest_plate", "rump_plate", "blanket", "neck_plate", "chamfron",
         *[f"leg_{lg}_greave" for lg in LEGS])
    _mat("flame", "chest_gem", "mane_a", "mane_b", "tail_b", "tail_tip", "chamfron_crest")
    for side, x0, x1 in (("l", -6.0, -5.0), ("r", 5.0, 6.0)):                      # torn hem of the barding
        for i in range(6):
            z = -8.5 + 3.0 * i
            C("horse_root", f"barding_rag_{side}{i}", (x0, 9.2 + (i % 2) * 1.6, z), (x1, 12.0, z + 1.8), "coat")
    C("neck", "mane_c", (-1.4, 23, -9.6), (1.4, 29, -8.0), "flame")
    C("neck", "mane_wisp", (-0.8, 31, -7.6), (0.8, 37, -6.6), "flame")
    C("tail_b", "tail_flame_a", (-1.3, 5, 14.6), (1.3, 13, 15.6), "flame")
    C("tail_b", "tail_flame_b", (-0.8, -1, 14.0), (0.8, 4.5, 14.8), "flame")
    for lg, (cx, cz) in LEGS.items():                                              # small flames at the hooves
        sx = -1 if cx < 0 else 1
        C(f"leg_{lg}", f"hoof_flame_{lg}", (cx + sx * 1.9, 1.5, cz - 0.5), (cx + sx * 2.5, 6.5, cz + 0.5), "flame")

    # ---- rider: grey trousers, dark boots, navy coat ----
    _mat("pants", "pelvis", "thigh_l", "thigh_r", "shin_l", "shin_r")
    _mat("hoof", "boot_l", "boot_r")
    _remove("knee_plate_l", "knee_plate_r", "chest_plate_k", "gorget", "pauldron_trim_l", "pauldron_trim_r",
            "fist_trim_l", "gauntlet_trim_r", "helm", "helm_band", "face_void", "helm_crest", "helm_plume")
    _mat("void", "torso", "abdomen_plate")
    _mat("flame", "chest_line")
    _mat("coat", "back_plate", "upper_arm_l", "upper_arm_r", "pauldron_l", "pauldron_r", "forearm_l",
         "cape1_main", "cape2_main", "cape3_main")
    _mat("smoke", "cape1_hem", "cape2_edge_l", "cape2_edge_r", "cape3_hem")
    _mat("metal", "belt_buckle")
    _mat("hand", "fist_l", "gauntlet_r")
    # coat lapels + collar (the chest between them is a dark void with a teal flame)
    C("knight_torso", "lapel_l", (-4.6, 26.6, -1.5), (-1.7, 35.8, -0.5), "coat")
    C("knight_torso", "lapel_r", (1.7, 26.6, -1.5), (4.6, 35.8, -0.5), "coat")
    C("knight_torso", "chest_flame_wide", (-1.5, 31.0, -1.25), (1.5, 36.2, -0.9), "flame")
    C("knight_torso", "collar_l", (-4.2, 35.6, -1.6), (-1.6, 38.6, 3.9), "coat")
    C("knight_torso", "collar_r", (1.6, 35.6, -1.6), (4.2, 38.6, 3.9), "coat")
    C("knight_torso", "badge", (-3.9, 33.0, -1.8), (-2.9, 34.2, -1.5), "metal")
    for i, (x0, x1) in enumerate(((-3.6, -2.8), (1.8, 2.6), (3.1, 3.9))):         # glowing belt gems
        C("knight_torso", f"belt_gem_{i}", (x0, 25.7, -1.0), (x1, 26.9, -0.4), "flame")
    # long coat: side skirts + front flaps with ragged, smoky hems
    for s, xa, xb in (("l", -10.4, -9.6), ("r", 9.6, 10.4)):
        C("knight_root", f"coat_skirt_{s}", (xa, 15.0, -0.8), (xb, 26.8, 4.8), "coat")
        for i in range(5):
            z = -0.8 + 1.15 * i
            C("knight_root", f"coat_rag_{s}{i}", (xa, 11.6 + (i % 3) * 1.1, z), (xb, 15.2, z + 1.0), "smoke")
    for s, xa, xb in (("l", -7.0, -3.2), ("r", 3.2, 7.0)):
        C("knight_root", f"coat_front_{s}", (xa, 19.5, -1.7), (xb, 26.6, -1.15), "coat")
        for i in range(3):
            x = xa + 1.3 * i
            C("knight_root", f"coat_front_rag_{s}{i}", (x, 17.2 + (i % 2) * 1.2, -1.7), (x + 1.1, 19.7, -1.15), "smoke")
    for i, xx in enumerate((-4.0, -2.0, 0.0, 2.0, 4.0)):                           # ragged back tails
        C("cape_3", f"tail_rag_{i}", (xx - 0.9, 17.4 + (i % 2) * 1.6, 11.5), (xx + 0.9, 21.7, 12.6), "smoke")
    # ---- head: shadow face with teal flames + wide-brim hat ----
    C("h_knight_head", "head_void", (-3.2, 36, -1.5), (3.2, 43, 5.5), "void")
    C("h_knight_head", "face_flame_jaw", (-2.6, 36.8, -1.9), (2.6, 38.0, -1.55), "flame")
    C("h_knight_head", "face_flame_l", (-3.5, 38.2, -1.8), (-2.7, 42.0, -1.55), "flame")
    C("h_knight_head", "face_flame_r", (2.7, 38.2, -1.8), (3.5, 42.0, -1.55), "flame")
    C("h_knight_head", "hair_flame_l", (-4.4, 35.0, 0.0), (-3.3, 42.5, 4.8), "flame")
    C("h_knight_head", "hair_flame_r", (3.3, 35.0, 0.0), (4.4, 42.5, 4.8), "flame")
    C("h_knight_head", "hair_back", (-3.5, 33.5, 5.4), (3.5, 42.5, 6.6), "smoke")
    C("h_knight_head", "hair_back_flame", (-1.6, 32.0, 6.6), (1.6, 41.0, 7.4), "flame")
    C("h_knight_head", "hat_brim", (-7.0, 43.0, -5.0), (7.0, 43.9, 9.0), "hat")
    C("h_knight_head", "hat_crown", (-3.8, 43.9, -1.8), (3.8, 47.8, 5.8), "hat")
    C("h_knight_head", "hat_top", (-3.2, 47.8, -1.4), (3.2, 48.4, 5.4), "hat")
    C("h_knight_head", "hat_band", (-3.9, 44.0, -1.9), (3.9, 45.2, 5.9), "armor2")
    C("h_knight_head", "hat_buckle", (-0.9, 44.1, -2.25), (0.9, 45.1, -1.9), "metal")
    # ---- clawed hands ----
    for i, x in enumerate((5.5, 6.5, 7.5, 8.3)):
        C("arm_r", f"claw_r{i}", (x, 19.2, 1.0 + (i % 2) * 1.6), (x + 0.6, 22.9, 1.6 + (i % 2) * 1.6), "claw")
    for i, x in enumerate((-8.6, -7.6, -6.6, -5.6)):
        C("arm_l", f"claw_l{i}", (x, 26.0, -7.2), (x + 0.6, 28.1, -6.6), "claw")

elif STYLE == "samurai":
    # Crimson Samurai Rider: black-lacquer plates, crimson lacing, cream-gold trim, kabuto with a crescent crest,
    # wide sode shoulder plates and a slender katana. Horse barded in the same colours.
    PAL.update({
        "plate":  ((31, 30, 36), 4, (88, 76, 72), (50, 48, 56)),
        "plate2": ((18, 18, 22), 3, (56, 50, 52), (30, 30, 36)),
        "lac":    ((132, 22, 28), 8, (74, 10, 14), (176, 44, 44)),
        "gold":   ((233, 212, 164), 8, (140, 108, 64), (252, 240, 205)),
        "steel":  ((72, 78, 96), 5, (150, 160, 184), (104, 112, 132)),
        "steel2": ((176, 184, 202), 6, (236, 240, 250), (210, 218, 232)),
    })
    PAL["armor"], PAL["armor2"], PAL["trim"], PAL["glow"] = PAL["plate"], PAL["plate2"], PAL["gold"], PAL["gold"]
    PAL["cloth"], PAL["ghost"], PAL["blade"], PAL["metal"] = PAL["lac"], PAL["lac"], PAL["steel"], PAL["steel"]
    PAL["leather"] = ((44, 30, 30), 5, (92, 64, 58), (62, 44, 42))
    PAL["eye"] = ((255, 196, 120), 6, (255, 240, 200), (255, 214, 150))
    EMISSIVE.clear(); EMISSIVE.add("eye")

    # ---- horse ----
    _mat("plate2", "horse_body", "neck_main", "head_main", "muzzle", "tail_a", "mane_a", *[f"leg_{lg}_upper" for lg in LEGS])
    _mat("lac", "blanket", "saddle_seat", "cheek_strap_l", "cheek_strap_r", "noseband", "tail_b", "mane_b")
    _remove("chamfron_crest")
    C("head", "chamfron_horn_base", (-2.6, 33.6, -19.6), (2.6, 34.6, -18.9), "gold")
    for sgn in (-1, 1):
        n = "l" if sgn < 0 else "r"
        C("head", f"chamfron_horn_{n}0", (min(sgn * 1.8, sgn * 2.6), 34.6, -19.6), (max(sgn * 1.8, sgn * 2.6), 36.6, -18.9), "gold")
        C("head", f"chamfron_horn_{n}1", (min(sgn * 2.4, sgn * 3.2), 36.6, -19.6), (max(sgn * 2.4, sgn * 3.2), 38.6, -18.9), "gold")
    for side, x0, x1 in (("l", -6.5, -6.0), ("r", 6.0, 6.5)):                  # lacing bands on the barding
        for i in range(3):
            C("horse_root", f"barding_lace_{side}{i}", (x0, 13.6 + 2.0 * i, -8.5), (x1, 14.6 + 2.0 * i, 8.5), "lac")

    # ---- rider ----
    _mat("lac", "pelvis", "torso", "belt")
    _mat("plate", "thigh_l", "thigh_r", "back_plate", "gorget", "chest_plate_k", "abdomen_plate", "pauldron_l", "pauldron_r",
         "forearm_l", "gauntlet_r", "helm")
    _mat("plate2", "shin_l", "shin_r", "boot_l", "boot_r", "upper_arm_l", "upper_arm_r", "fist_l")
    _remove("helm_crest", "helm_plume", "sword_pommel_gem", "blade_core", "blade_edge_l", "blade_edge_r")
    for i, (y0, y1) in enumerate(((33.6, 34.6), (31.4, 32.4), (29.2, 30.2))):   # cream-gold do bands
        C("knight_torso", f"chest_band_{i}", (-4.3, y0, -1.35), (4.3, y1, -1.0), "gold")
    for i, (y0, y1) in enumerate(((34.6, 35.4), (32.4, 33.6), (30.2, 31.4), (28.2, 29.2))):
        C("knight_torso", f"chest_lace_{i}", (-4.0, y0, -1.3), (4.0, y1, -1.05), "lac")
    for i in range(5):                                                         # lacing knots
        for j, y in enumerate((33.0, 30.8, 28.6)):
            C("knight_torso", f"chest_dot_{i}_{j}", (-3.3 + 1.65 * i, y, -1.45), (-2.7 + 1.65 * i, y + 0.6, -1.3), "plate2")
    for s_, xa, xb in (("l", -10.4, -9.6), ("r", 9.6, 10.4)):                  # kusazuri side skirts
        C("knight_root", f"kusa_side_{s_}", (xa, 15.5, -0.8), (xb, 26.4, 4.8), "plate")
        for i in range(4):
            C("knight_root", f"kusa_side_lace_{s_}{i}", (xa - 0.1, 16.4 + 2.6 * i, -0.7), (xb + 0.1, 17.3 + 2.6 * i, 4.7), "lac")
        C("knight_root", f"kusa_side_hem_{s_}", (xa - 0.1, 15.2, -0.9), (xb + 0.1, 16.0, 4.9), "gold")
    for i in range(4):                                                         # kusazuri front plates
        x = -6.8 + 3.4 * i
        C("knight_root", f"kusa_front_{i}", (x, 19.5, -1.75), (x + 3.3, 26.4, -1.15), "plate")
        C("knight_root", f"kusa_front_lace_a{i}", (x + 0.2, 20.5, -1.8), (x + 3.1, 21.4, -1.1), "lac")
        C("knight_root", f"kusa_front_lace_b{i}", (x + 0.2, 23.0, -1.8), (x + 3.1, 23.9, -1.1), "lac")
        C("knight_root", f"kusa_front_hem_{i}", (x, 19.2, -1.8), (x + 3.3, 19.8, -1.1), "gold")
    # kabuto: dome, peak, wings, neck guard, mask, crescent crest (maedate)
    C("h_knight_head", "helm_dome", (-3.0, 43.0, -1.0), (3.0, 44.0, 5.0), "plate")
    C("h_knight_head", "helm_peak", (-3.8, 41.6, -2.4), (3.8, 42.6, -1.4), "plate")
    C("h_knight_head", "helm_peak_lace", (-3.8, 41.3, -2.5), (3.8, 41.7, -1.3), "lac")
    C("h_knight_head", "menpo", (-3.1, 36.2, -2.0), (3.1, 39.4, -1.5), "plate2")
    for sgn, n in ((-1, "l"), (1, "r")):
        xa, xb = (3.6, 4.7) if sgn > 0 else (-4.7, -3.6)
        C("h_knight_head", f"fuki_{n}", (xa, 39.0, -1.4), (xb, 43.0, 1.8), "plate")
        C("h_knight_head", f"fuki_trim_{n}", (xa - (0.1 if sgn < 0 else 0), 39.0, -1.6), (xb + (0.1 if sgn > 0 else 0), 43.0, -1.4), "gold")
        xa, xb = (3.7, 5.0) if sgn > 0 else (-5.0, -3.7)
        C("h_knight_head", f"shikoro_side_{n}", (xa, 35.6, -0.4), (xb, 39.2, 5.6), "plate")
        C("h_knight_head", f"shikoro_side_lace_{n}", (xa - 0.1 * sgn * -1, 36.4, -0.5), (xb + 0.1 * sgn, 37.2, 5.7), "lac")
    C("h_knight_head", "shikoro_back", (-4.8, 35.4, 5.1), (4.8, 38.6, 6.5), "plate")
    C("h_knight_head", "shikoro_lace_back", (-4.9, 36.6, 5.0), (4.9, 37.4, 6.6), "lac")
    C("h_knight_head", "maedate_base", (-2.2, 43.1, -1.5), (2.2, 44.2, -0.95), "gold")
    for i, (y0, y1, x0, x1) in enumerate(((44.2, 45.4, 1.6, 3.0), (45.4, 47.0, 2.4, 3.6), (47.0, 48.6, 3.0, 3.9))):
        C("h_knight_head", f"maedate_r{i}", (x0, y0, -1.5), (x1, y1, -0.95), "gold")
        C("h_knight_head", f"maedate_l{i}", (-x1, y0, -1.5), (-x0, y1, -0.95), "gold")
    # sode shoulder plates: lacing + gold tips; kote hand guards
    for s_, sgn in (("l", -1), ("r", 1)):
        x0, x1 = (4.0, 9.0) if sgn > 0 else (-9.0, -4.0)
        for i in range(3):
            C(f"arm_{s_}", f"sode_lace_{s_}{i}", (x0 - 0.2, 34.2 + 0.95 * i, -0.7), (x1 + 0.2, 34.9 + 0.95 * i, 4.7), "lac")
        tx0, tx1 = (8.8, 9.4) if sgn > 0 else (-9.4, -8.8)
        C(f"arm_{s_}", f"sode_tip_{s_}", (tx0, 33.6, -0.6), (tx1, 37.2, 4.6), "gold")
    # katana: slender steel blade, lacquered saya (scabbard), wrapped grip, square tsuba
    for c in cubes:
        n = c["name"]
        if n == "blade":
            c["frm"][0], c["to"][0], c["mat"] = 6.8, 7.2, "steel2"
        elif n == "blade_tip":
            c["frm"][0], c["to"][0], c["mat"] = 6.85, 7.15, "steel2"
        elif n == "sword_guard":
            c["frm"][0], c["to"][0], c["frm"][2], c["to"][2], c["mat"] = 5.6, 8.4, -3.6, -1.4, "plate2"
        elif n == "sword_grip":
            c["mat"] = "lac"
        elif n in ("sword_pommel",):
            c["mat"] = "gold"
        elif n in ("holster_back", "holster_side_l", "holster_side_r"):
            c["mat"] = "plate2"
        elif n == "holster_tip":
            c["mat"] = "gold"
        elif n == "holster_strap":
            c["mat"] = "lac"

# --------------------------------------------------------------------------------------
# UV packing + texture painting
# --------------------------------------------------------------------------------------
FACES = ("north", "east", "south", "west", "up", "down")


def face_px(cube, face):
    (x0, y0, z0), (x1, y1, z1) = cube["frm"], cube["to"]
    w, h, d = x1 - x0, y1 - y0, z1 - z0
    dims = {"north": (w, h), "south": (w, h), "east": (d, h), "west": (d, h), "up": (w, d), "down": (w, d)}[face]
    return max(1, math.ceil(dims[0] - 1e-6)), max(1, math.ceil(dims[1] - 1e-6))


rects = []
for c in cubes:
    for f in FACES:
        w, h = face_px(c, f)
        rects.append([c, f, w, h, 0, 0])
rects.sort(key=lambda r: (-r[3], -r[2]))
x = y = shelf_h = 0
PAD = 1
for r in rects:
    w, h = r[2], r[3]
    if x + w + PAD > TEX_SIZE:
        x = 0
        y += shelf_h + PAD
        shelf_h = 0
    r[4], r[5] = x, y
    x += w + PAD
    shelf_h = max(shelf_h, h)
if y + shelf_h > TEX_SIZE:
    raise SystemExit("Texture atlas overflow - raise TEX_SIZE")

tex = Image.new("RGBA", (TEX_SIZE, TEX_SIZE), (0, 0, 0, 0))
emi = Image.new("RGBA", (TEX_SIZE, TEX_SIZE), (0, 0, 0, 0))
tp, ep = tex.load(), emi.load()


def clamp(v):
    return max(0, min(255, int(v)))


for c, f, w, h, ox, oy in rects:
    mat = c["face_mat"].get(f, c["mat"])
    base, noise, edge, hi = PAL[mat]
    for j in range(h):
        for i in range(w):
            n = random.randint(-noise, noise)
            col = [clamp(base[k] + n) for k in range(3)]
            border = (i == 0 or j == 0 or i == w - 1 or j == h - 1) and min(w, h) >= 3
            if mat in ("armor", "armor2", "cloth", "leather", "metal", "blade", "hoof", "coat", "pants", "hat", "smoke", "hand", "claw", "plate", "plate2", "lac", "gold", "steel", "steel2"):
                if border:
                    col = [clamp((edge[k] * 0.55 + base[k] * 0.45)) for k in range(3)]
                elif j == 1 and w >= 4:
                    col = [clamp((hi[k] + n)) for k in range(3)]
                elif mat in ("armor", "metal") and w >= 6 and h >= 6 and (i % 5 == 2 and j % 5 == 2):
                    col = [clamp(edge[k] * 0.8) for k in range(3)]       # rivets
            elif mat in ("trim", "glow", "ghost", "eye", "flame"):
                t = j / max(1, h - 1)
                col = [clamp(hi[k] * (1 - 0.35 * t) + n) for k in range(3)]
                if border:
                    col = list(edge)
            tp[ox + i, oy + j] = (*col, 255)
            if mat in EMISSIVE:
                ep[ox + i, oy + j] = (*col, 255)

tex.save(os.path.join(OUT, f"{NAME}.png"))
emi.save(os.path.join(OUT, f"{NAME}_e.png"))
buf = io.BytesIO()
tex.save(buf, "PNG")
TEX_B64 = base64.b64encode(buf.getvalue()).decode()

face_uv = {}
for c, f, w, h, ox, oy in rects:
    face_uv.setdefault(c["uuid"], {})[f] = [ox, oy, ox + w, oy + h]

# --------------------------------------------------------------------------------------
# Animation helpers (forward kinematics for the sword arm)
# --------------------------------------------------------------------------------------
def hand_pos(alpha_deg):
    a = math.radians(alpha_deg)
    return SHOULDER[0] - ARM_L * math.cos(a), SHOULDER[1] + ARM_L * math.sin(a)


class Anim:
    def __init__(self, name, length, loop):
        self.name, self.length, self.loop = name, length, loop
        self.tracks = {}      # (bone, channel) -> [(t, (x,y,z), interp)]

    def key(self, bone, ch, t, x=0.0, y=0.0, z=0.0, interp="linear"):
        if ch == "rotation":
            x *= ROT_X_SIGN
        if ch == "position":
            z *= POS_Z_SIGN
        self.tracks.setdefault((bone, ch), []).append((round(t, 4), (round(x, 4), round(y, 4), round(z, 4)), interp))

    def sword(self, t, alpha, a_s, interp="linear"):
        """Arm angle alpha + sword blade angle a_s (both X rotations). Sword grip follows the hand."""
        hy, hz = hand_pos(alpha)
        self.key("arm_r", "rotation", t, alpha, 0, 0, interp)
        self.key("sword", "rotation", t, a_s, 0, 0, interp)
        self.key("sword", "position", t, 0, hy - G0Y, hz - G0Z, interp)

    def sword_rest(self, t):
        self.key("arm_r", "rotation", t, 0, 0, 0)
        self.key("sword", "rotation", t, 0, 0, 0)
        self.key("sword", "position", t, 0, 0, 0)

    def sword_sweep(self, t0, t1, a0, a1, s0, s1, step=0.05):
        n = max(1, int(round((t1 - t0) / step)))
        for i in range(n + 1):
            u = i / n
            self.sword(t0 + (t1 - t0) * u, a0 + (a1 - a0) * u, s0 + (s1 - s0) * u)


GUARD = (-40.0, -60.0)       # arm alpha, blade angle for the low "ready" guard
ANIMS = []


def sin_t(t, T, phase=0.0):
    return math.sin(2 * math.pi * (t / T + phase))


def horse_idle_layer(a, T, drawn):
    """Breathing, ear/neck/head nods, tail + cape sway, small knight movements. Looped."""
    n = 8
    for i in range(n + 1):
        t = T * i / n
        ph = sin_t(t, T)
        ph2 = sin_t(t, T, 0.25)
        a.key("horse_root", "position", t, 0, 0.35 * (0.5 - 0.5 * math.cos(2 * math.pi * t / T)), 0, "catmullrom")
        a.key("horse_root", "rotation", t, 0.6 * ph, 0, 0, "catmullrom")
        a.key("neck", "rotation", t, 2.0 * ph, 0, 0, "catmullrom")
        a.key("head", "rotation", t, -1.5 * ph + 1.0 * ph2, 0, 0, "catmullrom")
        a.key("tail", "rotation", t, 4 * ph2 + 3, 0, 2.5 * ph, "catmullrom")
        a.key("tail_b", "rotation", t, 6 * ph, 0, 3 * ph2, "catmullrom")
        a.key("cape_1", "rotation", t, 2.5 + 1.5 * ph2, 0, 0, "catmullrom")
        a.key("cape_2", "rotation", t, 1.5 + 1.2 * ph, 0, 0, "catmullrom")
        a.key("cape_3", "rotation", t, 3 + 2 * ph2, 0, 0, "catmullrom")
        a.key("knight_torso", "rotation", t, 0.8 * ph, 0, 0, "catmullrom")
        a.key("h_knight_head", "rotation", t, 0.5 * ph2, 6 * sin_t(t, T, 0.1), 0, "catmullrom")
        a.key("arm_l", "rotation", t, 1.2 * ph, 0, 0, "catmullrom")
        for lg in LEGS:
            a.key(f"leg_{lg}", "rotation", t, 0, 0, 0)
    # the horse paws the ground once per loop
    a.tracks[("leg_fl", "rotation")] = []
    for t, v in ((0, 0), (T * 0.50, 0), (T * 0.58, -26), (T * 0.66, 4), (T * 0.74, -20), (T * 0.84, 0), (T, 0)):
        a.key("leg_fl", "rotation", t, v, 0, 0)
    if drawn:
        n2 = 8
        for i in range(n2 + 1):
            t = T * i / n2
            a.sword(t, GUARD[0] + 2.5 * sin_t(t, T), GUARD[1] + 2.5 * sin_t(t, T), "catmullrom")
    else:
        for i in range(n + 1):
            t = T * i / n
            a.key("arm_r", "rotation", t, 1.5 * sin_t(t, T, 0.5), 0, 0, "catmullrom")
            a.key("sword", "rotation", t, 0, 0, 0)
            a.key("sword", "position", t, 0, 0, 0)


def gallop_layer(a, T, drawn, amp=38.0):
    n = 8
    phases = {"bl": 0.0, "br": 0.08, "fl": 0.45, "fr": 0.55}
    for i in range(n + 1):
        t = T * i / n
        for lg, ph in phases.items():
            a.key(f"leg_{lg}", "rotation", t, -amp * sin_t(t, T, ph), 0, 0, "catmullrom")
        bounce = 0.5 - 0.5 * math.cos(4 * math.pi * t / T)
        a.key("horse_root", "position", t, 0, 1.0 * bounce, 0, "catmullrom")
        a.key("horse_root", "rotation", t, 3.0 * sin_t(t, T, 0.1), 0, 0, "catmullrom")
        a.key("neck", "rotation", t, 11 + 4 * sin_t(t, T, 0.3), 0, 0, "catmullrom")
        a.key("head", "rotation", t, -7 + 3 * sin_t(t, T, 0.55), 0, 0, "catmullrom")
        a.key("tail", "rotation", t, 28 + 7 * sin_t(t, T, 0.2), 0, 4 * sin_t(t, T, 0.5), "catmullrom")
        a.key("tail_b", "rotation", t, 22 + 9 * sin_t(t, T, 0.45), 0, 5 * sin_t(t, T, 0.1), "catmullrom")
        a.key("cape_1", "rotation", t, 24 + 4 * sin_t(t, T, 0.2), 0, 0, "catmullrom")
        a.key("cape_2", "rotation", t, 9 + 6 * sin_t(t, T, 0.35), 0, 0, "catmullrom")
        a.key("cape_3", "rotation", t, 26 + 8 * sin_t(t, T, 0.5), 0, 0, "catmullrom")
        a.key("knight_torso", "rotation", t, 6 + 1.5 * sin_t(t, T, 0.1), 0, 0, "catmullrom")
        a.key("h_knight_head", "rotation", t, -5 + 1.5 * sin_t(t, T, 0.3), 0, 0, "catmullrom")
        a.key("arm_l", "rotation", t, 2.0 * sin_t(t, T, 0.2), 0, 0, "catmullrom")
    if drawn:
        for i in range(n + 1):
            t = T * i / n
            a.sword(t, GUARD[0] - 4 + 3 * sin_t(t, T, 0.15), GUARD[1] - 4 + 3 * sin_t(t, T, 0.15), "catmullrom")
    else:
        for i in range(n + 1):
            t = T * i / n
            a.key("arm_r", "rotation", t, 7 * sin_t(t, T, 0.6), 0, 0, "catmullrom")
            a.key("sword", "rotation", t, 0, 0, 0)
            a.key("sword", "position", t, 0, 0, 0)


def settle_horse(a, t):
    """Neutral horse/knight pose keys (used by one-shot sword animations)."""
    a.key("horse_root", "position", t, 0, 0, 0)
    a.key("horse_root", "rotation", t, 0, 0, 0)
    for b in ("neck", "head", "tail", "tail_b", "knight_torso", "h_knight_head", "arm_l"):
        a.key(b, "rotation", t, 0, 0, 0)
    a.key("cape_1", "rotation", t, 2.5, 0, 0)
    a.key("cape_2", "rotation", t, 1.5, 0, 0)
    a.key("cape_3", "rotation", t, 3, 0, 0)
    for lg in LEGS:
        a.key(f"leg_{lg}", "rotation", t, 0, 0, 0)


# ---- idle (sheathed) ----
a = Anim("idle", 4.0, "loop"); horse_idle_layer(a, 4.0, False); ANIMS.append(a)
# ---- run (sheathed) ----
a = Anim("run", 0.6, "loop"); gallop_layer(a, 0.6, False); ANIMS.append(a)
# ---- combat idle / run (sword drawn, held until the chase ends) ----
a = Anim("combat_idle", 4.0, "loop"); horse_idle_layer(a, 4.0, True); ANIMS.append(a)
a = Anim("combat_run", 0.6, "loop"); gallop_layer(a, 0.6, True); ANIMS.append(a)

# ---- draw_sword: reach to the hip -> pull the blade out upward -> lower into the ready guard ----
a = Anim("draw_sword", 0.85, "once")
for t in (0.0, 0.85):
    settle_horse(a, t)
a.key("knight_torso", "rotation", 0.0, 0, 0, 0)
a.key("knight_torso", "rotation", 0.14, 5, 0, 0)       # lean toward the hilt
a.key("knight_torso", "rotation", 0.5, 8, 0, 0)
a.key("knight_torso", "rotation", 0.85, 2, 0, 0)
a.sword_rest(0.0)
a.sword(0.14, ALPHA_REACH, 0)                          # hand closes on the grip
a.sword(0.20, ALPHA_REACH, 0)
a.sword_sweep(0.20, 0.50, ALPHA_REACH, -112.0, 0, 0)   # blade slides out upward, still pointing down
a.sword(0.56, -112.0, 0)                               # tiny pause - blade free of the holster
a.sword_sweep(0.56, 0.85, -112.0, GUARD[0], 0, GUARD[1])
ANIMS.append(a)

# ---- attack_up: wind-up low -> rising diagonal strike -> follow through -> back to guard ----
a = Anim("attack_up", 0.9, "once")
for t in (0.0, 0.9):
    settle_horse(a, t)
a.key("knight_torso", "rotation", 0.0, 0, 0, 0)
a.key("knight_torso", "rotation", 0.12, -5, 0, 0)
a.key("knight_torso", "rotation", 0.30, 11, 0, 0)
a.key("knight_torso", "rotation", 0.45, 8, 0, 0)
a.key("knight_torso", "rotation", 0.9, 0, 0, 0)
a.key("h_knight_head", "rotation", 0.12, 3, 0, 0)
a.key("h_knight_head", "rotation", 0.30, -6, 0, 0)
a.key("h_knight_head", "rotation", 0.9, 0, 0, 0)
a.key("neck", "rotation", 0.12, -3, 0, 0)
a.key("neck", "rotation", 0.30, 7, 0, 0)
a.key("neck", "rotation", 0.9, 0, 0, 0)
a.key("cape_1", "rotation", 0.30, 20, 0, 0)
a.key("cape_1", "rotation", 0.9, 2.5, 0, 0)
a.sword(0.0, GUARD[0], GUARD[1])
a.sword_sweep(0.0, 0.12, GUARD[0], -10.0, GUARD[1], -30.0, 0.04)     # wind-up: blade low and back
a.sword_sweep(0.12, 0.30, -10.0, -100.0, -30.0, -125.0, 0.03)        # strike from below to above
a.sword_sweep(0.30, 0.45, -100.0, -140.0, -125.0, -155.0, 0.05)      # follow through
a.sword_sweep(0.45, 0.90, -140.0, GUARD[0], -155.0, GUARD[1], 0.05)  # recover to guard
ANIMS.append(a)

# ---- sheathe_sword: lift blade above the holster, lower it in, relax the arm ----
a = Anim("sheathe_sword", 1.0, "once")
for t in (0.0, 1.0):
    settle_horse(a, t)
a.key("knight_torso", "rotation", 0.0, 2, 0, 0)
a.key("knight_torso", "rotation", 0.5, 7, 0, 0)
a.key("knight_torso", "rotation", 0.85, 5, 0, 0)
a.key("knight_torso", "rotation", 1.0, 0, 0, 0)
a.sword(0.0, GUARD[0], GUARD[1])
a.sword_sweep(0.0, 0.30, GUARD[0], -112.0, GUARD[1], 0, 0.05)
a.sword(0.40, -112.0, 0)
a.sword_sweep(0.40, 0.82, -112.0, ALPHA_REACH, 0, 0, 0.05)            # slow, visible slide into the holster
a.sword_rest(0.82) if False else None
a.key("arm_r", "rotation", 1.0, 0, 0, 0)
a.key("sword", "rotation", 1.0, 0, 0, 0)
a.key("sword", "position", 1.0, 0, 0, 0)
ANIMS.append(a)

# ---- hurt overlay (short recoil, does not touch the sword arm) ----
a = Anim("hurt", 0.45, "once")
for t, rk, rt, nk in ((0, 0, 0, 0), (0.08, -9, -9, -8), (0.25, -3, -3, -3), (0.45, 0, 0, 0)):
    a.key("horse_root", "position", t, 0, 0, 1.4 * (abs(rk) / 9) if rk else 0, "linear")
    a.key("knight_torso", "rotation", t, rk, 0, 0)
    a.key("neck", "rotation", t, rt, 0, 0)
    a.key("head", "rotation", t, nk, 0, 0)
    a.key("tail", "rotation", t, -rk * 1.2, 0, 0)
ANIMS.append(a)

# make sure every looping/once animation starts/ends on a defined key for each used channel
ALL_ROT = ["horse_root", "neck", "head", "tail", "tail_b", "cape_1", "cape_2", "cape_3", "knight_torso",
           "h_knight_head", "arm_l", "arm_r", "sword"] + [f"leg_{l}" for l in LEGS]
for an in ANIMS:
    for b in ALL_ROT:
        if (b, "rotation") not in an.tracks:
            an.key(b, "rotation", 0, 0, 0, 0)
    for b in ("horse_root", "sword"):
        if (b, "position") not in an.tracks:
            an.key(b, "position", 0, 0, 0, 0)

# --------------------------------------------------------------------------------------
# Write .bbmodel
# --------------------------------------------------------------------------------------
FACE_KEYS = {"north", "east", "south", "west", "up", "down"}


def element(c):
    return {
        "name": c["name"], "box_uv": False, "rescale": False, "locked": False, "light_emission": 0,
        "render_order": "default", "allow_mirror_modeling": True,
        "from": c["frm"], "to": c["to"], "autouv": 0, "color": 0,
        "origin": [(c["frm"][0] + c["to"][0]) / 2, (c["frm"][1] + c["to"][1]) / 2, (c["frm"][2] + c["to"][2]) / 2],
        "faces": {f: {"uv": face_uv[c["uuid"]][f], "texture": 0} for f in FACE_KEYS},
        "type": "cube", "uuid": c["uuid"],
    }


def outliner(name):
    g = groups[name]
    kids = []
    for kind, ref in g["children"]:
        kids.append(ref if kind == "c" else outliner(ref))
    return {"name": g["name"], "origin": g["origin"], "rotation": [0, 0, 0], "color": 0, "uuid": g["uuid"],
            "export": True, "mirror_uv": False, "isOpen": g["name"] in ("root", "horse_root", "knight_root"),
            "locked": False, "visibility": True, "autouv": 0, "children": kids}


animations = []
for an in ANIMS:
    animators = {}
    for (bone, ch), keys in an.tracks.items():
        node = animators.setdefault(groups[bone]["uuid"], {"name": bone, "type": "bone", "keyframes": []})
        for t, (x, y, z), interp in sorted(keys, key=lambda k: k[0]):
            node["keyframes"].append({
                "channel": ch, "data_points": [{"x": str(x), "y": str(y), "z": str(z)}],
                "uuid": U(), "time": t, "color": -1, "interpolation": interp,
            })
    animations.append({
        "uuid": U(), "name": an.name, "loop": an.loop, "override": False, "length": an.length,
        "snapping": 20, "selected": False, "anim_time_update": "", "blend_weight": "",
        "start_delay": "", "loop_delay": "", "animators": animators,
    })

project = {
    "meta": {"format_version": "4.10", "creation_time": 1760000000, "model_format": "free", "box_uv": False},
    "name": NAME, "model_identifier": "", "visible_box": [1, 1, 0], "variable_placeholders": "",
    "variable_placeholder_buttons": [], "unhandled_root_fields": {},
    "resolution": {"width": TEX_SIZE, "height": TEX_SIZE},
    "elements": [element(c) for c in cubes],
    "outliner": [outliner("root")],
    "textures": [{
        "path": "", "name": f"{NAME}.png", "folder": "", "namespace": "", "id": "0",
        "width": TEX_SIZE, "height": TEX_SIZE, "uv_width": TEX_SIZE, "uv_height": TEX_SIZE,
        "particle": False, "use_as_default": False, "layers_enabled": False, "sync_to_project": "",
        "render_mode": "default", "render_sides": "auto", "frame_time": 1, "frame_order_type": "loop",
        "frame_order": "", "frame_interpolate": False, "visible": True, "internal": True, "saved": False,
        "uuid": U(), "source": "data:image/png;base64," + TEX_B64,
    }],
    "animations": animations,
}
with open(os.path.join(OUT, f"{NAME}.bbmodel"), "w") as fh:
    json.dump(project, fh, separators=(",", ":"))

# --------------------------------------------------------------------------------------
# Orthographic preview (front / side / top) - quick geometry sanity check
# --------------------------------------------------------------------------------------
COL = {k: v[0] for k, v in PAL.items()}
COL.update({"trim": (60, 140, 255), "glow": (150, 220, 255), "ghost": (80, 160, 255), "eye": (200, 250, 255),
            "armor": (46, 54, 84), "armor2": (30, 34, 56), "cloth": (30, 48, 110), "leather": (70, 52, 50),
            "void": (6, 8, 14), "metal": (110, 122, 160), "blade": (60, 80, 130), "hoof": (20, 22, 34)})
S = 9
views = {"front (north, -Z toward viewer)": (0, 1, +1), "side (front on the left)": (2, 1, +1), "top": (0, 2, +1)}
W = 70 * S
Himg = 62 * S
img = Image.new("RGB", (W * 3 + 40, Himg + 30), (22, 24, 30))
dr = ImageDraw.Draw(img)
for vi, (title, (ax, ay, _)) in enumerate(views.items()):
    ox = 10 + vi * (W + 10) + W // 2
    dr.text((ox - W // 2 + 4, 4), title, fill=(200, 210, 230))
    depth_axis = {0: 2, 2: 0}.get(ax, 1)
    order = sorted(cubes, key=lambda c: -(c["frm"][depth_axis] + c["to"][depth_axis]) / 2 if vi != 2 else (c["frm"][1] + c["to"][1]) / 2)
    if vi == 0:
        order = sorted(cubes, key=lambda c: (c["frm"][2] + c["to"][2]) / 2, reverse=True)
    if vi == 1:
        order = sorted(cubes, key=lambda c: (c["frm"][0] + c["to"][0]) / 2)
    for c in order:
        if ay == 1:
            x0, x1 = c["frm"][ax], c["to"][ax]
            y0, y1 = c["frm"][1], c["to"][1]
            px0, px1 = ox + x0 * S, ox + x1 * S
            if vi == 1:
                px0, px1 = ox - x1 * S, ox - x0 * S
                px0, px1 = ox + c["frm"][2] * S, ox + c["to"][2] * S
            py0, py1 = Himg - y1 * S, Himg - y0 * S
        else:
            px0, px1 = ox + c["frm"][0] * S, ox + c["to"][0] * S
            py0, py1 = 40 + (c["frm"][2] + 25) * S, 40 + (c["to"][2] + 25) * S
        col = COL[c["mat"]]
        dr.rectangle([px0, py0, px1, py1], fill=col, outline=tuple(min(255, k + 40) for k in col))
img.save(os.path.join(OUT, f"preview_{NAME}_rest_pose.png"))
print("cubes:", len(cubes), "groups:", len(groups), "animations:", [x.name for x in ANIMS])
print("sword grip centre Y = %.2f, reach alpha = %.1f deg" % (G0Y, ALPHA_REACH))
