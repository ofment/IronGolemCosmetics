#!/usr/bin/env python3
"""Tiny textured preview renderer for a .bbmodel (rest pose or any animation time). Usage:
   python3 render_bbmodel.py model.bbmodel out.png [animation:time ...]"""
import json, math, sys, base64, io
from PIL import Image, ImageDraw

def rotm(rx, ry, rz):
    rx, ry, rz = map(math.radians, (rx, ry, rz))
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = [[1,0,0],[0,cx,-sx],[0,sx,cx]]; Ry = [[cy,0,sy],[0,1,0],[-sy,0,cy]]; Rz = [[cz,-sz,0],[sz,cz,0],[0,0,1]]
    mm = lambda A,B: [[sum(A[i][k]*B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return mm(Rz, mm(Ry, Rx))

def load(path):
    m = json.load(open(path))
    tex = Image.open(io.BytesIO(base64.b64decode(m["textures"][0]["source"].split(",", 1)[1]))).convert("RGBA")
    els = {e["uuid"]: e for e in m["elements"]}
    cubes = []
    def walk(nodes, chain):
        for n in nodes:
            if isinstance(n, dict):
                walk(n["children"], chain + [n])
            else:
                cubes.append((els[n], chain))
    walk(m["outliner"], [])
    return m, tex, cubes

def pose_at(m, name, t):
    if not name: return {}
    a = next(x for x in m["animations"] if x["name"] == name)
    pose = {}
    for an in a["animators"].values():
        by = {}
        for kf in an["keyframes"]:
            by.setdefault(kf["channel"], []).append((kf["time"], [float(kf["data_points"][0].get(k, 0) or 0) for k in "xyz"]))
        for ch, ks in by.items():
            ks.sort(key=lambda k: k[0])
            if t <= ks[0][0]: v = ks[0][1]
            elif t >= ks[-1][0]: v = ks[-1][1]
            else:
                for i in range(len(ks) - 1):
                    if ks[i][0] <= t <= ks[i+1][0]:
                        f = (t - ks[i][0]) / max(1e-9, ks[i+1][0] - ks[i][0])
                        v = [ks[i][1][k] + (ks[i+1][1][k] - ks[i][1][k]) * f for k in range(3)]; break
            pose.setdefault(an["name"], {})[ch] = v
    return pose

def world(chain, p, pose):
    for g in reversed(chain):
        pr = pose.get(g["name"], {})
        rot = [g["rotation"][i] + pr.get("rotation", [0,0,0])[i] for i in range(3)]
        pos = pr.get("position", [0,0,0]); sc = pr.get("scale", [1,1,1])[0]
        d = [(p[i] - g["origin"][i]) * sc for i in range(3)]
        R = rotm(*rot)
        p = [g["origin"][i] + sum(R[i][k] * d[k] for k in range(3)) + pos[i] for i in range(3)]
    return p

def render(m, tex, cubes, pose, yaw, size=(420, 520), scale=7.5):
    W, H = size; im = Image.new("RGB", size, (20, 24, 40)); dr = ImageDraw.Draw(im)
    cy, sy = math.cos(math.radians(yaw)), math.sin(math.radians(yaw)); px = tex.load(); polys = []
    for e, chain in cubes:
        if any(pose.get(g["name"], {}).get("scale", [1])[0] < 0.01 for g in chain): continue
        a, b = e["from"], e["to"]
        C = {(i,j,k): [b[0] if i else a[0], b[1] if j else a[1], b[2] if k else a[2]] for i in (0,1) for j in (0,1) for k in (0,1)}
        wc = {k: world(chain, v, pose) for k, v in C.items()}
        def P(k):
            x, y, z = wc[k]; xr = x*cy + z*sy; zr = -x*sy + z*cy
            return (W/2 + xr*scale, H - 30 - y*scale), zr
        faces = {"north": [(0,0,0),(1,0,0),(1,1,0),(0,1,0)], "south": [(0,0,1),(1,0,1),(1,1,1),(0,1,1)],
                 "west": [(0,0,0),(0,0,1),(0,1,1),(0,1,0)], "east": [(1,0,0),(1,0,1),(1,1,1),(1,1,0)],
                 "up": [(0,1,0),(1,1,0),(1,1,1),(0,1,1)], "down": [(0,0,0),(1,0,0),(1,0,1),(0,0,1)]}
        shade = {"up": 1.18, "north": 1.0, "south": 0.78, "east": 0.88, "west": 0.88, "down": 0.55}
        for fn, idx in faces.items():
            u0, v0, u1, v1 = e["faces"][fn]["uv"]
            pts = [P(i) for i in idx]
            cols = [px[x, y][:3] for x in range(int(min(u0,u1)), max(int(min(u0,u1))+1, int(max(u0,u1)))) for y in range(int(min(v0,v1)), max(int(min(v0,v1))+1, int(max(v0,v1))))]
            col = tuple(sum(c[i] for c in cols)//len(cols) for i in range(3))
            col = tuple(min(255, int(v * shade[fn])) for v in col)
            polys.append((sum(p[1] for p in pts)/4, [p[0] for p in pts], col))
    polys.sort(key=lambda t: t[0])
    for _, pts, col in polys: dr.polygon(pts, fill=col)
    return im

if __name__ == "__main__":
    m, tex, cubes = load(sys.argv[1]); out = sys.argv[2]
    views = sys.argv[3:] or ["idle:0"]
    sheet = Image.new("RGB", (420 * len(views) * 2, 520))
    for i, v in enumerate(views):
        n, t = v.split(":"); pose = pose_at(m, n, float(t))
        for j, yaw in enumerate((-40, 140)):
            im = render(m, tex, cubes, pose, yaw); ImageDraw.Draw(im).text((8, 8), f"{n} t={t} yaw={yaw}", fill=(255,255,255))
            sheet.paste(im, ((i*2 + j) * 420, 0))
    sheet.save(out)
